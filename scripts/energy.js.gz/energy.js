function navigator_Go(url){window.location.assign(url)}
var isSubmitting=false

function ajax(Update=$LastUpdateTime){
	$LastUpdateTime=localStorage.getItem("LastUpdateTime")
	$.json('/ajax.php?t='+Update).then(
		function(response){
			$newTime=parseInt(response['t'])
			localStorage.setItem("LastUpdateTime",response['t'])
			if((response['t']-$LastUpdateTime)>=1)ajax(0)
			if (Update==0) {
				zonavg=response['zonavg']
			}
			
			if (localStorage.getItem('view')=='floorplan') {
				zon=+response['zon']||0
				net=+response['net']||0
				avg=+response['avg']||0
				elvandaag=localStorage.getItem("elvandaag")
				total=net+zon
				
				$("#netvalue").html(net)
				if(net>0)$("#net").css('color',berekenKleurRood(net,5000))
				else $("#net").css('color',berekenKleurGroen(-net,5000))
				drawCircle('netcircle',net,2500,800,'purple')

				$("#avgvalue").html(avg)
				$("#avgvalue").css('color',berekenKleurRood(avg,5000))
				drawCircle('avgtimecircle',updateSecondsInQuarter(response['t']+6),800,790,'gray')
				drawCircle('avgcircle',avg,2500,800,'purple')

				$("#totalvalue").html(total)
				$("#totalvalue").css('color',berekenKleurRood(net,5000))
				drawCircle('totalcircle',total,2500+zon,800,'purple')

				$("#zonvalue").html(zon)
				$("#zonvalue").css('color',berekenKleurGroen(zon,zonavg*2))
				drawCircle('zoncircle',-zon,zonavg,800,'green')
			}
			$.each(response, function(device, v, i){
				if(device=="elvandaag"){
					try{
						$("#alwayson").html(v['icon']+"W")
						$("#elecvalue").html(v['s'].toString().replace(/[.]/, ","))
						if(net>0)$("#elecvalue").css('color',berekenKleurRood(v['s'],v['m']*2))
						else $("#elecvalue").css('color',berekenKleurGroen(-v['s'],v['m']*2))
						drawCircle('eleccircle',v['s'],v['m'],800,'purple')
					}catch{}
				}else if(device=="zonvandaag"){
					try{
						item=v['s']
						$("#zonvvalue").html(item.toString().replace(/[.]/, ","))
						$("#zonvvalue").css('color',berekenKleurGroen(-item,v['m']/10))
						drawCircle('zonvcircle',v['s'],v['m'],800,'green')
					}catch{}
				}else if(device=="gasvandaag"){
					try{
						item=v['s']*1000
						$("#gasvalue").html(item.toString().replace(/[.]/, ","))
						$("#gasvalue").css('color',berekenKleurRood(item,v['m']*2000))
						drawCircle('gascircle',item,v['m']*1000,800,'red')
					}catch{}
				}else if(device=="watervandaag"){
					try{
						item=v['s']
						$("#watervvalue").html(item)
						$("#watervvalue").css('color',berekenKleurRood(item,v['m']*2))
						drawCircle('watervcircle',item,v['m'],800,'blue')
					}catch{}
				}else{
					//console.log(v['dt']+" -> "+device+" -> "+v['s']+" -> "+time+" -> "+v['m'])
				}
			})
		},
	)
}

function floorplan(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplan')
	ajax(0)
	myAjax=$.setInterval(ajax,999)
	try{
		html='<div class="fix verbruik">'
		html+='<div id="avg"><span id="avgtitle">15\'</span><span id="avgvalue"></span><span id="avgunit">Wh</span><canvas id="avgtimecircle" width="820" height="820"></canvas><canvas id="avgcircle" width="820" height="820"></canvas></div>'
		html+='<div id="net"><span id="nettitle">Net</span><span id="netvalue"></span><span id="netunit">W</span><canvas id="netcircle" width="820" height="820"></canvas></div>'
		html+='<div id="total"><span id="totaltitle">Verbruik</span><span id="totalvalue"></span><span id="totalunit">W</span><canvas id="totalcircle" width="820" height="820"></canvas></div>'
		html+='<div id="elec"><span id="electitle">Elec</span><span id="elecvalue"></span><span id="elecunit">kWh</span><canvas id="eleccircle" width="820" height="820"></canvas></div>'
		html+='<div id="gas"><span id="gastitle">Gas</span><span id="gasvalue"></span><span id="gasunit">L</span><canvas id="gascircle" width="820" height="820"></canvas></div>'
		html+='<div id="waterv"><span id="watervtitle">Water</span><span id="watervvalue"></span><span id="watervunit">L</span><canvas id="watervcircle" width="820" height="820"></canvas></div>'
		html+='<div id="zon"><span id="zontitle">Zon</span><span id="zonvalue"></span><span id="zonunit">W</span><canvas id="zoncircle" width="820" height="820"></canvas></div>'
		html+='<div id="zonv"><span id="zonvtitle">Zon</span><span id="zonvvalue"></span><span id="zonvunit">kWh</span><canvas id="zonvcircle" width="820" height="820"></canvas></div>'
		html+='</div>'
		//<div style="background-color:#000;position:fixed;z-index:-100;top:756px;left:78px;width:412px;height:214px"></div>'
		$('#placeholder').html(html)
	}catch{}
	sidebar()
}

function initview(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	for (var i=1; i < 99999; i++){try{window.clearInterval(i);}catch{};}
	view=localStorage.getItem('view')
	if(view=="floorplan")window["floorplan"]()
	else if(view=="floorplanheating")window["floorplanheating"]()
	else if(view=="floorplanothers")window["floorplanothers"]()
	else if(view=="floorplandaikin")window["floorplandaikin"]()
	else window["floorplan"]()
}

function berekenKleurRood(waarde, maxWaarde) {
    waarde=Math.max(0, Math.min(maxWaarde, waarde))
    let rood,groen,blauw
    const overgang1=maxWaarde * 0.25
    const overgang2=maxWaarde * 0.5
    const overgang3=maxWaarde * 0.75
    if (waarde < overgang1) {
        rood=204
        groen=204 + (waarde / overgang1) * (255 - 204)
        blauw=204
    } else if (waarde < overgang2) { 
        rood=255
        groen=255 - ((waarde - overgang1) / (overgang2 - overgang1)) * 50
        blauw=0
    } else if (waarde < overgang3) {
        rood=255
        groen=165 - ((waarde - overgang2) / (overgang3 - overgang2)) * 15
        blauw=0
    } else { 
        rood=255
        groen=69 - ((waarde - overgang3) / (maxWaarde - overgang3)) * 69
        blauw=0
    }
    return `#${Math.round(rood).toString(16).padStart(2, '0')}${Math.round(groen).toString(16).padStart(2, '0')}${Math.round(blauw).toString(16).padStart(2, '0')}`
}
function berekenKleurGroen(waarde, maxWaarde) {
    waarde=Math.max(0, Math.min(maxWaarde, waarde))
    let rood, groen, blauw
    const overgang1=maxWaarde * 0.25
    const overgang2=maxWaarde * 0.5
    const overgang3=maxWaarde * 0.75
    if (waarde < overgang1) {
        rood=204
        groen=204 + (waarde / overgang1) * (255 - 204)
        blauw=204
    } else if (waarde < overgang2) { 
        rood=255
        groen=255 - ((waarde - overgang1) / (overgang2 - overgang1)) * 50
        blauw=0
    } else if (waarde < overgang3) {
        rood=165 - ((waarde - overgang2) / (overgang3 - overgang2)) * 15
        groen=255
        blauw=0
    } else { 
        rood=69 - ((waarde - overgang3) / (maxWaarde - overgang3)) * 69
        groen=255
        blauw=0
    }
    return `#${Math.round(rood).toString(16).padStart(2, '0')}${Math.round(groen).toString(16).padStart(2, '0')}${Math.round(blauw).toString(16).padStart(2, '0')}`
}
function drawCircle(id, value, maxValue, circleSize, color) {
	const canvas=document.getElementById(id)
	const ctx=canvas.getContext('2d')
	const centerX=canvas.width/2
	const centerY=canvas.height/2
	const radius=circleSize/2
	percentage=(Math.abs(value)/maxValue)
	if(percentage>1) percentageB=percentage-1
	else percentageB=percentage
	const maxAngle=Math.PI*2
	const angle=percentageB*maxAngle
//	if(id=='avgtimecircle') console.log(id+' '+' value='+value+' percentage='+percentage+' percentageB='+percentageB)
	ctx.clearRect(0,0,canvas.width,canvas.height)
	ctx.beginPath()
	ctx.arc(centerX,centerY,radius,-Math.PI/2,-Math.PI/2+maxAngle)
	ctx.lineWidth=25
	if(percentage>1) {
		if (value >= 0) {
			if (color=='purple') ctx.strokeStyle='#b54dff'
			else if (color=='green') ctx.strokeStyle='#33cc33'
			else if (color=='red') ctx.strokeStyle='#ffb833'
			else if (color=='blue') ctx.strokeStyle='#3333ff'
		} else {
			if (color=='purple') ctx.strokeStyle='#0f3d0f'
			else if (color=='green') ctx.strokeStyle='#33cc33'
			else if (color=='red') ctx.strokeStyle='#ffb833'
			else if (color=='blue') ctx.strokeStyle='#000080'
		}
	} else {
		if (value >= 0) {
			if (color=='purple') ctx.strokeStyle='#3b0066'
			else if (color=='green') ctx.strokeStyle='#0f3d0f'
			else if (color=='red') ctx.strokeStyle='#805300'
			else if (color=='blue') ctx.strokeStyle='#000080'
			else if (color=='gray') ctx.strokeStyle='#000000'
		} else {
			if (color=='purple') ctx.strokeStyle='#0f3d0f'
			else if (color=='green') ctx.strokeStyle='#0f3d0f'
			else if (color=='red') ctx.strokeStyle='#805300'
			else if (color=='blue') ctx.strokeStyle='#000080'
		}
	}
	ctx.stroke()
	ctx.beginPath()
	if(percentage>1) {
		if (value >= 0) {
			if (color=='green') ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 - angle, true)
			else ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 + angle)
			if (color=='purple') ctx.strokeStyle='#ff0000'
			else if (color=='green') ctx.strokeStyle='#66ff66'
			else if (color=='red') ctx.strokeStyle='#ff0000'
			else if (color=='blue') ctx.strokeStyle='#ff0000'
		} else {
			ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 - angle, true)
			if (color=='purple') ctx.strokeStyle='#33cc33'
			else if (color=='green') ctx.strokeStyle='#e6ff00'
			else if (color=='red') ctx.strokeStyle='#ff1a1a'
			else if (color=='blue') ctx.strokeStyle='#ff0000'
		}
	} else {
		if (value >= 0) {
			if (color=='green') ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 - angle, true)
			else ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 + angle)
			if (color=='purple') ctx.strokeStyle='#b54dff'
			else if (color=='green') ctx.strokeStyle='#33cc33'
			else if (color=='red') ctx.strokeStyle='#ffb833'
			else if (color=='blue') ctx.strokeStyle='#3333ff'
			else if (color=='gray') ctx.strokeStyle='#aaaaaa'
		} else {
			ctx.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 - angle, true)
			if (color=='purple') ctx.strokeStyle='#33cc33'
			else if (color=='green') ctx.strokeStyle='#33cc33'
			else if (color=='red') ctx.strokeStyle='#ffb833'
			else if (color=='blue') ctx.strokeStyle='#3333ff'
		}
	}
	ctx.lineWidth=25
	ctx.stroke()
}
function updateSecondsInQuarter(time) {
    let currentTime = new Date(time*1000);
    let totalSecondsToday = Math.floor(currentTime.getTime() / 1000)
    let secondsInCurrentQuarter = totalSecondsToday % (15 * 60)
	return secondsInCurrentQuarter
}