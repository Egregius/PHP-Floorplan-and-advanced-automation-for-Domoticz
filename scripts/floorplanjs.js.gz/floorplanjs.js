function navigator_Go(url){window.location.assign(url)}
var isSubmitting=false
function ajax(Update=$LastUpdateTime){
	$LastUpdateTime=localStorage.getItem("LastUpdateTime")
	$.json('/ajax.php?t='+Update).then(
		function(response){
			$newTime=parseInt(response['t'])
			localStorage.setItem("LastUpdateTime",response['t'])
			if((response['t']-$LastUpdateTime)>=1)ajax(0)
			zon=+response['zon']||0
			net=+response['net']||0
			avg=+response['avg']||0
			
			
			try{
				elvandaag=localStorage.getItem("elvandaag")
				total=net+zon
				$("#trelec").html("<td id='delta'>&Delta; "+net+" W</td><td>Elec:</td><td id='elec'>"+total+" W</td><td id='elecvandaag'>"+elvandaag.toString().replace(/[.]/, ",")+" kWh<br>"+avg+" Wh</td>")
				$color=~~(256-(total/310))
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				document.getElementById("elec").style.color=$color

				$color=~~(256-((v['m']-10)/0.1171875))
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if(v['m']>10)document.getElementById("elecvandaag").style.color=$color
				else document.getElementById("elecvandaag").style.color=null

				if(net>0){
					$color=~~(256-(net/310))
					$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
					$color="#FF"+$color+"00"
				} else {
					$color=net/3.906250016
					$color=256-$color
					$color=~~$color
					$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
					$color="#"+$color+"FF"+$color
				}
				document.getElementById("delta").style.color=$color
			}catch{}			

			if(zon>0){
				$color=zon/3.906250016
				$color=256-$color
				$color=~~$color
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#"+$color+"FF"+$color
			} else $color="#AAA"
			try{
				$("#zon").html(zon+" W")
				document.getElementById("zon").style.color=$color
			}catch{}
			
			if (Update==0) {
				try {
					$("#zonop").html(response['CivTwilightStart'])
					$("#sunop").html(response['Sunrise'])
					$("#sunonder").html(response['Sunset'])
					$("#zononder").html(response['CivTwilightEnd'])
				}catch{}
			}
			$.each(response, function(device, v, i){
				if(device=="Weg"){
					localStorage.setItem("Weg", v['s'])
					try{
						html='<div class="fix z" onclick="Weg();">'
						if(v['s']==0)html+='<img src="/images/Thuis.png" id="Weg">'
						else if(v['s']==1)html+='<img src="/images/Slapen.png" id="Weg">'
						else if(v['s']==2)html+='<img src="/images/Weg.png" id="Weg">'
						else if(v['s']==3)html+='<img src="/images/Vacation.png" id="Weg">'
						html+='</div>'
						$("#Weg").html(html)
					}catch{}
					if(v['s']==0){
						try{
							$("#zliving").removeClass("secured")
							$("#zlivingb").removeClass("secured")
							$("#zkeuken").removeClass("secured")
							$("#zinkom").removeClass("secured")
						}catch{}
						try{
							$("#zgarage").removeClass("secured")
							$("#zhalla").removeClass("secured")
							$("#zhallb").removeClass("secured")
						}catch{}
					}else if(v['s']==1){
						try{
							$("#zliving").addClass("secured")
							$("#zlivingb").addClass("secured")
							$("#zkeuken").addClass("secured")
							$("#zinkom").addClass("secured")
						}catch{}
						try{
							$("#zgarage").addClass("secured")
							$("#zhalla").removeClass("secured")
							$("#zhallb").removeClass("secured")
						}catch{}
					}else if(v['s']>=2){
						try{
							$("#zliving").addClass("secured")
							$("#zlivingb").addClass("secured")
							$("#zkeuken").addClass("secured")
							$("#zinkom").addClass("secured")
						}catch{}
						try{
							$("#zgarage").addClass("secured")
							$("#zhalla").addClass("secured")
							$("#zhallb").addClass("secured")
						}catch{}
					}
				}else if(device=="minmaxtemp"){
					try{
						$("#mintemp").html("<small>&#x21e9;</small>"+v['s'].toString().replace(/[.]/, ",")+" &#8451;")
						if(v['s']>30)$("#mintemp").css("color", "#F66")
						else if(v['s']>28)$("#mintemp").css("color", "#F77")
						else if(v['s']>26)$("#mintemp").css("color", "#F88")
						else if(v['s']>24)$("#mintemp").css("color", "#F99")
						else if(v['s']>22)$("#mintemp").css("color", "#FAA")
						else if(v['s']>20)$("#mintemp").css("color", "#FBB")
						else if(v['s']>18)$("#mintemp").css("color", "#FCC")
						else if(v['s']<10)$("#mintemp").css("color", "#CCF")
						else if(v['s']<8)$("#mintemp").css("color", "#BBF")
						else if(v['s']<6)$("#mintemp").css("color", "#AAF")
						else if(v['s']<4)$("#mintemp").css("color", "#99F")
						else if(v['s']<2)$("#mintemp").css("color", "#88F")
						else if(v['s']<0)$("#mintemp").css("color", "#77F")
						else $("#maxtemp").css("color",null)
						$("#maxtemp").html("<small>&#x21e7;</small>"+v['m'].toString().replace(/[.]/, ",")+" &#8451;")
						if(v['m']>30)$("#maxtemp").css("color", "#F66")
						else if(v['m']>28)$("#maxtemp").css("color","#F77")
						else if(v['m']>26)$("#maxtemp").css("color","#F88")
						else if(v['m']>24)$("#maxtemp").css("color","#F99")
						else if(v['m']>22)$("#maxtemp").css("color","#FAA")
						else if(v['m']>20)$("#maxtemp").css("color","#FBB")
						else if(v['m']>18)$("#maxtemp").css("color","#FCC")
						else if(v['m']<10)$("#maxtemp").css("color","#CCF")
						else if(v['m']<8)$("#maxtemp").css("color","#BBF")
						else if(v['m']<6)$("#maxtemp").css("color","#AAF")
						else if(v['m']<4)$("#maxtemp").css("color","#99F")
						else if(v['m']<2)$("#maxtemp").css("color","#88F")
						else if(v['m']<0)$("#maxtemp").css("color","#77F")
						else $("#maxtemp").css("color",null)
					}catch{}
				}else if(device=="wind"){
					try{
						elem=document.getElementById("wind")
						elem.innerHTML=v['s'].toString().replace(/[.]/, ",")+"km/u"
						if(v['s']>40)elem.style.color="#F66"
						else if(v['s']>30)elem.style.color="#F77"
						else if(v['s']>25)elem.style.color="#F88"
						else if(v['s']>20)elem.style.color="#F99"
						else if(v['s']>16)elem.style.color="#FAA"
						else if(v['s']>12)elem.style.color="#FBB"
						else if(v['s']>8)elem.style.color="#FCC"
						else elem.style.color=null
					}catch{}
				}else if(device=="icon"){
					try{
						$('#icon').attr("src", "/images/"+v['s']+".png")
					}catch{}
				}else if(device=="uv"){
					try{
						if(v['s']==0)html=''
						else if(v['s']<2)html='<font color="#99EE00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['s']<4)html='<font color="#99CC00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['s']<6)html='<font color="#FFCC00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['s']<8)html='<font color="#FF6600">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
						else html='<font color="#FF2200">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
						if(v['m']==0)html+=''
						else if(v['m']<2)html+='<br><font color="#99EE00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['m']<4)html+='<br><font color="#99CC00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['m']<6)html+='<br><font color="#FFCC00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
						else if(v['m']<8)html+='<br><font color="#FF6600">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
						else html+='<br><font color="#FF2200">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
						$("#uv").html(html)
					}catch{}
				}else if(device=="elvandaag"){
					localStorage.setItem("elvandaag",v['s'])
					$("#alwayson").html(v['icon']+"W")
				}else if(device=="zonvandaag"){
					try{
						zonvandaag=parseFloat(Math.round(v['s']*10)/10).toFixed(1)
						$dcolor=~~(256-(v['m']/0.5))
						$dcolor=('00' + $dcolor.toString(16).toUpperCase()).slice(-2)
						$dcolor="#"+$dcolor+"FF"+$dcolor
						$("#zonvandaag").html(zonvandaag.toString().replace(/[.]/, ",")+" kWh")
						if(v['m']>0)document.getElementById("zonvandaag").style.color=$dcolor
						else document.getElementById("zonvandaag").style.color="#CCC"
					}catch{}
				}else if(device=="gasvandaag"){
					try{
						if(v['s']>0){
//							item=parseFloat(Math.round((v['s']/100)*100)/100).toFixed(2)
							item=v['s']
							$("#trgas").html('<td></td><td id="tdgas">Gas:</td><td colspan="2" id="tdgasvandaag">'+item.toString().replace(/[.]/, ",")+' m<sup>3</sup>')
							if(item>3){
								$color=~~(256-(item/0.078125))
								$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
								$color="#FF"+$color+"00"
							} else $color="#CCC"
							if(v['s']>4)document.getElementById("tdgasvandaag").style.color=$color
							else document.getElementById("tdgasvandaag").style.color=null
						}else $("#trgas").html("")
					}catch{}
					localStorage.setItem("tijd_gas", v['t'])
				}else if(device=="watervandaag"){
					try{
						if(v['s']>0){
							item=v['s']
							$("#trwater").html('<td></td><td id="tdwater">Water:</td><td colspan="2" id="watervandaag">'+item.toString().replace(/[.]/, ",")+' L</sup>')
							if(v['s']>1000)document.getElementById("watervandaag").style.color="#FF0000"
							else if(v['s']>750)document.getElementById("watervandaag").style.color="#FF4400"
							else if(v['s']>500)document.getElementById("watervandaag").style.color="#FF8800"
							else if(v['s']>400)document.getElementById("watervandaag").style.color="#FFAA00"
							else if(v['s']>300)document.getElementById("watervandaag").style.color="#FFCC00"
							else if(v['s']>200)document.getElementById("watervandaag").style.color="#FFFF00"
							else document.getElementById("watervandaag").style.color=null
						}else $("#trwater").html("")
					}catch{}
					localStorage.setItem("tijd_water", v['t'])
				}else if(device=="heating"){
					try{
					   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
						if(v['s']==0)html+=''
						else if(v['s']==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
						else if(v['s']==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
						else if(v['s']==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
						else if(v['s']==2)html+='<img src="/images/AircoGas.png" class="i40" alt="AircoGas">'
						else if(v['s']==3)html+='<img src="/images/GasAirco.png" class="i40" alt="GasAirco">'
						else if(v['s']==4)html+='<img src="/images/Gas.png" class="i40" alt="Gas">'
						document.getElementById("heating").innerHTML=html
					}catch{}
					localStorage.setItem(device, v['s'])
					localStorage.setItem('tijd_'+device, v['t'])
					try{
						html='<td>'
						if(v['s']==0)html+='<img src="images/close.png" height="40" width="40px" onclick="heating();"></td><td align="left" height="40" width="40px" style="line-height:18px" onclick="heating()">Neutral</td>'
						else if(v['s']==-2)html+='<img src="images/Cooling.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>cooling</td>'
						else if(v['s']==-1)html+='<img src="images/Cooling_grey.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Passive<br>cooling</td>'
						else if(v['s']==1)html+='<img src="images/Cooling_red.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>heating</td>'
						else if(v['s']==2)html+='<img src="images/GasAirco.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas-Airco<br>heating</td>'
						else if(v['s']==3)html+='<img src="images/Gas.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas heating</td>'
						document.getElementById("trheating").innerHTML=html
					}catch{}
				}else if(device=="Grohered_kWh"){
					try{
						elem=v['s'].split(";")
						item=parseInt(Math.round(elem[0]))
						if(item==0)html=""
						else if(item>0&&item<11)html='<img src="images/plug_On.png" width="28px" height="auto" alt="">'
						else html='<img src="images/plug_Red.png" width="28px" height="auto" alt="">'
						document.getElementById("Grohered_kWh").innerHTML=html
					}catch{}
				}else if(device=="daikin_kWh"){
					try{
						elem=document.getElementById("daikin_kWh")
						if(v['s']>0){
							html=Math.round(v['s'])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(v['s']/10))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(v['s']>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="powermeter_kWh"){
					try{
						elem=document.getElementById("powermeter_kWh")
						if(v['s']>0){
							html=Math.round(v['s'])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(v['s']/15))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(v['s']>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="wasdroger_kWh"){
					try{
						elem=document.getElementById("wasdroger_kWh")
						if(v['s']>0){
							html=Math.round(v['s'])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(v['s']/10))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(v['s']>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="sirene"){
					try{
						if(v['s']!="Off")html='<img src="images/alarm_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'sirene\',\'sw\',\'Off\')"><br>'+device
						else html=""
						document.getElementById("sirene").innerHTML=html
					}catch{}
				}else if(v['dt']=="smoke detector"){
					try{
						if(v['s']!="Off")html='<img src="images/smoke_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'resetsecurity\',\'resetsecurity\',\'Off\')"><br>'+device
						else html=""
						document.getElementById("sirene").innerHTML=html
					}catch{}
				}else if(device=="brander"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem('tijd_'+device, v['t'])
					try{
						if(v['s']=="Off")html='<img src="images/fire_Off.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'On\')">'
						else html='<img src="images/fire_On.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'Off\')">'
						document.getElementById("brander").innerHTML=html
					}catch{}
					heatingmode=localStorage.getItem('heating')
					try{
					   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
						if(heatingmode==0)html+=''
						else if(heatingmode==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
						else if(heatingmode==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
						else if(heatingmode==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
						else if(heatingmode==4){
							if(v['s']=='On')html+='<img src="/images/fire_On.png" class="i40" id="branderfloorplan" alt="Gas">'
							else html+='<img src="/images/fire_Off.png" class="i40" alt="Gas">'
						}
						document.getElementById("heating").innerHTML=html
					}catch{}
					try{
						//BRANDERFLOORPLAN
						if(heatingmode==4){
							if(v['s']=="Off") $('#branderfloorplan').attr("src", "/images/fire_Off.png")
							else $('#branderfloorplan').attr("src", "/images/fire_On.png")
						} else if(heatingmode==3){
							if(v['s']=="Off")$('#branderfloorplan').attr("src", "/images/gaselec_Off.png")
							else $('#branderfloorplan').attr("src", "/images/gaselec_On.png")
						} else $('#branderfloorplan').attr("src", "")
					}catch{}
				}else if(device=="luifel"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem('tijd_'+device, v['t'])
					localStorage.setItem(device+'mode', v['m'])
					try{
						if(v['s']==0)html='<img src="/images/arrowgreenup.png" class="i60">'
						else if(v['s']==100)html='<img src="/images/arrowgreendown.png" class="i60">'
						else html='<img src="/images/arrowdown.png" class="i60"><div class="fix center dimmerlevel" style="position:absolute;top:10px;left:-2px;width:70px;letter-spacing:4;"><font size="5" color="#CCC">'+v['s']+'</font> </div>'
						if(v['m']==1)html+='<div class="fix" style="top:2px;left:2px;z-index:-100;background:#fff7d8;width:56px;height:56px;border-radius:45px;"></div>'
						html+='<br>luifel<br><span id="tluifel"></span>'
						document.getElementById(device).innerHTML=html
					}catch{}
				}else if(device=="raamhall"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem("tijd_"+device, v['t'])
					try{
						element=document.getElementById(device)
						if(v['s']=="Open") element.classList.add("red")
						else element.classList.remove("red")
						if(v['t']>($LastUpdateTime-82800)){
							date=new Date(v['t']*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("t"+device).innerHTML=""
					}catch{}
				}else if(device=="buien"){
					try{
						if(typeof v['s'] !== undefined){
							elem=document.getElementById('buien')
							elem.innerHTML="Buien: "+v['s']
							if(v['s']>70)elem.style.color="#39F"
							else if(v['s']>60)elem.style.color="#69F"
							else if(v['s']>50)elem.style.color="#79F"
							else if(v['s']>40)elem.style.color="#89F"
							else if(v['s']>30)elem.style.color="#99F"
							else if(v['s']>20)elem.style.color="#AAF"
							else if(v['s']>10)elem.style.color="#BBD"
							else if(v['s']>0)elem.style.color="#CCF"
							else elem.style.color=null
						}else{
							elem=document.getElementById('buien')
							elem.innerHTML="Buien: 0"
							elem.style.color="#888"
						}
					}catch{}
				}else if(v['dt']=="switch"){
					html=''
					try{
						if(device=="water"||device=="regenpomp"||device=="steenterras"||device=="tuintafel"||device=="terras"||device=="tuin"||device=="auto"||device=="Media"||device=="nas"){
							if(device=="Media"||device=="steenterras") {
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
							} else if(device=="regenpomp"||device=="nas") {
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\');floorplan();"/>'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\');floorplan();""/>'
							} else {
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\')"/>'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\')""/>'
							}
							html+='<br>'+device
							if(device=="water"||device=="regenpomp"||device=="auto"||device=="Media"||device=="nas") {
								if(v['t']>($LastUpdateTime-82800)){
									date=new Date(v['t']*1000)
									hours=date.getHours()
									minutes="0"+date.getMinutes()
									html+='<br>'+hours+':'+minutes.substr(-2)
								} else html+='<br>'+formatDate(v['t'])
							}
							if(device=="water"){
								localStorage.setItem('watermode', v['m'])
							}
						}else{
							if (device=='lamp kast') {
								device='lamp_kast'
							} else if(device=="daikin") {
								if (v['s']=="Off") {
									elem=document.getElementById("daikin_kWh")
									elem.innerHTML=""
								}
								if (v['m']==1) localStorage.setItem('daikinmode', 'auto')
								else localStorage.setItem('daikinmode', 'man')
							} else if(device=="powermeter") {
								if (v['s']=="Off") {
									elem=document.getElementById("powermeter_kWh")
									elem.innerHTML=""
								}
							} else if(device=="wasdroger") {
								if (v['s']=="Off") {
									elem=document.getElementById("wasdroger_kWh")
									elem.innerHTML=""
								}
							}
							if(device=="powermeter"||device=="GroheRed") {
								localStorage.setItem(device+'mode', v['m'])
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="confirmPowerusage(\''+device+'\')">'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="confirmPowerusage(\''+device+'\')">'
							} else if(device=="langekast"||device=="daikin") {
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
							} else {
								if(v['s']=="On")html='<img src="/images/'+v['icon']+'_On.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\')"/>'
								else if(v['s']=="Off")html='<img src="/images/'+v['icon']+'_Off.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\')""/>'
								else html=''
							}
						}
						try{
							$('#'+device).html(html)
						}catch{}
					}catch{}
					localStorage.setItem(device, v['s'])
				}else if(v['dt']=="bose"){
					try{
						if(device=="bose101"||device=="bose106"){
							if(v['icon']=="Offline")html=''
							else{
								if(v['s']=="On")html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_On.png\" id=\""+device+"\" alt=\"bose\"></a>"
								else html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_Off.png\" id=\""+device+"\" alt=\"bose\"></a>"
							}
						}else{
							if(v['icon']=="Offline")html=''
							else{
								if(v['s']=="On")html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_On.png\" id=\""+device+"\" alt=\"bose\"></a>"
								else html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_Off.png\" id=\""+device+"\" alt=\"bose\"></a>"
							}
						}
						$('#'+device).html(html)
					}catch{}
//					try{
//						if(v['s']=="On"){$('#'+device).attr("src", "/images/bose_On.png");}
//						else if(v['s']=="Off"){$('#'+device).attr("src", "/images/bose_Off.png");}
//					}catch{}
					localStorage.setItem(device, v['s'])
				}else if(v['dt']=="dimmer"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem(device+'mode', v['m'])
					try{
						if(v['s']==0||v['s']=="Off") html='<img src="/images/light_Off.png" class="img100">'
						else html='<img src="/images/light_On.png" class="img100"><div class="fix center dimmerlevel"><font color="#000">'+v['s']+'</font></div>'
						if (device=="ledluifel") {
							luifel=localStorage.getItem("luifel")
							if (luifel=="0"&&v['s']==0)html=''
						} else if (device=="terras") {
							html+='terras'
						}
						$('#'+device).html(html)
					}catch{}
				}else if(v['dt']=="rollers"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem(device+'mode', v['m'])
					try{
						opts=v['icon'].split(",")
						stat=100 - v['s']
						if(stat<100)perc=(stat/100)*0.7
						else perc=1
						elem=document.getElementById(device)
						if(stat==0){
							nsize=0
							elem.classList.remove("yellow")
						}else if(stat>0){
							nsize=(opts[2]*perc)+8
							if(nsize>opts[2])nsize=opts[2]
							top=+opts[0] + +opts[2]-nsize
							elem.classList.add("yellow")
						}else{nsize=opts[2];}
						if(opts[3]=="P"){
							elem.style.top=top+'px'
							elem.style.left=opts[1]+'px'
							elem.style.width='8px'
							elem.style.height=nsize+'px'
						}else if(opts[3]=="L"){
							elem.style.top=opts[0]+'px'
							elem.style.left=opts[1]+'px'
							elem.style.width=nsize+'px'
							elem.style.height='9px'
						}
					}catch{}
					try{
						if(v['s']==100) html='<img src="/images/arrowgreendown.png" class="i48">'
						else if(v['s']==0) html='<img src="/images/arrowgreenup.png" class="i48">'
						else{
							html='<img src="/images/circlegrey.png" class="i48">'
							html+='<div class="fix center dimmerlevel" style="position:absolute;top:19px;left:1px;width:46px;letter-spacing:6;">'
							html+='<font size="5" color="#CCC">'
							html+=v['s']+'</font></div>'
						}
						html+='</div>'
						if(v['t']>($LastUpdateTime-82800)){
							date=new Date(v['t']*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							html+='<br><div id="t'+device+'">'+hours+':'+minutes.substr(-2)+'</div>'
						}else html+='<br><div id="t'+device+'">'+formatDate(v['t'])+'</div>';
						$('#R'+device).html(html)
					}catch{}
					if(localStorage.getItem('view')=='floorplanheating'){
						try{
							if(v['t']>($LastUpdateTime-82800)){
								date=new Date(v['t']*1000)
								hours=date.getHours()
								minutes="0"+date.getMinutes()
								document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
							}else{
								document.getElementById("t"+device).innerHTML=""
								document.getElementById("t"+device).innerHTML=formatDate(v['t'])
							}
						}catch{}
					}
				}else if(v['dt']=="pir"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem("tijd_"+device, v['t'])
					try{
						device=device.toString().replace("pir", "")
						element=document.getElementById("z"+device)
						if(device=="hall"){
							if(v['s']=="On"){
								document.getElementById("z"+device+"a").classList.add("motion")
								document.getElementById("z"+device+"b").classList.add("motion")
							}else{
								document.getElementById("z"+device+"a").classList.remove("motion")
								document.getElementById("z"+device+"b").classList.remove("motion")
							}
						}else if(device=="living"){
							if(v['s']=="On"){
								document.getElementById("z"+device).classList.add("motion")
								document.getElementById("z"+device+"b").classList.add("motion")
							}else{
								document.getElementById("z"+device).classList.remove("motion")
								document.getElementById("z"+device+"b").classList.remove("motion")
							}
						}else{
							if(v['s']=="On") element.classList.add("motion")
							else element.classList.remove("motion")
						}
						if(v['t']>($LastUpdateTime-82800)){
							date=new Date(v['t']*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("tpir"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("tpir"+device).innerHTML=""
					}catch{}
				}else if(v['dt']=="contact"){
					localStorage.setItem(device, v['s'])
					localStorage.setItem("tijd_"+device, v['t'])
					try{
						element=document.getElementById(device)
						if(v['s']=="Open") element.classList.add("red")
						else element.classList.remove("red")
						if(v['t']>($LastUpdateTime-82800)){
							date=new Date(v['t']*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("t"+device).innerHTML=formatdate(v['t'])
					}catch{}
				}else if(v['dt']=="thermometer"){
					localStorage.setItem(device, v['s'])
					try{
						var hoogte=v['s'] * 3
						if(hoogte>88)hoogte=88
						else if(hoogte<20)hoogte=20
						var top=91 - hoogte
						if(v['s'] >= 22){tcolor="F00";dcolor="55F";}
						else if(v['s'] >= 20){tcolor="D12";dcolor="44F";}
						else if(v['s'] >= 18){tcolor="B24";dcolor="33F";}
						else if(v['s'] >= 15){tcolor="93B";dcolor="22F";}
						else if(v['s'] >= 10){tcolor="64D";dcolor="11F";}
						else{tcolor="55F";dcolor="00F";}
						html='<div class="fix tmpbg" style="top:'+top+'px;left:8px;height:'+hoogte+'px;background:linear-gradient(to bottom, #'+tcolor+', #'+dcolor +');">'
						html+='</div>'
						if (device!='zolder_temp') {
							html+='<img src="/images/temp.png" height="100px" width="auto" alt="'+device+'">'
							html+='<div class="fix center" style="top:70px;left:5px;width:30px;" id="temp'+device+'">'
							html+=v['s'].toString().replace(/[.]/, ",")
							html+='<br><span style="color:'
							if(v['m']==100) html+='#000;background-color:#77F;padding:4px 1px;'
							else if(v['m']>=90) html+='#77F'
							else if(v['m']>=80) html+='#99F'
							else if(v['m']>=70) html+='#BBF'
							else if(v['m']<=45) html+='#FAA'
							else if(v['m']<=35) html+='#F88'
							html+='">'+v['m']+'%</span></div>'
						} else {
							html+='<img src="/images/temp.png" height="100px" width="auto" alt="'+device+'">'
							html+='<div class="fix center" style="top:73px;left:5px;width:30px;" id="temp'+device+'">'
							html+=v['s'].toString().replace(/[.]/, ",")
							html+='</div>'
						}
						document.getElementById(device).innerHTML=html
						if(v['icon']>=0.5)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="56px" width="15px"></div>'
						else if(v['icon']>=0.4)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="42px" width="15px"></div>'
						else if(v['icon']>=0.3)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="28px" width="15px"></div>'
						else if(v['icon']>=0.2)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="14px" width="15px"></div>'
						else if(v['icon']>=0.1)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendup.png" height="14px" width="15px"></div>'
						else if(v['icon']<=-0.5)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="56px" width="15px"></div>'
						else if(v['icon']<=-0.4)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="42px" width="15px"></div>'
						else if(v['icon']<=-0.3)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="28px" width="15px"></div>'
						else if(v['icon']<=-0.2)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="14px" width="15px"></div>'
						else if(v['icon']<=-0.1)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trenddown.png" height="14px" width="15px"></div>'
						else html=""
						document.getElementById(device).insertAdjacentHTML('beforeend', html)
					}catch{}
				}else if(v['dt']=="daikin"){
					localStorage.setItem(device, v['m'])
					localStorage.setItem(device+'_value', v['s'])
				}else if(v['dt']=="thermostaat"){
					heatingset=localStorage.getItem('heating')
					localStorage.setItem(device+'_mode', v['m'])
					localStorage.setItem(device+'_icon', v['icon'])
					localStorage.setItem(device, v['s'])
					localStorage.setItem("tijd_"+device, v['t'])
					try{
						temp=localStorage.getItem(device.toString().replace("_set", "_temp"))
						dif=temp-v['s']
						if(heatingset>=1||device=='badkamer_set'){
							if(dif>0.3)circle="hot"
							else if(dif<-0.3)circle="cold"
							else circle="grey"
							if(v['s']>=20)center="red"
							else if(v['s']>19)center="orange"
							else if(v['s']>14)center="grey"
							else center="blue"
						}else{
							if(device=='living_set')daikin=localStorage.getItem('daikinliving')
							else if(device=='kamer_set')daikin=localStorage.getItem('daikinkamer')
							else if(device=='alex_set')daikin=localStorage.getItem('daikinalex')
							if(daikin==4)circle="hot"
							else if(daikin==3)circle="cold"
							else circle="grey"
							if(daikin==4){
								if(v['s']>19)center="red"
								else if(v['s']>17.5)center="orange"
								else if(v['s']==10)center="grey"
								else center="blue"
							}else if(daikin==3){
								if(v['s']==33)center="grey"
								else if(v['s']>25)center="red"
								else if(v['s']>21)center="orange"
								else center="blue"
							}else center="grey"
						}
						elem=document.getElementById(device)
						html='<img src="/images/thermo'+circle+center+'.png" class="i48" alt="">'
						html+='<div class="fix center" style="top:35px;left:11px;width:26px;">'
						if(v['m']>0){
							html+='<font size="2" color="#222">'+v['s'].toString().replace(/[.]/, ",")+'</font></div>'
							html+='<div class="fix" style="top:2px;left:2px;z-index:-100;background:#b08000;width:44px;height:44px;border-radius:45px;"></div>'
						}else html+='<font size="2" color="#CCC">'+v['s'].toString().replace(/[.]/, ",")+'</font></div>'
						if(v['t']>($LastUpdateTime-82800)){
							date=new Date(v['t']*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							html+='<br><div id="t'+device+'">'+hours+':'+minutes.substr(-2)+'</div>'
						}else html+='<br><div id="t'+device+'">'+formatDate(v['t'])+'</div>';
					}catch{}
					try{

						// Daikin set point
						if(heatingset==-2||heatingset==1||heatingset==2||heatingset==3){
							if(device=='alex_set'||device=='living_set'||device=='kamer_set'){
								var obj=JSON.parse(v['icon'])
								html+='<br>'
								if(obj.power==0)html+='Off<br>'
								else{
									if(isNaN(obj.fan))html+=obj.set+'  '+obj.fan+'<br>'
									else{
										sp=['B','B','B',1,2,3,4,5]
										html+=obj.set+'  '+sp[obj.fan]+'<br>'
									}
								}
							}
						}
						document.getElementById(device).innerHTML=html
					}catch{}
				}else if(v['dt']=="SetPoint"){
					try{
						document.getElementById(device).innerHTML=v['s'] * 1
					}catch{}
				}else{
					//console.log(v['dt']+" -> "+device+" -> "+v['s']+" -> "+time+" -> "+v['m'])
				}
			})
			try{
				date=new Date($newTime*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				seconds="0"+date.getSeconds()
				$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
			}catch{}
			try{
				tijd=localStorage.getItem("tijd_water")
				elem=document.getElementById("tdwater")
				$color=~~($LastUpdateTime-tijd)
				if($color>255) $color=255
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if($LastUpdateTime-tijd<900)elem.style.color=$color
				else elem.style.color=null
			}catch{}
			try{
				tijd=localStorage.getItem("tijd_gas")
				elem=document.getElementById("tdgas")
				$color=~~($LastUpdateTime-tijd)
				if($color>255) $color=255
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if($LastUpdateTime-tijd<900)elem.style.color=$color
				else elem.style.color=null
			}catch{}
			var items=['living_set','badkamer_set','kamer_set','alex_set','brander','luifel']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(v)
					elem=document.getElementById("t"+v)
					date=new Date(tijd*1000)
					hours=date.getHours()
					minutes="0"+date.getMinutes()
					html=hours+':'+minutes.substr(-2)
					if(elem.innerHTML!=html&&tijd>$LastUpdateTime-82800)elem.innerHTML=html
					if(tijd>$LastUpdateTime-60)elem.style.color="#FF8800"
					else if(tijd>$LastUpdateTime-90)elem.style.color="#FFAA00"
					else if(tijd>$LastUpdateTime-300)elem.style.color="#FFCC00"
					else if(tijd>$LastUpdateTime-600)elem.style.color="#FFFF00"
					else if(tijd>$LastUpdateTime-7200)elem.style.color="#CCC"
					else if(tijd>$LastUpdateTime-14400)elem.style.color="#BBB"
					else if(tijd>$LastUpdateTime-21600)elem.style.color="#AAA"
					else if(tijd>$LastUpdateTime-28800)elem.style.color="#999"
					else if(tijd>$LastUpdateTime-36000)elem.style.color="#888"
					else if(tijd>$LastUpdateTime-82800)elem.style.color="#777"
					else {
						elem.style.color="#777"
						html=formatDate(tijd)
						if(elem.innerHTML!=html)elem.innerHTML=html
					}
				}catch{}
			})
			var items=['deurgarage','deurinkom','achterdeur','deurvoordeur','deurbadkamer','deurkamer','deurwaskamer','deuralex','deurwc','raamliving','raamkeuken','raamkamer','raamwaskamer','raamalex']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(items[i])
					elem=document.getElementById("t"+v)
					if($value=="Closed"){

						if($LastUpdateTime-tijd<900){
							$color=~~(($LastUpdateTime-tijd)/2)
							if($color>255) $color=255
							$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
							$color="#FF"+$color+"00"
							if(elem.style.color!=$color)elem.style.color=$color
						}else if($LastUpdateTime-tijd<1800&&elem.style.color!=$color)elem.style.color="#ddd"
						else if($LastUpdateTime-tijd<3600&&elem.style.color!=$color)elem.style.color="#ccc"
						else if($LastUpdateTime-tijd<7200&&elem.style.color!=$color)elem.style.color="#bbb"
						else if($LastUpdateTime-tijd<10800&&elem.style.color!=$color)elem.style.color="#aaa"
						else if($LastUpdateTime-tijd<14400&&elem.style.color!=$color)elem.style.color="#999"
						else if($LastUpdateTime-tijd<18000&&elem.style.color!=$color)elem.style.color="#888"
						else if($LastUpdateTime-tijd<82800&&elem.style.color!=$color)elem.style.color="#777"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#666")elem.style.color="#666"
						}
					}else{
						if(tijd>$LastUpdateTime-82800)elem.style.color=null
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
						}
						elem.style.color="#FFF"
					}
				}catch{}
			})
			var items=['pirliving','pirinkom','pirhall','pirkeuken','pirgarage']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(v)
					elem=document.getElementById("t"+v)
					if($value=="Off"){
						$color=~~(($LastUpdateTime-tijd)/1.5)
						if($color>255) $color=255
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if($LastUpdateTime-tijd<900&&elem.style.color!=$color)elem.style.color=$color
						else if($LastUpdateTime-tijd<1800&&elem.style.color!=$color)elem.style.color="#ddd"
						else if($LastUpdateTime-tijd<3600&&elem.style.color!=$color)elem.style.color="#ccc"
						else if($LastUpdateTime-tijd<7200&&elem.style.color!=$color)elem.style.color="#bbb"
						else if($LastUpdateTime-tijd<10800&&elem.style.color!=$color)elem.style.color="#aaa"
						else if($LastUpdateTime-tijd<14400&&elem.style.color!=$color)elem.style.color="#999"
						else if($LastUpdateTime-tijd<18000&&elem.style.color!=$color)elem.style.color="#888"
						else if($LastUpdateTime-tijd<82800&&elem.style.color!=$color)elem.style.color="#777"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#666")elem.style.color="#666"
						}
					}else{
						if(tijd>$LastUpdateTime-82800&&elem.style.color!="#FFF")elem.style.color="#FFF"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#FFF")elem.style.color="#FFF"
						}
					}
				}catch{}
			})
		},
	)
}
function ajaxmedia($ip){
	if(isSubmitting) {
		return
	}
	isSubmitting=true
	$.json('/ajax.php?media').then(
		function(response){
			try{
				up=human_kb(response['pfsense']['up']*1024)
				down=human_kb(response['pfsense']['down']*1024)
			}catch{}
			try{
				html='<small>&#x21e7;</small> '+up+'<br><small>&#x21e9;</small>'+down
				$("#pfsense").html(html)
			}catch{}
			 isSubmitting=false
	})
}
function ajaxbose($ip){
	try{clearInterval(myAjax);}catch{}
	if(isSubmitting) {
		return
	}
	isSubmitting=true
	$.ajax({
		url: '/ajax.php?bose='+$ip,
		dataType : 'json',
		async: true,
		defer: true,
		success: function(data){
			date=new Date(data["time"]*1000)
			hours=date.getHours()
			minutes="0"+date.getMinutes()
			seconds="0"+date.getSeconds()
			$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
			html=""
			if(data["nowplaying"]["@attributes"]["source"]!="STANDBY"){
//				console.log(data["nowplaying"])
				let volume=parseInt(data["volume"]["actualvolume"], 10)
				levels=[-10, -7, -4, -2, -1, 0, 1, 2, 4, 7, 10]
				html="<br>"
				levels.forEach(function(level){
					let newlevel=parseInt(volume+level)
					if(newlevel>=0){
						if(level!=0)html+='<button class="btn volume hover" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
						else html+='<button class="btn volume btna" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
					}
				})
				try{
					if($("#volume").html()!=html)$("#volume").html(html)
				}catch{}
				let bass=parseInt(data["bass"]["actualbass"], 10)
				levels=[-9, -8, -7, -6, -5, -4, -3, -2, -1, 0]
				html="<br>"
				levels.forEach(function(level){
					if(level!=bass)html+='<button class="btn volume hover" id="bass'+level+'" onclick="ajaxcontrolbose('+$ip+',\'bass\',\''+level+'\')">'+level+'</button>'
					else html+='<button class="btn volume btna" id="bass'+level+'" onclick="ajaxcontrolbose('+$ip+',\'bass\',\''+level+'\')">'+level+'</button>'
				})
				if($("#bass").html()!=html)$("#bass").html(html)

				if(data["nowplaying"]["@attributes"]["source"]=="SPOTIFY"){
					if($("#artist").html()!=data["nowplaying"]["artist"])$("#artist").html(data["nowplaying"]["artist"])
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])
				}else if(data["nowplaying"]["@attributes"]["source"]=="BLUETOOTH"){
					if($("#artist").html()!="Bluetooth")$("#artist").html("Bluetooth")
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])

				}else if(data["nowplaying"]["@attributes"]["source"]=="TUNEIN"){
					if($("#artist").html()!=data["nowplaying"]["artist"])$("#artist").html(data["nowplaying"]["artist"])
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])
					try{
						$("#source").html(data["nowplaying"]["@attributes"]["source"])
					}catch{}

				}else{
					try{
						$("#artist").html(data["nowplaying"]["@attributes"]["source"])
					}catch{}
				}
				img='None'
				try{
					img=data["nowplaying"]["art"].toString().replace("http://", "https://")
				}catch{}
				if(data["nowplaying"]["@attributes"]["source"]=="BLUETOOTH") html='<img src="/images/bluetooth.png" height="160px" width="auto" alt="bluetooth">'
				else if(img=='None')html=''
				else if(img.startsWith('http')) html='<img src="'+img+'" height="160px" width="auto" alt="Art">'
				else html=''
				try{
					elem=document.getElementById("art")
					if(elem.innerHTML!=html)elem.innerHTML=html
				}catch{}
				if(data["nowplaying"]["@attributes"]["source"]=="SPOTIFY"){
					html='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'prev\')">Prev</button>'
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'next\')">Next</button>'
				} else html=''
				if(data["nowplaying"]["ContentItem"]["itemName"]=='EDM - Part 1') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">1: EDM - Part 1</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">1: EDM - Part 1</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='EDM - Part 2') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">2: EDM - Part 2</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">2: EDM - Part 2</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Mix - Part 1') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">3: Mix - Part 1</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">3: Mix - Part 1</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Mix - Part 2') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">4: Mix - Part 2</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">4: Mix - Part 2</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Ballads + Pop') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">5: Ballads + Pop</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">5: Ballads + Pop</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Top') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">6: Top</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">6: Top</button>'
				html+='<br><br><button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'Off\');ajaxbose('+$ip+');myAjaxMedia=setInterval( function() { ajaxbose('+$ip+'); }, 500 );">Power Off</button><br><br>'
			}else{
				$("#artist").html("")
				$("#track").html("")
				$("#art").html("")
				$("#volume").html("")
				$("#bass").html("")
				html='<button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'On\')">Power On</button>'
			}
			if ($ip==101) {
				html+='<br>'
				if (data["bose101mode"]==1) {
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'0\')">Manual</button>'
					html+='<button class="btn b2 btna" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'1\')">Auto</button>'
				} else {
					html+='<button class="btn b2 btna" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'0\')">Manual</button>'
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'1\')">Auto</button>'
				}
			}
			if($("#power").html()!=html) $("#power").html(html)
			isSubmitting=false
		},
		error: function( data ) {
			isSubmitting=false
		},timeout: 2000
	})
}
function ajaxcontrol(device,command,action){
	$.get('/ajax.php?device='+device+'&command='+command+'&action='+action)
}
function ajaxcontrolbose(ip,command,action){
	$.get( '/ajax.php?boseip='+ip+'&command='+command+'&action='+action)
}
function floorplan(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplan')
	ajax(0)
	myAjax=$.setInterval(ajax,500)
	try{
		html='<div class="fix leftbuttons" id="heating" onclick="floorplanheating();"></div>'
		html+='<div class="fix z1 afval" id="gcal"></div>'
		html+='<div class="fix floorplan2icon" onclick="floorplanothers();"><img src="/images/plus.png" class="i60" alt="plus"></div>'
		html+='<div class="fix picam1" id="picam1"><a href=\'javascript:navigator_Go("picam1/index.php");\'><img src="/images/Camera.png" class="i48" alt="cam"></a></div>'
		html+='<div class="fix Weg" id="Weg"></div>'
		html+='<div class="fix z2" id="sirene"></div>'

		items=['Rbureel','RkeukenL','RkeukenR','Rliving','RkamerL','RkamerR','Rwaskamer','Ralex']
		items.forEach(function(item){html+='<div class="fix yellow" id="'+item+'"></div>';})

		items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','GroheRed', 'Grohered_kWh','dysonlader','kookplaat','daikin_kWh','powermeter_kWh','wasdroger_kWh','zliving','zlivingb','zkeuken','zinkom','zgarage','zhalla','zhallb','alwayson']
		items.forEach(function(item){html+='<div class="fix z0" id="'+item+'"></div>';})

		items=['living','badkamer','kamer','waskamer','alex','buiten']
		items.forEach(function(item){html+='<div class="fix" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})

		items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc']
		items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})

		items=['bose101','bose102','bose103','bose104','bose105','bose106','bose107']
		items.forEach(function(item){html+='<div class="fix" id="'+item+'"></div>';})

		items=['alex','eettafel','kamer','ledluifel','lichtbadkamer','terras','waskamer','zithoek','inkom','hall','wasbak','snijplank']
		items.forEach(function(item){html+='<div class="fix z" onclick="dimmer(\''+item+'\');" id="'+item+'"></div>';})

		items=['lamp kast','tuin','tuintafel','kristal','bureel','voordeur','wc','garage','garageled','zolderg','steenterras','poortrf','daikin','powermeter','langekast','waskamervuur1','waskamervuur2','kerstboom']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item.replace(" ", "_")+'"></div>';})

		html+='<div class="fix verbruik" onclick="location.href=\'https://verbruik.egregius.be/dag.php?Guy=on&reset\';" id="verbruik"><table><tr id="trelec"></tr><tr id="trzon"><td></td><td>Zon:</td><td id="zon"></td><td id="zonvandaag"></td></tr><tr id="trgas"></tr><tr id="trwater"></tr><tr id="trdgas"></tr><tr id="trdwater"></tr>'
		html+='</table></div><div class="fix z1 splitbill"><a href=\'javascript:navigator_Go("https://finance.egregius.be/splitbill/index.php");\'><img src="/images/euro.png" width="48px" height="48px" alt="Close"></a></div><div class="fix z1 HUM"><a href=\'javascript:navigator_Go("/hum.php");\'>HUM</a></div>'
//		$('#placeholder').html(html).fadeIn(3000)
		$('#placeholder').html(html)
	}catch{}
	sidebar()
}
function floorplanothers(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplanothers')
	ajax(0)
	ajaxmedia()
	myAjax=$.setInterval(ajax, 999)
	myAjaxmedia=$.setInterval(ajaxmedia, 1205)
	try{
		html='<div class="fix floorplan2icon" onclick="floorplan();"><img src="/images/close.png" class="i60" alt="plus"></div>'
		html+='<div class="fix z2" id="sirene"></div>'
		items=['eettafel','zithoek','wasbak','snijplank','inkom']
		items.forEach(function(item){html+='<div class="fix z" onclick="dimmer(\''+item+'\');" id="'+item+'"></div>';})
		items=['kristal','bureel','lamp kast','nas','Media','voordeur','wc']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item.replace(" ", "_")+'"></div>';})
		items=['bureel','keukenL','keukenR','living']
		items.forEach(function(item){html+='<div class="fix yellow" id="R'+item+'"></div>';})
		items=['zliving','zlivingb','zkeuken','zinkom']
		items.forEach(function(item){html+='<div class="fix z0" id="'+item+'"></div>';})
		items=['raamliving','raamkeuken','deurvoordeur','deurinkom','deurgarage','deurwc','bose101','bose105']
		items.forEach(function(item){html+='<div class="fix" id="'+item+'"></div>';})
		items=['buiten']
		items.forEach(function(item){html+='<div class="fix" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
		items=['auto','regenpomp']
		items.forEach(function(item){html+='<div class="fix z1 i48" style="width:70px;" id="'+item+'"></div>';})
		items=['tpirliving','tpirkeuken','tpirinkom','traamliving','traamkeuken','tdeurvoordeur','tdeurinkom','tdeurgarage','tdeurwc']
		items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})

		low=localStorage.getItem('regenputleeg')
		high=localStorage.getItem('regenputvol')
		if(low=='Off'&&high=='Off')html+='<div class="fix" id="regenput"><img src="/images/regenputrood.png"></div>'
		else if(low=='On'&&high=='Off')html+='<div class="fix" id="regenput"><img src="/images/regenputblauw.png"></div>'
		else if(low=='On'&&high=='On')html+='<div class="fix" id="regenput"><img src="/images/regenputgroen.png"></div>'
		html+='<div class="fix z1 center" style="top:820px;left:320px;"><a href=\'javascript:navigator_Go("https://home.egregius.be/log.php");\'><img src="/images/log.png" width="40px" height="40px"/><br>Log</a></div>'
		html+='<div class="fix z1 center" style="top:820px;left:400px;"><a href=\'javascript:navigator_Go("floorplan.cache.php?nicestatus");\'><img src="/images/log.png" width="40px" height="40px"/><br>Cache</a></div>'
		html+='<div class="fix z1 center" style="top:930px;left:80px;width:160px;height:60px!important"><button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'runsync\');floorplan();" class="btn b1">Run Syncs</button></div>'
		html+='<div class="fix z1 center" style="top:360px;left:300px;width:180px;height:60px!important"><button onclick="ajaxcontrol(\'MQTT\', \'MQTT\', \'MQTT\');floorplan();" class="btn b1">Restart MQTT&CRON</button></div>'
		html+='<div class="fix z1 center" style="top:930px;left:250px;width:160px;"><a href=\'javascript:aftellen();\' onclick="aftellen()" class="btn b1">Aftellen</a></div>'
		if (localStorage.getItem('Weg')==2)html+='<div class="fix z1 center" style="top:260px;left:407px;"><a href=\'javascript:ajaxcontrol("Weg","Weg","3");floorplan();\'><img src="images/Vacation.png" width="40px" height="40px"/><br>Vacation</a></div>'
		html+='<div class="fix blackmedia">'
		html+='<div class="fix" style="top:370px;left:0px;width:400px">'
		water=localStorage.getItem('water')
		if (water!='Unavailable') {
			items=['water']
			items.forEach(function(item){html+='<div class="fix z1 i48" style="width:70px;" id="'+item+'"></div>';})
			$mode=localStorage.getItem('watermode')
			if ($mode==300) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3 btna" id="water300">Water 5 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3" id="water300">Water 5 min</button>'
			if ($mode==360) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 360);" class="btn b3 btna" id="water360">Water 6 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 360);" class="btn b3" id="water360">Water 6 min</button>'
			if ($mode==420) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 420);" class="btn b3 btna" id="water420">Water 7 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 420);" class="btn b3" id="water420">Water 7 min</button>'
			if ($mode==480) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 480);" class="btn b3 btna" id="water480">Water 8 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 480);" class="btn b3" id="water480">Water 8 min</button>'
			if ($mode==1800) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3 btna" id="water1800">Water 30 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3" id="water1800">Water 30 min</button>'
			if ($mode==7200) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3 btna" id="water7200">Water 2 uur</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3" id="water7200">Water 2 uur</button>'
		}
		html+='</div></div><div class="fix" id="mediasidebar"><br><br><br><br><a href=\'javascript:navigator_Go("https://films.egregius.be/films.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Films</a><br><br><a href=\'javascript:navigator_Go("https://films.egregius.be/series.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Series</a><br><br><a href=\'javascript:navigator_Go("kodi.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Kodi<br>Control</a><br><br>'
		html+='<div class="fix" id="pfsense"></div>'
		$('#placeholder').html(html)
	}catch{}
	sidebar()
}
function floorplanheating(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplanheating')
	heatingset=localStorage.getItem('heating')
	daikinmode=localStorage.getItem('daikinmode')
	ajax(0)
	myAjax=$.setInterval(ajax,333)
	try{
		html='<div class="fix floorplan2icon" onclick="floorplan();"><img src="/images/close.png" class="i60" alt="plus"></div>'
		html+='<div class="fix leftbuttons" id="heating" onclick="floorplanheating();"></div>'
		html+='<div class="fix z2" id="sirene"></div>'
		html+='<div class="fix z2" id="daikincmpfreq"></div>'
		html+='<div class="fix z1" style="top:343px;left:415px;"><a href=\'javascript:navigator_Go("floorplan.doorsensors.php");\'><img src="/images/close.png" width="72px" height="72px" alt="Close"></a></div>'
		items=['GroheRed','kookplaat','daikin','waskamervuur1','waskamervuur2','wasdroger']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item+'"></div>';})
		items=['Rbureel','RkeukenL','RkeukenR','Rliving','RkamerL','RkamerR','Rwaskamer','Ralex']
		items.forEach(function(item){html+='<div class="fix yellow" id="'+item+'"></div>';})
		items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','Grohered_kWh','daikin_kWh','wasdroger_kWh','zliving','zlivingb','zkeuken','zinkom','zgarage','zhalla','zhallb','alwayson']
		items.forEach(function(item){html+='<div class="fix z0" id="'+item+'"></div>';})
		items=['living','badkamer','kamer','waskamer','alex','zolder','buiten']
		items.forEach(function(item){html+='<div class="fix" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
		items=['Rliving','Rbureel','RkeukenL','RkamerL','RkamerR','Rwaskamer','Ralex'];
		items.forEach(function(item){html+='<div class="fix z" onclick="roller(\''+item+'\');" id="R'+item+'"></div>';})
		items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc']
		items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})
		if(heatingset>1) items=['living','badkamer','kamer','alex']
		else if(heatingset==1&&daikinmode=='auto')items=['living','badkamer','kamer','alex']
		else if(heatingset==1&&daikinmode=='man')items=['badkamer']
		else if(heatingset==0)items=['badkamer','living','kamer','alex']
		else if(heatingset==-1)items=['badkamer','living','kamer','alex']
		else if(heatingset==-2&&daikinmode=='auto')items=['living','kamer','alex']
		items.forEach(function(item){html+='<div class="fix z2 '+item+'_set" onclick="setpoint(\''+item+'\');" id="'+item+'_set"></div>';})
		html+='<div class="fix z" onclick="roller(\'luifel\');" id="luifel"></div>'
		html+='<div class="fix z" id="bovenbeneden"><a href=\'javascript:navigator_Go("floorplan.daikinpowerusage.php");\' class="btn">Daikin Power Usage</a><br><br><button class="btn btnh" onclick="ajaxcontrol(\'tv\',\'roller\',\'tv\');initview();">TV</button> &nbsp; <button class="btn btnf" onclick="roller(\'Beneden\');">Beneden</button> &nbsp; <button class="btn btnf" onclick="roller(\'Boven\');">Boven</button></div>'
		html+='<div class="fix divsetpoints z"><table class="tablesetpoints">'
		if(heatingset>=2)html+='<tr><td id="brander"></td><td align="left" height="60" width="80px" style="line-height:18px">Brander<br><span id="tbrander"></span></td></tr>'
		html+='<tr id="trheating"></tr>'
		html+='</table></div>'
		html+='<div class="fix z1 HUM"><a href=\'javascript:navigator_Go("/hum.php");\'>HUM</a></div>'
		$('#placeholder').html(html)
	}catch{}
	sidebar()
}
function floorplanbose(){
	ajaxbose($ip)()
	myAjaxmedia=$.setInterval(function(){ajaxbose($ip);}, 333)
	try{
	}catch{}
}
function aftellen(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'aftellen')
	ajaxaftellen(0)
	myAjax=$.setInterval(ajaxaftellen, 1000)
//	try{
		html='<div class="fix z1" style="bottom:12px;left:12px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px"/></div>'
		html+='<style>table{width:100%}table,th,td{border: 1px solid gray;border-collapse: collapse;font-size:1.2em;padding:4px} th{text-align:center;width:40%}td{text-align:right;width:60%}</style>'
		html+='<div class="fix" style="top:0px;left:0px;width:99.75%;height:835px;background-color:#000;"><table>'
		items=['Gestopt','Alex','Kirby','Guy','Getrouwd','Samen','Xafax','Unixtimestamp']
		items.forEach(function(item){html+='<tr><th rowspan=7>'+item+'</th><td id="'+item+'sec"></td></tr><tr><td id="'+item+'min"></td></tr><tr><td id="'+item+'uur"></td></tr><tr><td id="'+item+'dag"></td></tr><tr><td id="'+item+'maand"></td></tr><tr><td id="'+item+'jaar"></td></tr><tr><td id="'+item+'jaartxt"></td></tr>';})
		html+='</table></div>'
		$('#placeholder').html(html)
//	}catch{}
}
function ajaxaftellen(){
	date=new Date()
	var d=[]
	d['Alex']=new Date('03/10/2016 19:30')
	d['Kirby']=new Date('01/22/1987')
	d['Guy']=new Date('03/23/1977')
	d['Getrouwd']=new Date('04/21/2018 10:30')
	d['Samen']=new Date('05/06/2013 18:00')
	d['Gestopt']=new Date('09/16/2024 14:33')
	d['Xafax']=new Date('12/01/2009 8:30')
	d['Unixtimestamp']=new Date('01/01/1970')
	items=['Alex','Kirby','Guy','Getrouwd','Samen','Xafax','Unixtimestamp']
	for (const x of items){
		const sec=Math.ceil((date-d[x])/1000)
		const min=Math.ceil(sec/60)
		const uur=Math.ceil(sec/(60*60))
		const dag=Math.ceil(sec/(60*60*24))
		const maand=Math.abs(sec/(60*60*24*30))
		const jaar=Math.abs(sec/(60*60*24*365))
		$("#"+x+"sec").html(sec.toLocaleString()+' sec')
		$("#"+x+"min").html(min.toLocaleString()+' min')
		$("#"+x+"uur").html(uur.toLocaleString()+' uur')
		$("#"+x+"dag").html(dag.toLocaleString()+' dagen')
		$("#"+x+"maand").html(maand.toLocaleString()+' maand')
		$("#"+x+"jaar").html(jaar.toLocaleString()+' jaar')
	}
	$("#Alexjaartxt").html(getAge('03/10/2016 19:30'))
	$("#Kirbyjaartxt").html(getAge('01/22/1987'))
	$("#Guyjaartxt").html(getAge('03/23/1977'))
	$("#Getrouwdjaartxt").html(getAge('04/21/2018 10:30'))
	$("#Samenjaartxt").html(getAge('05/06/2013 18:00'))
	$("#Xafaxjaartxt").html(getAge('12/01/2009 08:30'))

	items=['Gestopt']
	for (const x of items){
		const sec=Math.ceil((date-d[x])/1000)
		const sig=Math.floor(sec/4320)
		const eur=Math.floor(sig*(9.9/40))
		const dag=Math.ceil(sec/(60*60*24))
		const maand=Math.abs(sec/(60*60*24*30))
		const jaar=Math.abs(sec/(60*60*24*365))
		$("#"+x+"sec").html(sig.toLocaleString()+' sigaretten')
		$("#"+x+"min").html(eur.toLocaleString()+' €')
		$("#"+x+"jaartxt").html(getAge('09/16/2024 14:33'))
		$("#"+x+"dag").html(dag.toLocaleString()+' dagen')
		$("#"+x+"maand").html(maand.toLocaleString()+' maand')
		$("#"+x+"jaar").html(jaar.toLocaleString()+' jaar')
	}
}
function getAge(dateString) {
  var now=new Date()
  var today=new Date(now.getYear(),now.getMonth(),now.getDate())
  var yearNow=now.getYear()
  var monthNow=now.getMonth()
  var dateNow=now.getDate()
  var dob=new Date(dateString.substring(6,10),dateString.substring(0,2)-1,dateString.substring(3,5))
  var yearDob=dob.getYear()
  var monthDob=dob.getMonth()
  var dateDob=dob.getDate()
  var age={}
  var ageString=""
  var yearString=""
  var monthString=""
  var dayString=""
  yearAge=yearNow - yearDob
  if (monthNow >= monthDob) var monthAge=monthNow - monthDob
  else {
    yearAge--
    var monthAge=12 + monthNow -monthDob
  }

  if (dateNow >= dateDob) var dateAge=dateNow - dateDob
  else {
    monthAge--
    var dateAge=31 + dateNow - dateDob
    if (monthAge < 0) {
      monthAge=11
      yearAge--
    }
  }
  age={years: yearAge,months: monthAge,days: dateAge}
  if ( age.years > 1 ) yearString=" jaren"
  else yearString=" jaar"
  if ( age.months> 1 ) monthString=" maanden"
  else monthString=" maand"
  if ( age.days > 1 ) dayString=" dagen"
  else dayString=" dag"
  if ( (age.years > 0) && (age.months > 0) && (age.days > 0) ) ageString=age.years + yearString + ", " + age.months + monthString + ", en " + age.days + dayString
  else if ( (age.years == 0) && (age.months == 0) && (age.days > 0) ) ageString="Only " + age.days + dayString + " old!"
  else if ( (age.years > 0) && (age.months == 0) && (age.days == 0) ) ageString=age.years + yearString + " Happy Birthday!!"
  else if ( (age.years > 0) && (age.months > 0) && (age.days == 0) ) ageString=age.years + yearString + " en " + age.months + monthString
  else if ( (age.years == 0) && (age.months > 0) && (age.days > 0) ) ageString=age.months + monthString + " en " + age.days + dayString
  else if ( (age.years > 0) && (age.months == 0) && (age.days > 0) ) ageString=age.years + yearString + " en " + age.days + dayString
  else if ( (age.years == 0) && (age.months > 0) && (age.days == 0) ) ageString=age.months + monthString
  else ageString="Oops! Could not calculate age!"
  return ageString
}
function convertDateForIos(date) {
    var arr=date.split(/[- :]/);
    date=new Date(arr[0], arr[1]-1, arr[2], arr[3], arr[4], arr[5]);
    return date;
}
function sidebar(){
	try{
		html='<div class="fix weather"><a href=\'javascript:navigator_Go("https://www.buienradar.be/weer/beitem/be/2802384/14daagse");\'><img src="" alt="icon" id="icon"></a></div>'
		html+='<div class="fix center zon"><span id="maxtemp"></span><br><span id="mintemp"></span><br><a href=\'javascript:navigator_Go("https://www.buienradar.be/weer/Beitem/BE/2802384");\'><span id="buien"></span></a><br><span id="wind"></span><br><br><img src="images/sunrise.png" alt="sunrise"><br><small>&#x21e7;</small><span id="zonop"></span><br><small>&#x21e7;</small><span id="sunop"></span><br><small>&#x21e9;</small><span id="sunonder"></span><br><small>&#x21e9;</small><span id="zononder"></span><br><div id="uv"></div></div>'
		document.getElementById('placeholder').insertAdjacentHTML('beforeend', html)
	}catch{}
}
function pad(n, length){
	len=length - (''+n).length
	return (len>0 ? new Array(++len).join('0') : '')+n
}
function toggle_visibility(id){
	e=document.getElementById(id)
	if(e.style.display=='inherit') e.style.display='none'
	else e.style.display='inherit'
}
function fix(){
	var el=this
	var par=el.parentNode
	var next=el.nextSibling
	par.removeChild(el)
	setTimeout(function() {par.insertBefore(el, next);}, 0)
}
function human_kb(fileSizeInBytes) {
	var i=-1
	var byteUnits=[' kbps', ' Mbps', ' Gbps', ' Tbps', 'Pbps', 'Ebps', 'Zbps', 'Ybps']
	do {
		fileSizeInBytes=fileSizeInBytes / 1024
		i++
	} while (fileSizeInBytes > 1024)
	return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i]
}
function initview(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	for (var i=1; i < 99999; i++){try{window.clearInterval(i);}catch{};}
	view=localStorage.getItem('view')
	if(view=="floorplan")window["floorplan"]()
	else if(view=="floorplanheating")window["floorplanheating"]()
	else if(view=="floorplanothers")window["floorplanothers"]()
	else if(view=="floorplandaikin")window["floorplandaikin"]()
	else window["floorplan"]()
}
function setpoint(device){
	level=localStorage.getItem(device+'_set')
	try{
		icon=JSON.parse(localStorage.getItem(device+'_set_icon'))
	}catch{}
	daikin=JSON.parse(localStorage.getItem('daikin'+device+'_value'))
	heatingset=localStorage.getItem('heating')
	temp=localStorage.getItem(device+'_temp')
	$mode=localStorage.getItem(device+'_set_mode')
	html='<div class="fix dimmer" ><h2>'+device+' = '+temp+'°C</h2><h2>Set = '+level+'°C</h2>'
	if($mode==1||$mode==2){
		html+='<div class="fix btn btna" style="top:105px;left:25px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'1\');initview();"><br>Manueel</div>'
		html+='<div class="fix btn" style="top:105px;left:380px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'0\');initview();"><br>Auto</div>'
	}else{
		html+='<div class="fix btn" style="top:105px;left:25px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'1\');initview();"><br>Manueel</div>'
		html+='<div class="fix btn btna" style="top:105px;left:380px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'0\');initview();"><br>Auto</div>'
	}
	html+='<div class="fix z" style="top:230px;left:0px;width:100%">'
	if(device=='badkamer'){
		html+='<h4>Slow</h4>'
		temps=[16,16.5,17,17.5,18,18.5,19,20,20.5,21]
		temps.forEach(function(temp){
			if(level==temp&&$mode==1)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
		html+='<h4>Fast</h4>'
		temps.forEach(function(temp){
			if(level==temp&&$mode==2)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint2\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint2\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
	} else {
		if(heatingset>0){
			if(device=='living') temps=[10,17.2,17.4,17.6,17.8,18,18.1,18.2,18.3,18.4,18.5,18.6,18.7,18.8,18.9,19,19.1,19.2,19.3,19.4,19.5,19.6,19.7,19.8,19.9,20,20.1,20.2,20.3,20.4,20.5,20.6,20.7,20.8,20.9,21,21.1,21.2]
			else temps=[4,10,11,12,12.5,13,13.2,13.4,13.6,13.8,14,14.2,14.4,14.6,14.8,15,15.2,15.4,15.6,15.8,16,16.2,16.4,16.6,16.8,17,17.2,17.4,17.6,17.8,18,18.2,18.4,18.6,18.8]
		}else if(heatingset==-2){
			temps=[1,2,3,4,5,18,18.5,19,19.5,20,20.5,21,21.5,22,22.5,23,23.5,24,24.5,25,25.5,26,26.5,27,33,'D']
		}else{
			temps=['D']
		}
		temps.forEach(function(temp){
			if(level==temp)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
	}
	html+='</div><div class="fix z" style="bottom:12px;left:12px;" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)

}
function dimmer(device,floorplan='floorplan'){
	try{$.clearInterval(myAjax)}catch{}
	$mode=localStorage.getItem(device+'mode')
	current=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:220px">'
	if(current==0)html+='<h2>'+device+' Off</h2>'
	else html+='<h2>'+device+' '+current+' %</h2>'
	html+='<div class="fix z" style="top:80px;left:115px;" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'0\');initview();"><img src="images/light_Off.png" class="i90"></div>'
	html+='<div class="fix z" style="top:80px;left:305px;" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'100\');initview();"><img src="images/light_On.png" class="i90"></div>'
	html+='</div><div>'
	levels=[1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,22,24,26,28,30,32,35,40,45,50,55,60,65,70,75,80,85,90,95,100]
	if(levels.includes(parseInt(current))){}else{if(current>0&&current<100)levels.push(current);}
	levels.sort((a, b) => a - b)
	levels.forEach(function(level){
		if(current==level)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\''+level+'\');initview();">'+level+'</button>'
		else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\''+level+'\');initview();">'+level+'</button>'
	})
	html+='</div><div class="fix z" style="bottom:12px;left:12px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)
}
function roller(device,floorplan='floorplanheating'){
	try{$.clearInterval(myAjax)}catch{}
	current=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:220px">'
	if(current==0){
		if(device=='luifel')html+='<h2>'+device+' Dicht</h2><div class="fix" style="top:90px;left:385px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
		else html+='<h2>'+device+' Open</h2><div class="fix" style="top:90px;left:305px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
	} else if(current==100){
		if(device=='luifel')html+='<h2>'+device+' Open</h2><div class="fix" style="top:90px;left:35px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
		else html+='<h2>'+device+' Dicht</h2><div class="fix" style="top:90px;left:115px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
	} else if(device!='Beneden'&&device!='Boven') html+='<h2>'+device+' '+current+' %</h2>'
	else html+='<h2>'+device+'</h2>'
	if(device=='luifel'){
		mode=localStorage.getItem(device+'mode')
		if(mode==1)html+='<button class="btn btna b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'1\');initview();">Manueel</button><button class="btn b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'0\');initview();">Auto</button>'
		else html+='<button class="btn b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'1\');initview();">Manueel</button><button class="btn btna b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'0\');initview();">Auto</button>'
	}
	if(device=='luifel') html+='<div class="fix z" style="top:90px;left:35px;"><img src="images/arrowgreendown.png" class="i90" onclick="ajaxcontrol(\''+device+'\',\'roller\',\'100\');initview();"></div>'
	else html+='<div class="fix z" style="top:90px;left:115px;"><img src="images/arrowgreendown.png" class="i90" onclick="ajaxcontrol(\''+device+'\',\'roller\',\'100\');initview();"></div>'
	if(device=='luifel') html+='<div class="fix z" style="top:90px;left:385px;"><img src="images/arrowgreenup.png" class="i90"  onclick="ajaxcontrol(\''+device+'\',\'roller\',\'0\');initview();"></div>'
	else html+='<div class="fix z" style="top:90px;left:305px;"><img src="images/arrowgreenup.png" class="i90"  onclick="ajaxcontrol(\''+device+'\',\'roller\',\'0\');initview();"></div>'
	html+='</div><div class="fix z" style="top:250px;left:0px;">'
	levels=[5,10,15,20,25,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,85,90,95]
	if(levels.includes(parseInt(current))){}else{if(current>0&&current<100)levels.push(current);}
	levels.sort((a, b) => a - b)
	levels.forEach(function(level){
		if(current==level)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'roller\',\''+level+'\');initview();">'+level+'</button>'
		else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'roller\',\''+level+'\');initview();">'+level+'</button>'
	})
	html+='</div><div class="fix z" style="bottom:12px;left:12px;" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)
}
function Weg(){
	try{$.clearInterval(myAjax)}catch{}
	achterdeur=localStorage.getItem('achterdeur')
	raamliving=localStorage.getItem('raamliving')
	raamkeuken=localStorage.getItem('raamkeuken')
	bose103=localStorage.getItem('bose103')
	bose104=localStorage.getItem('bose104')
	bose105=localStorage.getItem('bose105')
	bose106=localStorage.getItem('bose106')
	bose107=localStorage.getItem('bose107')
	$Weg=localStorage.getItem('Weg')
	html='<div class="dimmer" ><div style="min-height:220px">'
	html+='<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	if(achterdeur=='Open'||raamliving=='Open'||raamhall=='Open')html+='<h1 style="font-size:4em">OPGELET!<br>'
	if(achterdeur=='Open')html+='Achterdeur OPEN<br>'
	if(raamliving=='Open')html+='Raam Living OPEN<br>'
	if(raamhall=='Open')html+='Raam Hall OPEN<br>'
	if(raamkeuken=='Open')html+='Raam Keuken OPEN<br>'
	if(bose103=='On')html+='Bose kamer aan<br>'
	if(bose104=='On')html+='Bose garage aan<br>'
	if(bose105=='On')html+='Bose keuken aan<br>'
	if(bose106=='On')html+='Bose Buiten20 aan<br>'
	if(bose107=='On')html+='Bose Buiten10 aan<br>'
	if(achterdeur=='Open'||raamliving=='Open'||raamhall=='Open'){
		html+='</h1>'
	}
	if ($Weg==0) {
		html+='<button class="btn huge2" style="display:inline-block;background-image:url(images/Weg.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol(\'Weg\',\'Weg\',\'2\');initview();">Weg</button>'
		html+='<button class="btn huge2" style="display:inline-block;background-image:url(images/Slapen.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol(\'Weg\',\'Weg\',\'1\');initview();">Slapen</button>'
	} else if ($Weg>=1) {
		ajaxcontrol('Weg','Weg',0)
		window.location.reload(true)
	}
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function heating(){
	$heating=localStorage.getItem('heating')
	html='<div class="dimmer" ><div style="min-height:220px">'
	html+='<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	if($heating==3) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');sleep(500);initview();">Gas heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');sleep(500);initview();">Gas heating</button>'
	if($heating==2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');sleep(500);initview();">Gas-Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');sleep(500);initview();">Gas-Airco heating</button>'
	if($heating==1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');sleep(500);initview();">Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');sleep(500);initview();">Airco heating</button>'
	if($heating==0) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');sleep(500);initview();">Neutral</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');sleep(500);initview();">Neutral</button>'
	if($heating==-1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');sleep(500);initview();">Passive cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');sleep(500);initview();">Passive cooling</button>'
	if($heating==-2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');sleep(500);initview();">Airco cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');sleep(500);initview();">Airco cooling</button>'
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function confirmSwitch(device){
	$value=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:220px">'
	html+='<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	html+='<br><h1>'+device+'='+$value+'</h1><br>'
	html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\');initview();">On</button>'
	html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\');initview();">Off</button>'
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function confirmPowerusage(device){
	$mode=localStorage.getItem(device+'mode')
	html='<div class="dimmer" ><div style="min-height:220px">'
	html+='<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	html+='<br><h1>'+device+'</h1><br>'
	levels=[3000,2600,2400,2000,0]
	levels.forEach(function(level){
		if ($mode==level) html+='<button class="btn btna huge7" onclick="ajaxcontrol(\''+device+'\',\'On\','+level+');initview();">'+level+'</button>'
		else html+='<button class="btn huge7" onclick="ajaxcontrol(\''+device+'\',\'On\','+level+');initview();">'+level+'</button>'
	})
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function formatDate(nowDate) {
	date=new Date(nowDate*1000)
	var day=date.getDate()
	var month=date.getMonth()+1
	return (day+'/'+month);
}
function sleep(millis) {
	var date=new Date()
	var curDate=null
	do {curDate=new Date()}
	while(curDate-date < millis)
}