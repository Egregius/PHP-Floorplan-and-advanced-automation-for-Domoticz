function navigator_Go(url){window.location.assign(url)}
var isSubmitting=false
function ajax(Update=$LastUpdateTime){
	$LastUpdateTime=localStorage.getItem("LastUpdateTime")
	$.json('/ajax.php?t='+Update).then(
		function(response){
			$newTime=parseInt(response['t'])
			if((response['t']-$LastUpdateTime)>1){
				console.log("Fetching everything: last=" + $LastUpdateTime + ' new=' + $newTime + ' diff=' + ($newTime-$LastUpdateTime))
				ajax(0)
			}
			localStorage.setItem("LastUpdateTime", response['t'])
			$.each(response, function(device, v, i){
				$value=v['s']
				$mode=v['m']
				type=v['dt']
				$icon=v['ic']
				time=v['t']
				date=new Date($newTime*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				seconds="0"+date.getSeconds()
				$time=hours+':'+minutes.substr(-2)+':'+seconds.substr(-2)
				if(device=="Weg"){
					localStorage.setItem("Weg", v['s'])
					try{
						html='<div class="fix z" onclick="Weg();">'
						if($value==0)html+='<img src="/images/Thuis.png" id="Weg">'
						else if($value==1)html+='<img src="/images/Slapen.png" id="Weg">'
						else if($value==2)html+='<img src="/images/Weg.png" id="Weg">'
						else if($value==3)html+='<img src="/images/Vacation.png" id="Weg">'
						html+='</div>'
						$("#Weg").html(html)
					}catch{}
					if($value==0){
						try{
							$("#zliving").removeClass("secured")
							$("#zkeuken").removeClass("secured")
							$("#zinkom").removeClass("secured")
						}catch{}
						try{
							$("#zgarage").removeClass("secured")
							$("#zhalla").removeClass("secured")
							$("#zhallb").removeClass("secured")
						}catch{}
					}else if($value==1){
						try{
							$("#zliving").addClass("secured")
							$("#zkeuken").addClass("secured")
							$("#zinkom").addClass("secured")
						}catch{}
						try{
							$("#zgarage").addClass("secured")
							$("#zhalla").removeClass("secured")
							$("#zhallb").removeClass("secured")
						}catch{}
					}else if($value>=2){
						try{
							$("#zliving").addClass("secured")
							$("#zkeuken").addClass("secured")
							$("#zinkom").addClass("secured")
						}catch{}
						try{
							$("#zgarage").addClass("secured")
							$("#zhalla").addClass("secured")
							$("#zhallb").addClass("secured")
						}catch{}
					}
				}else if(device=="winst"){
//					try{
						if($value>0) {
							v=Math.abs($value).toFixed(2)
							$("#winst").html('€ '+v.toString().replace(/[.]/, ","))
						}
//					}catch{}
				}else if(device=="minmaxtemp"){
					try{
						$("#mintemp").html("<small>&#x21e9;</small>"+$value.toString().replace(/[.]/, ",")+" &#8451;")
						if($value>30)$("#mintemp").css("color", "#F66")
						else if($value>28)$("#mintemp").css("color", "#F77")
						else if($value>26)$("#mintemp").css("color", "#F88")
						else if($value>24)$("#mintemp").css("color", "#F99")
						else if($value>22)$("#mintemp").css("color", "#FAA")
						else if($value>20)$("#mintemp").css("color", "#FBB")
						else if($value>18)$("#mintemp").css("color", "#FCC")
						else if($value<10)$("#mintemp").css("color", "#CCF")
						else if($value<8)$("#mintemp").css("color", "#BBF")
						else if($value<6)$("#mintemp").css("color", "#AAF")
						else if($value<4)$("#mintemp").css("color", "#99F")
						else if($value<2)$("#mintemp").css("color", "#88F")
						else if($value<0)$("#mintemp").css("color", "#77F")
						else $("#maxtemp").css("color",null)
						$("#maxtemp").html("<small>&#x21e7;</small>"+$mode.toString().replace(/[.]/, ",")+" &#8451;")
						if($mode>30)$("#maxtemp").css("color", "#F66")
						else if($mode>28)$("#maxtemp").css("color","#F77")
						else if($mode>26)$("#maxtemp").css("color","#F88")
						else if($mode>24)$("#maxtemp").css("color","#F99")
						else if($mode>22)$("#maxtemp").css("color","#FAA")
						else if($mode>20)$("#maxtemp").css("color","#FBB")
						else if($mode>18)$("#maxtemp").css("color","#FCC")
						else if($mode<10)$("#maxtemp").css("color","#CCF")
						else if($mode<8)$("#maxtemp").css("color","#BBF")
						else if($mode<6)$("#maxtemp").css("color","#AAF")
						else if($mode<4)$("#maxtemp").css("color","#99F")
						else if($mode<2)$("#maxtemp").css("color","#88F")
						else if($mode<0)$("#maxtemp").css("color","#77F")
						else $("#maxtemp").css("color",null)
					}catch{}
				}else if(device=="civil_twilight"){
					try {
						date=new Date($value*1000)
						hours=date.getHours()
						minutes="0"+date.getMinutes()
						$("#zonop").html(' '+hours+':'+minutes.substr(-2))
						date=new Date($mode*1000)
						hours=date.getHours()
						minutes="0"+date.getMinutes()
						$("#zononder").html(' '+hours+':'+minutes.substr(-2))
					}catch{}
				}else if(device=="Sun"){
					try {
						date=new Date($value*1000)
						hours=date.getHours()
						minutes="0"+date.getMinutes()
						$("#sunop").html(' '+hours+':'+minutes.substr(-2))
						date=new Date($mode*1000)
						hours=date.getHours()
						minutes="0"+date.getMinutes()
						$("#sunonder").html(' '+hours+':'+minutes.substr(-2))
					}catch{}
				}else if(device=="wind"){
					try{
						elem=document.getElementById("wind")
						elem.innerHTML=$value.toString().replace(/[.]/, ",")+"km/u"
						if($value>40)elem.style.color="#F66"
						else if($value>30)elem.style.color="#F77"
						else if($value>25)elem.style.color="#F88"
						else if($value>20)elem.style.color="#F99"
						else if($value>16)elem.style.color="#FAA"
						else if($value>12)elem.style.color="#FBB"
						else if($value>8)elem.style.color="#FCC"
						else elem.style.color=null
					}catch{}
				}else if(device=="icon"){
					try{
						$('#icon').attr("src", "/images/"+$value+".png")
					}catch{}
				}else if(device=="uv"){
					try{
						if($value==0)html=''
						else if($value<2)html='<font color="#99EE00">UV: '+$value.toString().replace(/[.]/, ",")+'</font>'
						else if($value<4)html='<font color="#99CC00">UV: '+$value.toString().replace(/[.]/, ",")+'</font>'
						else if($value<6)html='<font color="#FFCC00">UV: '+$value.toString().replace(/[.]/, ",")+'</font>'
						else if($value<8)html='<font color="#FF6600">UV: '+$value.toString().replace(/[.]/, ",")+'</font>'
						else html='<font color="#FF2200">UV: '+$value.toString().replace(/[.]/, ",")+'</font>'
						if($mode==0)html+=''
						else if($mode<2)html+='<br><font color="#99EE00">max: '+$mode.toString().replace(/[.]/, ",")+'</font>'
						else if($mode<4)html+='<br><font color="#99CC00">max: '+$mode.toString().replace(/[.]/, ",")+'</font>'
						else if($mode<6)html+='<br><font color="#FFCC00">max: '+$mode.toString().replace(/[.]/, ",")+'</font>'
						else if($mode<8)html+='<br><font color="#FF6600">max: '+$mode.toString().replace(/[.]/, ",")+'</font>'
						else html+='<br><font color="#FF2200">max: '+$mode.toString().replace(/[.]/, ",")+'</font>'
						$("#uv").html(html)
					}catch{}
				}else if(device=="el"){
					localStorage.setItem(device, $value)
					$zon=localStorage.getItem('zon')
					$delta=$value-$zon
					$color=~~(256-($value/31.24999945))
					$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
					$color="#FF"+$color+"00"
					if($delta>0){
						$dcolor=~~(256-($delta/31.25))
						$dcolor=('00' + $dcolor.toString(16).toUpperCase()).slice(-2)
						$dcolor="#FF"+$dcolor+"00"
					} else if($delta<0){
						$dcolor=~~(256-(-$delta/0.053710938))
						$dcolor=('00' + $dcolor.toString(16).toUpperCase()).slice(-2)
						$dcolor="#"+$dcolor+"FF"+$dcolor
					} else $color="00"
					try{
						$("#trelec").html("<td id='delta'>&Delta; "+$delta+" W</td><td>Elec:</td><td id='elec'>"+$value+" W</td><td id='elecvandaag'>"+$mode.toString().replace(/[.]/, ",")+" kWh</td>")
						document.getElementById("elec").style.color=$color
						$color=~~(256-(($mode-10)/0.1171875))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if($mode>10)document.getElementById("elecvandaag").style.color=$color
						else document.getElementById("elecvandaag").style.color=null
						document.getElementById("delta").style.color=$dcolor
						$("#alwayson").html($icon+"W")
					}catch{}
				}else if(device=="zon"){
					localStorage.setItem(device, $value)
					if($value>0){
						$color=$value/3.906250016
						$color=256-$color
						$color=~~$color
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#"+$color+"FF"+$color
					} else $color="#CCC"
					try{
						$("#zon").html($value+" W")
						document.getElementById("zon").style.color=$color
					}catch{}
				}else if(device=="zonvandaag"){
					try{
						zonvandaag=parseFloat(Math.round($value*10)/10).toFixed(1)
						$dcolor=~~(256-($mode/0.5))
						$dcolor=('00' + $dcolor.toString(16).toUpperCase()).slice(-2)
						$dcolor="#"+$dcolor+"FF"+$dcolor
						$("#zonvandaag").html(zonvandaag.toString().replace(/[.]/, ",")+" kWh")
						if($mode>0)document.getElementById("zonvandaag").style.color=$dcolor
						else document.getElementById("zonvandaag").style.color="#CCC"
					}catch{}
				}else if(device=="gasvandaag"){
					try{
						if($value>0){
							item=parseFloat(Math.round(($value/100)*100)/100).toFixed(2)
							$("#trgas").html('<td></td><td id="tdgas">Gas:</td><td colspan="2" id="tdgasvandaag">'+item.toString().replace(/[.]/, ",")+' m<sup>3</sup>')
							if(item>3){
								$color=~~(256-(item/0.078125))
								$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
								$color="#FF"+$color+"00"
							} else $color="#CCC"
							if($value>4)document.getElementById("tdgasvandaag").style.color=$color
							else document.getElementById("tdgasvandaag").style.color=null
						}else $("#trgas").html("")
					}catch{}
					localStorage.setItem("tijd_gas", time)
				}else if(device=="watervandaag"){
					try{
						if($value>0){
							item=$value
							$("#trwater").html('<td></td><td id="tdwater">Water:</td><td colspan="2" id="watervandaag">'+item.toString().replace(/[.]/, ",")+' L</sup>')
							if($value>1000)document.getElementById("watervandaag").style.color="#FF0000"
							else if($value>750)document.getElementById("watervandaag").style.color="#FF4400"
							else if($value>500)document.getElementById("watervandaag").style.color="#FF8800"
							else if($value>400)document.getElementById("watervandaag").style.color="#FFAA00"
							else if($value>300)document.getElementById("watervandaag").style.color="#FFCC00"
							else if($value>200)document.getElementById("watervandaag").style.color="#FFFF00"
							else document.getElementById("watervandaag").style.color=null
						}else $("#trwater").html("")
					}catch{}
					localStorage.setItem("tijd_water", time)
				}else if(device=="heating"){
					try{
					   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
						if($value==0)html+=''
						else if($value==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
						else if($value==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
						else if($value==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
						else if($value==2)html+='<img src="/images/AircoGas.png" class="i40" alt="AircoGas">'
						else if($value==3)html+='<img src="/images/GasAirco.png" class="i40" alt="GasAirco">'
						else if($value==4)html+='<img src="/images/Gas.png" class="i40" alt="Gas">'
						document.getElementById("heating").innerHTML=html
					}catch{}
					localStorage.setItem(device, $value)
					localStorage.setItem('tijd_'+device, time)
					try{
						html='<td>'
						if($value==0)html+='<img src="images/close.png" height="40" width="40px" onclick="heating();"></td><td align="left" height="40" width="40px" style="line-height:18px" onclick="heating()">Neutral</td>'
						else if($value==-2)html+='<img src="images/Cooling.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>cooling</td>'
						else if($value==-1)html+='<img src="images/Cooling_grey.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Passive<br>cooling</td>'
						else if($value==1)html+='<img src="images/Cooling_red.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>heating</td>'
						else if($value==2)html+='<img src="images/AircoGas.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco-Gas<br>heating</td>'
						else if($value==3)html+='<img src="images/GasAirco.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas-Airco<br>heating</td>'
						else if($value==4)html+='<img src="images/Gas.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas heating</td>'
						document.getElementById("trheating").innerHTML=html
					}catch{}
				}else if(device=="Grohered_kWh"){
					try{
						elem=$value.split(";")
						item=parseInt(Math.round(elem[0]))
						if(item==0)html=""
						else if(item>0&&item<11)html='<img src="images/plug_On.png" width="28px" height="auto" alt="">'
						else html='<img src="images/plug_Red.png" width="28px" height="auto" alt="">'
						document.getElementById("Grohered_kWh").innerHTML=html
					}catch{}
				}else if(device=="daikin_kWh"){
					try{
						value=$value.split(";")
						elem=document.getElementById("daikin_kWh")
						if(value[0]>0){
							html=Math.round(value[0])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(value[0]/10))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(value[0]>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="luchtdroger_kWh"){
					try{
						value=$value.split(";")
						elem=document.getElementById("luchtdroger_kWh")
						if(value[0]>0){
							html=Math.round(value[0])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(value[0]/10))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(value[0]>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="wasdroger_kWh"){
					try{
						value=$value.split(";")
						elem=document.getElementById("wasdroger_kWh")
						if(value[0]>0){
							html=Math.round(value[0])+" W"
							elem.innerHTML=html
						}
						$color=~~(256-(value[0]/10))
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if(value[0]>0)elem.style.color=$color
						else elem.style.color=null
					}catch{}
				}else if(device=="sirene"){
					try{
						if($value!="Off")html='<img src="images/alarm_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'sirene\',\'sw\',\'Off\')"><br>'+device
						else html=""
						document.getElementById("sirene").innerHTML=html
					}catch{}
				}else if(type=="smoke detector"){
					try{
						if($value!="Off")html='<img src="images/smoke_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'resetsecurity\',\'resetsecurity\',\'Off\')"><br>'+device
						else html=""
						document.getElementById("sirene").innerHTML=html
					}catch{}
				}else if(device=="brander"){
					localStorage.setItem(device, $value)
					localStorage.setItem('tijd_'+device, time)
					try{
						if($value=="Off")html='<img src="images/fire_Off.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'On\')">'
						else html='<img src="images/fire_On.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'Off\')">'
						document.getElementById("brander").innerHTML=html
					}catch{}
					heatingmode=localStorage.getItem('heating')
					try{
					   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
						if(heatingmode==0)html+=''
						else if(heatingmode==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
						else if(heatingmode==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
						else if(heatingmode==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
						else if(heatingmode==4){
							if($value=='On')html+='<img src="/images/fire_On.png" class="i40" id="branderfloorplan" alt="Gas">'
							else html+='<img src="/images/fire_Off.png" class="i40" alt="Gas">'
						}
						document.getElementById("heating").innerHTML=html
					}catch{}
					try{
						//BRANDERFLOORPLAN
						if(heatingmode==4){
							if($value=="Off") $('#branderfloorplan').attr("src", "/images/fire_Off.png")
							else $('#branderfloorplan').attr("src", "/images/fire_On.png")
						} else if(heatingmode==3){
							if($value=="Off")$('#branderfloorplan').attr("src", "/images/gaselec_Off.png")
							else $('#branderfloorplan').attr("src", "/images/gaselec_On.png")
						} else $('#branderfloorplan').attr("src", "")
					}catch{}
				}else if(device=="luifel"){
					localStorage.setItem(device, $value)
					localStorage.setItem('tijd_'+device, time)
					localStorage.setItem(device+'mode', $mode)
					try{
						if($value==0)html='<img src="/images/arrowgreenup.png" class="i60">'
						else if($value==100)html='<img src="/images/arrowgreendown.png" class="i60">'
						else html='<img src="/images/arrowdown.png" class="i60"><div class="fix center dimmerlevel" style="position:absolute;top:10px;left:-2px;width:70px;letter-spacing:4;"><font size="5" color="#CCC">'+$value+'</font> </div>'
						if($mode==1)html+='<div class="fix" style="top:2px;left:2px;z-index:-100;background:#fff7d8;width:56px;height:56px;border-radius:45px;"></div>'
						html+='<br><span id="tluifel"></span>'
						document.getElementById(device).innerHTML=html
					}catch{}
				}else if(device=="raamhall"){
					localStorage.setItem(device, $value)
					localStorage.setItem("tijd_"+device, time)
					try{
						element=document.getElementById(device)
						if($value=="Open") element.classList.add("red")
						else element.classList.remove("red")
						if(time>($LastUpdateTime-82800)){
							date=new Date(time*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("t"+device).innerHTML=""
					}catch{}
				}else if(device=="buien"){
					try{
						if(typeof $value !== 'undefined'){
							elem=document.getElementById('buien')
							elem.innerHTML="Buien: "+$value
							if($value>70)elem.style.color="#39F"
							else if($value>60)elem.style.color="#69F"
							else if($value>50)elem.style.color="#79F"
							else if($value>40)elem.style.color="#89F"
							else if($value>30)elem.style.color="#99F"
							else if($value>20)elem.style.color="#AAF"
							else if($value>10)elem.style.color="#BBD"
							else if($value>0)elem.style.color="#CCF"
							else elem.style.color=null
						}else{
							elem=document.getElementById('buien')
							elem.innerHTML="Buien: 0"
							elem.style.color="#888"
						}
					}catch{}
				} else if(device=="gcal"){
					localStorage.setItem(device, $value)
					try{
						if(typeof $mode !== 'undefined')document.getElementById("gcal").innerHTML=$mode
						else document.getElementById("gcal").innerHTML=''
					}catch{}
				}else if(type=="switch"){
					try{
						if(device=="dampkap"||device=="water"||device=="regenpomp"||device=="zwembadfilter"||device=="zwembadwarmte"||device=="auto"||device=="sony"||device=="tv"||device=="lgtv"||device=="nas"||device=="nvidia"){
							if(device=="sony"||device=="tv"||device=="lgtv"||device=="nvidia") {
								if($value=="On")html='<img src="/images/'+$icon+'_On.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
								else if($value=="Off")html='<img src="/images/'+$icon+'_Off.png" id="'+device+'" onclick="confirmSwitch(\''+device+'\')">'
							} else {
								if($value=="On")html='<img src="/images/'+$icon+'_On.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\')"/>'
								else if($value=="Off")html='<img src="/images/'+$icon+'_Off.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\')""/>'
							}
							html+='<br>'+device
							if(time>($LastUpdateTime-82800)){
								date=new Date(time*1000)
								hours=date.getHours()
								minutes="0"+date.getMinutes()
								html+='<br>'+hours+':'+minutes.substr(-2)
							} else html+='<br>'+formatDate(time)
							if(device=="water"){
								try{
									if($mode==300){
										document.getElementById("water300").classList.add("btna")
										document.getElementById("water1800").classList.remove("btna")
										document.getElementById("water7200").classList.remove("btna")
									}else if($mode==1800){
										document.getElementById("water300").classList.remove("btna")
										document.getElementById("water1800").classList.add("btna")
										document.getElementById("water7200").classList.remove("btna")
									}else if($mode==7200){
										document.getElementById("water300").classList.remove("btna")
										document.getElementById("water1800").classList.remove("btna")
										document.getElementById("water7200").classList.add("btna")
									}else{
										document.getElementById("water300").classList.remove("btna")
										document.getElementById("water1800").classList.remove("btna")
										document.getElementById("water7200").classList.remove("btna")
									}
								}catch{}
							}else if(localStorage.getItem('view')=='floorplan'&&device=="lgtv"){
								try{
									if($value=='On')$('#lgtvicon').attr("src", "/images/lgtv_On.png")
									else $('#lgtvicon').attr("src", "/images/lgtv_Off.png")
								}catch{}
							}else if(localStorage.getItem('view')=='floorplan'&&device=="tv"){
								try{
									if($value=='On') $('#tvicon').attr("src", "/images/tv_On.png")
									else $('#tvicon').attr("src", "/images/tv_Off.png")
								}catch{}
							}
						}else{
							if (device=='lamp kast')device='lamp_kast';
							else if(device=="daikin") {
								if ($value=="Off") {
									elem=document.getElementById("daikin_kWh")
									elem.innerHTML=""
								}
								if ($mode==1) localStorage.setItem('daikinmode', 'auto')
								else localStorage.setItem('daikinmode', 'man')
							} else if(device=="luchtdroger") {
								localStorage.setItem('luchtdroger_mode', $mode)
							} else if(device=="wasdroger") {
								if ($value=="Off") {
									elem=document.getElementById("wasdroger_kWh")
									elem.innerHTML=""
								}
							}
							if($value=="On")html='<img src="/images/'+$icon+'_On.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\')"/>'
							else if($value=="Off")html='<img src="/images/'+$icon+'_Off.png" id="'+device+'" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\')""/>'
						}
						try{
							$('#'+device).html(html)
						}catch{}
					}catch{}
					localStorage.setItem(device, $value)
				}else if(type=="bose"){
					try{
						if(device=="bose101"||device=="bose106"){
							if($icon=="Offline"){html="";}
							else{
								if($value=="On"){html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_On.png\" id=\""+device+"\" alt=\"bose\"></a>";}
								else{html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_Off.png\" id=\""+device+"\" alt=\"bose\"></a>";}
							}
						}else{
							if($icon=="Offline"){html="";}
							else{
								if($value=="On"){html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_On.png\" id=\""+device+"\" alt=\"bose\"></a>";}
								else{html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_Off.png\" id=\""+device+"\" alt=\"bose\"></a>";}
							}
						}
						$('#'+device).html(html)
					}catch{}
//					try{
//						if($value=="On"){$('#'+device).attr("src", "/images/bose_On.png");}
//						else if($value=="Off"){$('#'+device).attr("src", "/images/bose_Off.png");}
//					}catch{}
					localStorage.setItem(device, $value)
				}else if(type=="dimmer"){
					localStorage.setItem(device, $value)
					localStorage.setItem(device+'mode', $mode)
					try{
						if($value==0||$value=="Off") html='<img src="/images/light_Off.png" class="img100">'
						else html='<img src="/images/light_On.png" class="img100"><div class="fix center dimmerlevel"><font color="#000">'+$value+'</font></div>'
						if (device=="ledluifel") {
							luifel=localStorage.getItem("luifel")
							if (luifel=="0"&&$value==0)html=''
						}
						$('#'+device).html(html)
					}catch{}
				}else if(type=="rollers"){
					localStorage.setItem(device, $value)
					localStorage.setItem(device+'mode', $mode)
					try{
						opts=$icon.split(",")
						stat=100 - $value
						if(stat<100)perc=(stat/100)*0.7
						else perc=1
						elem=document.getElementById(device)
						if(stat==0){
							nsize=0
							elem.classList.remove("yellow")
						}else if(stat>0){
							nsize=(opts[2]*perc)+8
							if(nsize>opts[2])nsize=opts[2]
							top=+opts[0] + +opts[2]-nsize
							elem.classList.add("yellow")
						}else{nsize=opts[2];}
						if(opts[3]=="P"){
							elem.style.top=top+'px'
							elem.style.left=opts[1]+'px'
							elem.style.width='7px'
							elem.style.height=nsize+'px'
						}else if(opts[3]=="L"){
							elem.style.top=opts[0]+'px'
							elem.style.left=opts[1]+'px'
							elem.style.width=nsize+'px'
							elem.style.height='7px'
						}
					}catch{}
					try{
						if($value==100) html='<img src="/images/arrowgreendown.png" class="i48">'
						else if($value==0) html='<img src="/images/arrowgreenup.png" class="i48">'
						else{
							html='<img src="/images/circlegrey.png" class="i48">'
							html+='<div class="fix center dimmerlevel" style="position:absolute;top:17px;left:-2px;width:70px;letter-spacing:4;">'
							html+='<font size="5" color="#CCC">'
							html+=$value+'</font></div>'
						}
						html+='</div>'
						if(time>($LastUpdateTime-82800)){
							date=new Date(time*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							html+='<br><div id="t'+device+'">'+hours+':'+minutes.substr(-2)+'</div>'
						}else html+='<br><div id="t'+device+'">'+formatDate(time)+'</div>';
						$('#R'+device).html(html)
					}catch{}
					if(localStorage.getItem('view')=='floorplanheating'){
						try{
							if(time>($LastUpdateTime-82800)){
								date=new Date(time*1000)
								hours=date.getHours()
								minutes="0"+date.getMinutes()
								document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
							}else{
								document.getElementById("t"+device).innerHTML=""
								document.getElementById("t"+device).innerHTML=formatDate(time)
							}
						}catch{}
					}
				}else if(type=="pir"){
					localStorage.setItem(device, $value)
					localStorage.setItem("tijd_"+device, time)
					try{
						device=device.toString().replace("pir", "")
						element=document.getElementById("z"+device)
						if(device=="hall"){
							if($value=="On"){
								document.getElementById("z"+device+"a").classList.add("motion")
								document.getElementById("z"+device+"b").classList.add("motion")
							}else{
								document.getElementById("z"+device+"a").classList.remove("motion")
								document.getElementById("z"+device+"b").classList.remove("motion")
							}
						}else{
							if($value=="On") element.classList.add("motion")
							else element.classList.remove("motion")
						}
						if(time>($LastUpdateTime-82800)){
							date=new Date(time*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("tpir"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("tpir"+device).innerHTML=""
					}catch{}
				}else if(type=="contact"){
					localStorage.setItem(device, $value)
					localStorage.setItem("tijd_"+device, time)
					try{
						element=document.getElementById(device)
						if($value=="Open") element.classList.add("red")
						else element.classList.remove("red")
						if(time>($LastUpdateTime-82800)){
							date=new Date(time*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
						}else document.getElementById("t"+device).innerHTML=formatdate(time)
					}catch{}
				}else if(type=="thermometer"){
					localStorage.setItem(device, $value)
					try{
						var hoogte=$value * 3
						if(hoogte>88)hoogte=88
						else if(hoogte<20)hoogte=20
						var top=91 - hoogte
						if($value >= 22){tcolor="F00";dcolor="55F";}
						else if($value >= 20){tcolor="D12";dcolor="44F";}
						else if($value >= 18){tcolor="B24";dcolor="33F";}
						else if($value >= 15){tcolor="93B";dcolor="22F";}
						else if($value >= 10){tcolor="64D";dcolor="11F";}
						else{tcolor="55F";dcolor="00F";}
						html='<div class="fix tmpbg" style="top:'+top+'px;left:8px;height:'+hoogte+'px;background:linear-gradient(to bottom, #'+tcolor+', #'+dcolor +');">'
						html+='</div>'
						if (device!='zolder_temp') {
							html+='<img src="/images/temp.png" height="100px" width="auto" alt="'+device+'">'
							html+='<div class="fix center" style="top:70px;left:5px;width:30px;" id="temp'+device+'">'
							html+=$value.toString().replace(/[.]/, ",")
							html+='<br>'+$mode+'%</div>'
						} else {
							html+='<img src="/images/temp.png" height="100px" width="auto" alt="'+device+'">'
							html+='<div class="fix center" style="top:73px;left:5px;width:30px;" id="temp'+device+'">'
							html+=$value.toString().replace(/[.]/, ",")
							html+='</div>'
						}
						document.getElementById(device).innerHTML=html
						if($icon>=0.5)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="56px" width="15px"></div>'
						else if($icon>=0.4)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="42px" width="15px"></div>'
						else if($icon>=0.3)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="28px" width="15px"></div>'
						else if($icon>=0.2)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendred.png" height="14px" width="15px"></div>'
						else if($icon>=0.1)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendup.png" height="14px" width="15px"></div>'
						else if($icon<=-0.5)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="56px" width="15px"></div>'
						else if($icon<=-0.4)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="42px" width="15px"></div>'
						else if($icon<=-0.3)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="28px" width="15px"></div>'
						else if($icon<=-0.2)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trendblue.png" height="14px" width="15px"></div>'
						else if($icon<=-0.1)html='<div class="fix" style="top:10px;left:13px;"><img src="/images/trenddown.png" height="14px" width="15px"></div>'
						else html=""
						document.getElementById(device).insertAdjacentHTML('beforeend', html)
					}catch{}
				}else if(type=="daikin"){
					localStorage.setItem(device, $mode)
					localStorage.setItem(device+'_value', $value)
				}else if(type=="thermostaat"){
					heatingset=localStorage.getItem('heating')
					localStorage.setItem(device+'_mode', $mode)
					localStorage.setItem(device+'_icon', $icon)
					localStorage.setItem(device, $value)
					localStorage.setItem("tijd_"+device, time)
					try{
						temp=localStorage.getItem(device.toString().replace("_set", "_temp"))
						dif=temp-$value
						if(heatingset>=1||device=='badkamer_set'){
							if(dif>0.3)circle="hot"
							else if(dif<-0.3)circle="cold"
							else circle="grey"
							if($value>=20)center="red"
							else if($value>19)center="orange"
							else if($value>14)center="grey"
							else center="blue"
						}else{
							if(device=='living_set')daikin=localStorage.getItem('daikinliving')
							else if(device=='kamer_set')daikin=localStorage.getItem('daikinkamer')
							else if(device=='alex_set')daikin=localStorage.getItem('daikinalex')
							if(daikin==4)circle="hot"
							else if(daikin==3)circle="cold"
							else circle="grey"
							if(daikin==4){
								if($value>19)center="red"
								else if($value>17.5)center="orange"
								else if($value==10)center="grey"
								else center="blue"
							}else if(daikin==3){
								if($value==33)center="grey"
								else if($value>25)center="red"
								else if($value>21)center="orange"
								else center="blue"
							}else center="grey"
						}
						elem=document.getElementById(device)
						html='<img src="/images/thermo'+circle+center+'.png" class="i48" alt="">'
						html+='<div class="fix center" style="top:35px;left:11px;width:26px;">'
						if($mode>0){
							html+='<font size="2" color="#222">'+$value.toString().replace(/[.]/, ",")+'</font></div>'
							html+='<div class="fix" style="top:2px;left:2px;z-index:-100;background:#b08000;width:44px;height:44px;border-radius:45px;"></div>'
						}else html+='<font size="2" color="#CCC">'+$value.toString().replace(/[.]/, ",")+'</font></div>'
						if(time>($LastUpdateTime-82800)){
							date=new Date(time*1000)
							hours=date.getHours()
							minutes="0"+date.getMinutes()
							html+='<br><div id="t'+device+'">'+hours+':'+minutes.substr(-2)+'</div>'
						}else html+='<br><div id="t'+device+'">'+formatDate(time)+'</div>';
						// Daikin set point
						if(heatingset==-2||heatingset==1||heatingset==2||heatingset==3){
							if(device=='alex_set'||device=='living_set'||device=='kamer_set'){
								var obj=JSON.parse($icon)
								html+='<br>'
								if(obj.power==0)html+='Off<br>'
								else{
									if(isNaN(obj.fan))html+=obj.set+'  '+obj.fan+'<br>'
									else{
										sp=['B','B','B',1,2,3,4,5]
										html+=obj.set+'  '+sp[obj.fan]+'<br>'
									}
								}
							}
						}
						document.getElementById(device).innerHTML=html
					}catch{}
				}else if(type=="SetPoint"){
					try{
						document.getElementById(device).innerHTML=$value * 1
					}catch{}
				}else{
					//console.log(type+" -> "+device+" -> "+$value+" -> "+time+" -> "+$mode)
				}
			})
			try{
				date=new Date($newTime*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				seconds="0"+date.getSeconds()
				$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
			}catch{}
			try{
				tijd=localStorage.getItem("tijd_water")
				elem=document.getElementById("tdwater")
				$color=~~($LastUpdateTime-tijd)
				if($color>255) $color=255
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if($LastUpdateTime-tijd<900)elem.style.color=$color
				else elem.style.color=null
			}catch{}
			try{
				tijd=localStorage.getItem("tijd_gas")
				elem=document.getElementById("tdgas")
				$color=~~($LastUpdateTime-tijd)
				if($color>255) $color=255
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if($LastUpdateTime-tijd<900)elem.style.color=$color
				else elem.style.color=null
			}catch{}
			var items=['living_set','badkamer_set','kamer_set','alex_set','zolder_set','brander','luifel']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(v)
					elem=document.getElementById("t"+v)
					date=new Date(tijd*1000)
					hours=date.getHours()
					minutes="0"+date.getMinutes()
					html=hours+':'+minutes.substr(-2)
					if(elem.innerHTML!=html&&tijd>$LastUpdateTime-82800)elem.innerHTML=html
					if(tijd>$LastUpdateTime-60)elem.style.color="#FF8800"
					else if(tijd>$LastUpdateTime-90)elem.style.color="#FFAA00"
					else if(tijd>$LastUpdateTime-300)elem.style.color="#FFCC00"
					else if(tijd>$LastUpdateTime-600)elem.style.color="#FFFF00"
					else if(tijd>$LastUpdateTime-7200)elem.style.color="#CCC"
					else if(tijd>$LastUpdateTime-14400)elem.style.color="#BBB"
					else if(tijd>$LastUpdateTime-21600)elem.style.color="#AAA"
					else if(tijd>$LastUpdateTime-28800)elem.style.color="#999"
					else if(tijd>$LastUpdateTime-36000)elem.style.color="#888"
					else if(tijd>$LastUpdateTime-82800)elem.style.color="#777"
					else {
						elem.style.color="#777"
						html=formatDate(tijd)
						if(elem.innerHTML!=html)elem.innerHTML=html
					}
				}catch{}
			})
			var items=['deurgarage','deurinkom','achterdeur','poort','deurvoordeur','deurbadkamer','deurkamer','deurwaskamer','deuralex','deurwc','raamliving','raamkeuken','raamkamer','raamwaskamer','raamalex']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(items[i])
					elem=document.getElementById("t"+v)
					if($value=="Closed"){

						if($LastUpdateTime-tijd<900){
							$color=~~(($LastUpdateTime-tijd)/2)
							if($color>255) $color=255
							$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
							$color="#FF"+$color+"00"
							if(elem.style.color!=$color)elem.style.color=$color
						}else if($LastUpdateTime-tijd<1800&&elem.style.color!=$color)elem.style.color="#ddd"
						else if($LastUpdateTime-tijd<3600&&elem.style.color!=$color)elem.style.color="#ccc"
						else if($LastUpdateTime-tijd<7200&&elem.style.color!=$color)elem.style.color="#bbb"
						else if($LastUpdateTime-tijd<10800&&elem.style.color!=$color)elem.style.color="#aaa"
						else if($LastUpdateTime-tijd<14400&&elem.style.color!=$color)elem.style.color="#999"
						else if($LastUpdateTime-tijd<18000&&elem.style.color!=$color)elem.style.color="#888"
						else if($LastUpdateTime-tijd<82800&&elem.style.color!=$color)elem.style.color="#777"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#666")elem.style.color="#666"
						}
					}else{
						if(tijd>$LastUpdateTime-82800)elem.style.color=null
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
						}
						elem.style.color="#FFF"
					}
				}catch{}
			})
			var items=['pirliving','pirinkom','pirhall','pirkeuken','pirgarage']
			$.each(items, function(i, v){
				try{
					tijd=localStorage.getItem("tijd_"+v)
					$value=localStorage.getItem(v)
					elem=document.getElementById("t"+v)
					if($value=="Off"){
						$color=~~(($LastUpdateTime-tijd)/1.5)
						if($color>255) $color=255
						$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
						$color="#FF"+$color+"00"
						if($LastUpdateTime-tijd<900&&elem.style.color!=$color)elem.style.color=$color
						else if($LastUpdateTime-tijd<1800&&elem.style.color!=$color)elem.style.color="#ddd"
						else if($LastUpdateTime-tijd<3600&&elem.style.color!=$color)elem.style.color="#ccc"
						else if($LastUpdateTime-tijd<7200&&elem.style.color!=$color)elem.style.color="#bbb"
						else if($LastUpdateTime-tijd<10800&&elem.style.color!=$color)elem.style.color="#aaa"
						else if($LastUpdateTime-tijd<14400&&elem.style.color!=$color)elem.style.color="#999"
						else if($LastUpdateTime-tijd<18000&&elem.style.color!=$color)elem.style.color="#888"
						else if($LastUpdateTime-tijd<82800&&elem.style.color!=$color)elem.style.color="#777"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#666")elem.style.color="#666"
						}
					}else{
						if(tijd>$LastUpdateTime-82800&&elem.style.color!="#FFF")elem.style.color="#FFF"
						else {
							html=formatDate(tijd)
							if(elem.innerHTML!=html)elem.innerHTML=html
							if(elem.style.color!="#FFF")elem.style.color="#FFF"
						}
					}
				}catch{}
			})
		},
	)
}
function ajaxmedia($ip){
	if(isSubmitting) {
		return
	}
	isSubmitting=true
	$.json('/ajax.php?media').then(
		function(response){
			try{
				up=human_kb(response['pfsense']['up']*1024)
				down=human_kb(response['pfsense']['down']*1024)
			}catch{}
			sony=localStorage.getItem('sony')
			tv=localStorage.getItem('tv')
			lgtv=localStorage.getItem('lgtv')
			try{
				html='<small>&#x21e7;</small> '+up+'<br><small>&#x21e9;</small>'+down
				$("#pfsense").html(html)
			}catch{}
			try{
				html=''
				if(sony=='Off'&&lgtv=='Off')html+='<button class="btn b1 btnh100" onclick="ajaxcontrol(\'media\', \'media\', \'On\')">Media Power On</button>'
				if(lgtv=='On') html+='<br><br><button onclick="ajaxcontrol(\'lgtv\', \'pause\', \'\')" class="btn b2 btnh75">Pause</button><button onclick="ajaxcontrol(\'lgtv\', \'play\', \'\')" class="btn b2 btnh75">Play</button>'
				if(sony=='On') {
					html+='<br><br><button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'-1\')" class="btn b2 btnh75">-1</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+1\')" class="btn b2 btnh75">+1</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\-2\')" class="btn b2 btnh75">-2</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+2\')" class="btn b2 btnh75">+2</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\-4\')" class="btn b2 btnh75">-4</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+4\')" class="btn b2 btnh75">+4</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\-6\')" class="btn b2 btnh75">-6</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+6\')" class="btn b2 btnh75">+6</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\-8\')" class="btn b2 btnh75">-8</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+8\')" class="btn b2 btnh75">+8</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'-10\')" class="btn b2 btnh75">-10</button>'
					html+='<button onclick="ajaxcontrol(\'lgtv\', \'volume\', \'\+10\')" class="btn b2 btnh75">+10</button>'
				}
				if($("#media").html()!=html)$("#media").html(html)
			 }catch{}
			 isSubmitting=false
	})
}
function ajaxbose($ip){
	try{clearInterval(myAjax);}catch{}
	if(isSubmitting) {
		return
	}
	isSubmitting=true
	$.ajax({
		url: '/ajax.php?bose='+$ip,
		dataType : 'json',
		async: true,
		defer: true,
		success: function(data){
			date=new Date(data["time"]*1000)
			hours=date.getHours()
			minutes="0"+date.getMinutes()
			seconds="0"+date.getSeconds()
			$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
			html=""
			if(data["nowplaying"]["@attributes"]["source"]!="STANDBY"){
				console.log(data["nowplaying"])
				let volume=parseInt(data["volume"]["actualvolume"], 10)
				levels=[-10, -7, -4, -2, -1, 0, 1, 2, 4, 7, 10]
				html="<br>"
				levels.forEach(function(level){
					let newlevel=parseInt(volume+level)
					if(newlevel>=0){
						if(level!=0)html+='<button class="btn volume hover" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
						else html+='<button class="btn volume btna" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
					}
				})
				try{
					if($("#volume").html()!=html)$("#volume").html(html)
				}catch{}
				let bass=parseInt(data["bass"]["actualbass"], 10)
				levels=[-9, -8, -7, -6, -5, -4, -3, -2, -1, 0]
				html="<br>"
				levels.forEach(function(level){
					if(level!=bass)html+='<button class="btn volume hover" id="bass'+level+'" onclick="ajaxcontrolbose('+$ip+',\'bass\',\''+level+'\')">'+level+'</button>'
					else html+='<button class="btn volume btna" id="bass'+level+'" onclick="ajaxcontrolbose('+$ip+',\'bass\',\''+level+'\')">'+level+'</button>'
				})
				if($("#bass").html()!=html)$("#bass").html(html)

				if(data["nowplaying"]["@attributes"]["source"]=="SPOTIFY"){
					if($("#artist").html()!=data["nowplaying"]["artist"])$("#artist").html(data["nowplaying"]["artist"])
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])
				}else if(data["nowplaying"]["@attributes"]["source"]=="BLUETOOTH"){
					if($("#artist").html()!="Bluetooth")$("#artist").html("Bluetooth")
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])

				}else if(data["nowplaying"]["@attributes"]["source"]=="TUNEIN"){
					if($("#artist").html()!=data["nowplaying"]["artist"])$("#artist").html(data["nowplaying"]["artist"])
					if($("#track").html()!=data["nowplaying"]["track"])$("#track").html(data["nowplaying"]["track"])
					try{
						$("#source").html(data["nowplaying"]["@attributes"]["source"])
					}catch{}

				}else{
					try{
						$("#artist").html(data["nowplaying"]["@attributes"]["source"])
					}catch{}
				}
				img='None'
				try{
					img=data["nowplaying"]["art"].toString().replace("http://", "https://")
				}catch{}
				if(data["nowplaying"]["@attributes"]["source"]=="BLUETOOTH") html='<img src="/images/bluetooth.png" height="160px" width="auto" alt="bluetooth">'
				else if(img=='None')html=''
				else if(img.startsWith('http')) html='<img src="'+img+'" height="160px" width="auto" alt="Art">'
				else html=''
				try{
					elem=document.getElementById("art")
					if(elem.innerHTML!=html)elem.innerHTML=html
				}catch{}
				if(data["nowplaying"]["@attributes"]["source"]=="SPOTIFY"){
					html='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'prev\')">Prev</button>'
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'next\')">Next</button>'
				} else html=''
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Kalkbrenner') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">1: Kalkbrenner</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">1: Kalkbrenner</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Tiësto') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">2: Tiësto</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">2: Tiësto</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='EDM') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">3: EDM</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">3: EDM</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='EDM + DJ\'s') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">4: EDM + DJ\'s</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">4: EDM + DJ\'s</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='EDM + DJ\'s + Pop') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">5: EDM + DJ\'s + Pop</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">5: EDM + DJ\'s + Pop</button>'
				if(data["nowplaying"]["ContentItem"]["itemName"]=='Mix') html+='<button class="btn btna b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">6: Mix</button>'
				else html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">6: Mix</button>'
				html+='<br><br><button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'Off\');ajaxbose('+$ip+');myAjaxMedia=setInterval( function() { ajaxbose('+$ip+'); }, 500 );">Power Off</button><br><br>'
			}else{
				$("#artist").html("")
				$("#track").html("")
				$("#art").html("")
				$("#volume").html("")
				$("#bass").html("")
				html='<button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'On\')">Power On</button>'
			}
			if ($ip==101) {
				html+='<br><br>'
				if (data["bose101mode"]==1) {
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'0\')">Manual</button>'
					html+='<button class="btn b2 btna" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'1\')">Auto</button>'
				} else {
					html+='<button class="btn b2 btna" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'0\')">Manual</button>'
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'mode\',\'1\')">Auto</button>'
				}
			}
			if($("#power").html()!=html) $("#power").html(html)
			isSubmitting=false
		},
		error: function( data ) {
			isSubmitting=false
		},timeout: 2000
	})
}
function ajaxcontrol(device,command,action){
	$.get('/ajax.php?device='+device+'&command='+command+'&action='+action)
}
function ajaxcontrolbose(ip,command,action){
	$.get( '/ajax.php?boseip='+ip+'&command='+command+'&action='+action)
}
function floorplan(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplan')
	ajax(0)
	myAjax=$.setInterval(ajax,500)
	try{
		html='<div class="fix leftbuttons" id="heating" onclick="floorplanheating();"></div><div class="fix" id="clock" onclick="floorplan();"></div>'
		html+='<div class="fix z1 afval" id="gcal"></div>'
		html+='<div class="fix floorplan2icon" onclick="floorplanothers();"><img src="/images/plus.png" class="i60" alt="plus"></div>'
		html+='<div class="fix picam1" id="picam1"><a href=\'javascript:navigator_Go("picam1/index.php");\'><img src="/images/Camera.png" class="i48" alt="cam"></a></div>'
		html+='<div class="fix Weg" id="Weg"></div>'
		html+='<div class="fix z2" id="sirene"></div>'
		html+='<div class="fix z0 crypto" id="crypto" onclick="location.href=\'https://finance.egregius.be/crypto/tabel.php\';"><img src="/images/bitvavo.png" class="i20" alt="crypto"><span id="winst"></span></div>'
		items=['alex','eettafel','kamer','ledluifel','lichtbadkamer','terras','waskamer','zithoek','zolder','inkom','hall','wasbak','snijplank']
		items.forEach(function(item){html+='<div class="fix z" onclick="dimmer(\''+item+'\');" id="'+item+'"></div>';})
		items=['lamp kast'/*,'badkamervuur1','badkamervuur2'*/,'tuin','kristal','bureel','voordeur','wc','garage','garageled','zolderg','poortrf','daikin','luchtdroger','luchtdroger1','luchtdroger2','wasdroger','waskamervuur1']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item.replace(" ", "_")+'"></div>';})
		items=['Rbureel','RkeukenL','RkeukenR','Rliving','RkamerL','RkamerR','Rwaskamer','Ralex']
		items.forEach(function(item){html+='<div class="fix yellow" id="'+item+'"></div>';})
		items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','poort','GroheRed', 'Grohered_kWh','kookplaat', 'daikin_kWh','luchtdroger_kWh','wasdroger_kWh','zliving','zkeuken','zinkom','zgarage','zhalla','zhallb','alwayson']
		items.forEach(function(item){html+='<div class="fix z0" id="'+item+'"></div>';})
		items=['living','badkamer','kamer','waskamer','alex','buiten']
		items.forEach(function(item){html+='<div class="fix" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
		items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tpoort','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc']
		items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})
		items=['bose101','bose102','bose103','bose104','bose105','bose106','bose107']
		items.forEach(function(item){html+='<div class="fix" id="'+item+'"></div>';})
		html+='<div class="fix verbruik" onclick="location.href=\'https://verbruik.egregius.be/dag.php?Guy=on&reset\';" id="verbruik"><table><tr id="trelec"></tr><tr id="trzon"><td></td><td>Zon:</td><td id="zon"></td><td id="zonvandaag"></td></tr><tr id="trgas"></tr><tr id="trwater"></tr><tr id="trdgas"></tr><tr id="trdwater"></tr>'
		html+='</table></div><div class="fix z1" style="top:775px;left:325px;"><a href=\'javascript:navigator_Go("https://finance.egregius.be/splitbill/index.php");\'><img src="/images/euro.png" width="48px" height="48px" alt="Close"></a></div><div class="fix z1" style="top:804px;left:220px;"><a href=\'javascript:navigator_Go("/hum.php");\'>HUM</a></div>'
		$('#placeholder').html(html).fadeIn(3000)
	}catch{}
	sidebar()
}
function floorplanheating(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplanheating')
	heatingset=localStorage.getItem('heating')
	daikinmode=localStorage.getItem('daikinmode')
	ajax(0)
	myAjax=$.setInterval(ajax,500)
	try{
		html='<div class="fix floorplan2icon" onclick="floorplanothers();"><img src="/images/plus.png" class="i60" alt="plus"></div>'
		html+='<div class="fix" id="clock" onclick="floorplanheating();"></div>'
		html+='<div class="fix z2" id="sirene"></div>'
		html+='<div class="fix z2" id="daikincmpfreq"></div>'
		html+='<div class="fix z1" style="top:5px;left:5px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
		html+='<div class="fix z1" style="top:290px;left:415px;"><a href=\'javascript:navigator_Go("floorplan.doorsensors.php");\'><img src="/images/close.png" width="72px" height="72px" alt="Close"></a></div>'
		items=[/*'badkamervuur1','badkamervuur2'*/,'GroheRed','kookplaat','daikin','luchtdroger','luchtdroger1','luchtdroger2','wasdroger','waskamervuur1']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item+'"></div>';})
		items=['Rbureel','RkeukenL','RkeukenR','Rliving','RkamerL','RkamerR','Rwaskamer','Ralex']
		items.forEach(function(item){html+='<div class="fix yellow" id="'+item+'"></div>';})
		items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','poort','Grohered_kWh','daikin_kWh','luchtdroger_kWh','wasdroger_kWh','zliving','zkeuken','zinkom','zgarage','zhalla','zhallb','alwayson']
		items.forEach(function(item){html+='<div class="fix z0" id="'+item+'"></div>';})
		items=['living','badkamer','kamer','waskamer','alex','zolder','buiten']
		items.forEach(function(item){html+='<div class="fix" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
		items=['Rliving','Rbureel','RkeukenL','RkamerL','RkamerR','Rwaskamer','Ralex'];
		items.forEach(function(item){html+='<div class="fix z" onclick="roller(\''+item+'\');" id="R'+item+'"></div>';})
		items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tpoort','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc']
		items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})
		if(heatingset>1) {
			items=['living','badkamer','kamer','alex','zolder']
	    }
		else if(heatingset==1&&daikinmode=='auto')items=['living','badkamer','kamer','alex']
		else if(heatingset==1&&daikinmode=='man')items=['badkamer']
		else if(heatingset==0)items=['badkamer']
		else if(heatingset==-2&&daikinmode=='auto')items=['living','kamer','alex']
		if(heatingset!=-1)items.forEach(function(item){html+='<div class="fix z2 '+item+'_set" onclick="setpoint(\''+item+'\');" id="'+item+'_set"></div>';})
		html+='<div class="fix z" onclick="roller(\'luifel\');" id="luifel"></div>'
		html+='<div class="fix z" id="bovenbeneden"><a href=\'javascript:navigator_Go("floorplan.daikinpowerusage.php");\' class="btn">Daikin Power Usage</a><br><br><button class="btn btnh" onclick="ajaxcontrol(\'tv\',\'roller\',\'tv\');initview();">TV</button> &nbsp; <button class="btn btnf" onclick="roller(\'Beneden\');">Beneden</button> &nbsp; <button class="btn btnf" onclick="roller(\'Boven\');">Boven</button></div>'
		html+='<div class="fix divsetpoints z"><table class="tablesetpoints">'
		if(heatingset>=2)html+='<tr><td id="brander"></td><td align="left" height="60" width="80px" style="line-height:18px">Brander<br><span id="tbrander"></span></td></tr>'
		html+='<tr id="trheating"></tr>'
		html+='</table></div>'
		html+='<div class="fix z1" style="top:804px;left:220px;"><a href=\'javascript:navigator_Go("/hum.php");\'>HUM</a></div>'
		$('#placeholder').html(html)
	}catch{}
	sidebar()
}
function floorplanmedia(){
	try{$.clearInterval(myAjax)}catch{}
	//for (var i=1; i < 99999; i++){try{window.clearInterval(i);}catch{};}
	localStorage.setItem('view', 'floorplanmedia')
	ajax(0)
	ajaxmedia()
	myAjax=$.setInterval(ajax, 999)
	myAjaxmedia=$.setInterval(ajaxmedia, 1205)
	try{
		tv=localStorage.getItem("tv")
		lgtv=localStorage.getItem("lgtv")
		//html='<div class="fix lamp_kast z1 i48" id="lamp kast"></div>'
		html='<div class="fix" id="clock" onclick="floorplanmedia();"></div>'
		html+='<div class="fix z1" style="top:5px;left:5px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
		html+='<div class="fix z2" id="sirene"></div>'
		items=['eettafel','zithoek','wasbak','snijplank']
		items.forEach(function(item){html+='<div class="fix z" onclick="dimmer(\''+item+'\');" id="'+item+'"></div>';})
		items=['kristal','bureel','lamp kast','sony','nas','nvidia','tv','lgtv']
		items.forEach(function(item){html+='<div class="fix z1 i48" id="'+item.replace(" ", "_")+'"></div>';})
		items=['bureel','keukenL','keukenR','living']
		items.forEach(function(item){html+='<div class="fix yellow" id="R'+item+'"></div>';})
		items=['living','keuken','inkom']
		items.forEach(function(item){html+='<div class="fix z0" id="z'+item+'"></div>';})
		items=['raamliving','raamkeuken','deurvoordeur','deurinkom','deurgarage','deurwc']
		items.forEach(function(item){html+='<div class="fix" id="'+item+'"></div>';})
		html+='<div class="fix blackmedia" id="media"></div>'
		html+='<div class="fix" id="mediasidebar"><br><br><br><br><a href=\'javascript:navigator_Go("https://films.egregius.be/films.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Films</a><br><br><a href=\'javascript:navigator_Go("https://films.egregius.be/series.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Series</a><br><br><a href=\'javascript:navigator_Go("kodi.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Kodi<br>Control</a><br><br>'
		html+='<div id="playpause"></div>'
		html+='<div id="pfsense"></div></div>'
		$('#placeholder').html(html)
	}catch{}
}
function floorplanbose(){
	ajaxbose($ip)()
	myAjaxmedia=$.setInterval(function(){ajaxbose($ip);}, 500)
	try{
	}catch{}
}
function floorplanothers(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'floorplanothers')
	ajax(0)
	myAjax=$.setInterval(ajax, 500)
	try{
		html='<div class="fix floorplan2icon" onclick="floorplan();"><img src="/images/plus.png" class="i60" alt="plus"></div>'
		html+='<div class="fix" id="clock" onclick="floorplanothers();"></div>'
		html+='<div class="fix z1" style="top:5px;left:5px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px"/></div>'
		items=['auto','water','regenpomp','zwembadfilter','zwembadwarmte','dampkap']
		items.forEach(function(item){html+='<div class="fix z1 i48" style="width:70px;" id="'+item+'"></div>';})
		low=localStorage.getItem('regenputleeg')
		high=localStorage.getItem('regenputvol')
		if(low=='Off'&&high=='Off')html+='<div class="fix" id="regenput"><img src="/images/regenputrood.png"></div>'
		else if(low=='On'&&high=='Off')html+='<div class="fix" id="regenput"><img src="/images/regenputblauw.png"></div>'
		else if(low=='On'&&high=='On')html+='<div class="fix" id="regenput"><img src="/images/regenputgroen.png"></div>'
		html+='<div class="fix z1 center" style="top:500px;left:120px;"><a href=\'javascript:navigator_Go("logs.php");\'><img src="/images/log.png" width="40px" height="40px"/><br>Log</a></div>'
		html+='<div class="fix z1 center" style="top:500px;left:220px;"><a href=\'javascript:navigator_Go("floorplan.cache.php?nicestatus");\'><img src="/images/log.png" width="40px" height="40px"/><br>Cache</a></div>'
		html+='<div class="fix z1 center" style="top:500px;left:320px;"><a href=\'javascript:navigator_Go("Smappee.php");\'><img src="/images/log.png" width="40px" height="40px"/><br>Smappee</a></div>'
		html+='<div class="fix z1 center" style="top:500px;left:420px;"><a href=\'javascript:navigator_Go("floorplan.ontime.php");\'><img src="/images/log.png" width="40px" height="40px"/><br>On-Time</a></div>'
		html+='<div class="fix z1 center" style="top:600px;left:0px;width:245px;"><button onclick="ajaxcontrol(\'fetch\', \'fetch\', \'fetch\');floorplan();" class="btn b1">Fetch Domoticz</button></div>'
		html+='<div class="fix z1 center" style="top:600px;left:250px;width:245px;height:60px!important"><button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'runsync\');floorplan();" class="btn b1">Run Syncs</button></div>'
		html+='<div class="fix z1 center" style="top:680px;left:0px;width:245px;"><a href=\'javascript:navigator_Go("floorplan.ontime.kWh_Meter.php");\' class="btn b1">kWh_Meter</a></div>'
		html+='<div class="fix z1 center" style="top:680px;left:250px;width:245px;"><a href=\'javascript:aftellen();\' onclick="aftellen()" class="btn b1">Aftellen</a></div>'
		if (localStorage.getItem('Weg')==2)html+='<div class="fix z1 center" style="top:260px;left:407px;"><a href=\'javascript:ajaxcontrol("Weg","Weg","3");floorplan();\'><img src="images/Vacation.png" width="40px" height="40px"/><br>Vacation</a></div>'
		html+='<div class="fix blackmedia">'
		html+='<div class="fix" style="top:180px;left:0px;width:400px">'
		water=localStorage.getItem('water')
		water$mode=localStorage.getItem('watermode')
		if(water=='On'){
			if ($mode==300) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3 btna" id="water300">Water 5 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3" id="water300">Water 5 min</button>'
			if ($mode==1800) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3 btna" id="water1800">Water 30 min</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3" id="water1800">Water 30 min</button>'
			if ($mode==7200) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3 btna" id="water7200">Water 2 uur</button>'
			else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3" id="water7200">Water 2 uur</button>'
		}else{
			html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3" id="water300">Water 5 min</button>'
			html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3" id="water1800">Water 30 min</button>'
			html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3" id="water7200">Water 2 uur</button>'
		}
		html+='<div class="fix z1 bottom" style="right:0px"><form method="POST"><input type="hidden" name="username" $value="logout"/><input type="submit" name="logout" value="Logout" class="btn" style="padding:0px;margin:0px;width:90px;height:35px;"/></form><br/><br/></div>'
		$('#placeholder').html(html)
	}catch{}
}
function aftellen(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	localStorage.setItem('view', 'aftellen')
	ajaxaftellen(0)
	myAjax=$.setInterval(ajaxaftellen, 1000)
//	try{
		html='<div class="fix z1" style="top:5px;left:5px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px"/></div>'
		html+='<style>table{width:100%}table,th,td{border: 1px solid gray;border-collapse: collapse;font-size:1.2em;padding:4px} th{text-align:center;width:40%}td{text-align:right;width:60%}</style>'
		html+='<div class="fix" style="top:0px;left:0px;width:99.75%;height:835px;background-color:#000;"><table>'
		items=['Gestopt','Alex','Kirby','Guy','Getrouwd','Samen','Xafax','Unixtimestamp']
		items.forEach(function(item){html+='<tr><th rowspan=7>'+item+'</th><td id="'+item+'sec"></td></tr><tr><td id="'+item+'min"></td></tr><tr><td id="'+item+'uur"></td></tr><tr><td id="'+item+'dag"></td></tr><tr><td id="'+item+'maand"></td></tr><tr><td id="'+item+'jaar"></td></tr><tr><td id="'+item+'jaartxt"></td></tr>';})
		html+='</table></div>'
		$('#placeholder').html(html)
//	}catch{}
}
function ajaxaftellen(){
	date=new Date()
	var d=[]
	d['Alex']=new Date('03/10/2016 19:30')
	d['Kirby']=new Date('01/22/1987')
	d['Guy']=new Date('03/23/1977')
	d['Getrouwd']=new Date('04/21/2018 10:30')
	d['Samen']=new Date('05/06/2013 18:00')
	d['Gestopt']=new Date('07/02/2022 8:15')
	d['Xafax']=new Date('12/01/2009 8:30')
	d['Unixtimestamp']=new Date('01/01/1970')
	items=['Alex','Kirby','Guy','Getrouwd','Samen','Xafax','Unixtimestamp']
	for (const x of items){
		const sec=Math.ceil((date-d[x])/1000)
		const min=Math.ceil(sec/60)
		const uur=Math.ceil(sec/(60*60))
		const dag=Math.ceil(sec/(60*60*24))
		const maand=Math.abs(sec/(60*60*24*30))
		const jaar=Math.abs(sec/(60*60*24*365))
		$("#"+x+"sec").html(sec.toLocaleString()+' sec')
		$("#"+x+"min").html(min.toLocaleString()+' min')
		$("#"+x+"uur").html(uur.toLocaleString()+' uur')
		$("#"+x+"dag").html(dag.toLocaleString()+' dagen')
		$("#"+x+"maand").html(maand.toLocaleString()+' maand')
		$("#"+x+"jaar").html(jaar.toLocaleString()+' jaar')
	}
	$("#Alexjaartxt").html(getAge('03/10/2016 19:30'))
	$("#Kirbyjaartxt").html(getAge('01/22/1987'))
	$("#Guyjaartxt").html(getAge('03/23/1977'))
	$("#Getrouwdjaartxt").html(getAge('04/21/2018 10:30'))
	$("#Samenjaartxt").html(getAge('05/06/2013 18:00'))
	$("#Xafaxjaartxt").html(getAge('12/01/2009 08:30'))

	items=['Gestopt']
	for (const x of items){
		const sec=Math.ceil((date-d[x])/1000)
		const sig=Math.floor(sec/4320)
		const eur=Math.floor(sig*(9.9/40))
		const dag=Math.ceil(sec/(60*60*24))
		const maand=Math.abs(sec/(60*60*24*30))
		const jaar=Math.abs(sec/(60*60*24*365))
		$("#"+x+"sec").html(sig.toLocaleString()+' sigaretten')
		$("#"+x+"min").html(eur.toLocaleString()+' €')
		$("#"+x+"jaartxt").html(getAge('07/02/2022 8:15'))
		$("#"+x+"dag").html(dag.toLocaleString()+' dagen')
		$("#"+x+"maand").html(maand.toLocaleString()+' maand')
		$("#"+x+"jaar").html(jaar.toLocaleString()+' jaar')
	}
}
function getAge(dateString) {
  var now=new Date()
  var today=new Date(now.getYear(),now.getMonth(),now.getDate())
  var yearNow=now.getYear()
  var monthNow=now.getMonth()
  var dateNow=now.getDate()
  var dob=new Date(dateString.substring(6,10),dateString.substring(0,2)-1,dateString.substring(3,5))
  var yearDob=dob.getYear()
  var monthDob=dob.getMonth()
  var dateDob=dob.getDate()
  var age={}
  var ageString=""
  var yearString=""
  var monthString=""
  var dayString=""
  yearAge=yearNow - yearDob
  if (monthNow >= monthDob) var monthAge=monthNow - monthDob
  else {
    yearAge--
    var monthAge=12 + monthNow -monthDob
  }

  if (dateNow >= dateDob) var dateAge=dateNow - dateDob
  else {
    monthAge--
    var dateAge=31 + dateNow - dateDob
    if (monthAge < 0) {
      monthAge=11
      yearAge--
    }
  }
  age={years: yearAge,months: monthAge,days: dateAge}
  if ( age.years > 1 ) yearString=" jaren"
  else yearString=" jaar"
  if ( age.months> 1 ) monthString=" maanden"
  else monthString=" maand"
  if ( age.days > 1 ) dayString=" dagen"
  else dayString=" dag"
  if ( (age.years > 0) && (age.months > 0) && (age.days > 0) ) ageString=age.years + yearString + ", " + age.months + monthString + ", en " + age.days + dayString
  else if ( (age.years == 0) && (age.months == 0) && (age.days > 0) ) ageString="Only " + age.days + dayString + " old!"
  else if ( (age.years > 0) && (age.months == 0) && (age.days == 0) ) ageString=age.years + yearString + " Happy Birthday!!"
  else if ( (age.years > 0) && (age.months > 0) && (age.days == 0) ) ageString=age.years + yearString + " en " + age.months + monthString
  else if ( (age.years == 0) && (age.months > 0) && (age.days > 0) ) ageString=age.months + monthString + " en " + age.days + dayString
  else if ( (age.years > 0) && (age.months == 0) && (age.days > 0) ) ageString=age.years + yearString + " en " + age.days + dayString
  else if ( (age.years == 0) && (age.months > 0) && (age.days == 0) ) ageString=age.months + monthString
  else ageString="Oops! Could not calculate age!"
  return ageString
}
function convertDateForIos(date) {
    var arr=date.split(/[- :]/);
    date=new Date(arr[0], arr[1]-1, arr[2], arr[3], arr[4], arr[5]);
    return date;
}
function sidebar(){
	try{
		tv=localStorage.getItem("tv")
		lgtv=localStorage.getItem("lgtv")
		html='<div class="fix weather"><img src="" alt="icon" id="icon"></div>'
		html+='<div class="fix mediabuttons" onclick="floorplanmedia();">'
		if(tv=="On"){
			if(lgtv=="On")html+='<img src="/images/lgtv_On.png" class="i60" alt="lgtv" id="lgtvicon">'
			else if(lgtv=="Off")html+='<img src="/images/lgtv_Off.png" class="i60" alt="lgtv" id="lgtvicon">'
		}else if(tv=="Off")html+='<img src="/images/tv_Off.png" class="i60" alt="tv" id="tvicon">'
		html+='<br>'
		html+='<br></div><div class="fix center zon"><span id="maxtemp"></span><br><span id="mintemp"></span><br><a href=\'javascript:navigator_Go("regen.php");\'><span id="buien"></span></a><br><span id="wind"></span><br><br><img src="images/sunrise.png" alt="sunrise"><br><small>&#x21e7;</small><span id="zonop"></span><br><small>&#x21e7;</small><span id="sunop"></span><br><small>&#x21e9;</small><span id="sunonder"></span><br><small>&#x21e9;</small><span id="zononder"></span><br><div id="uv"></div></div>'
		document.getElementById('placeholder').insertAdjacentHTML('beforeend', html)
	}catch{}
}
function pad(n, length){
	len=length - (''+n).length
	return (len>0 ? new Array(++len).join('0') : '')+n
}
function toggle_visibility(id){
	e=document.getElementById(id)
	if(e.style.display=='inherit') e.style.display='none'
	else e.style.display='inherit'
}
function fix(){
	var el=this
	var par=el.parentNode
	var next=el.nextSibling
	par.removeChild(el)
	setTimeout(function() {par.insertBefore(el, next);}, 0)
}
function human_kb(fileSizeInBytes) {
	var i=-1
	var byteUnits=[' kbps', ' Mbps', ' Gbps', ' Tbps', 'Pbps', 'Ebps', 'Zbps', 'Ybps']
	do {
		fileSizeInBytes=fileSizeInBytes / 1024
		i++
	} while (fileSizeInBytes > 1024)
	return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i]
}
function initview(){
	try{$.clearInterval(myAjax)}catch{}
	try{$.clearInterval(myAjaxmedia)}catch{}
	for (var i=1; i < 99999; i++){try{window.clearInterval(i);}catch{};}
	view=localStorage.getItem('view')
	if(view=="floorplan")window["floorplan"]()
	else if(view=="floorplanmedia")window["floorplanmedia"]()
	else if(view=="floorplanheating")window["floorplanheating"]()
	else if(view=="floorplanothers")window["floorplanothers"]()
	else if(view=="floorplandaikin")window["floorplandaikin"]()
	else window["floorplan"]()
}
function setpoint(device){
	level=localStorage.getItem(device+'_set')
	try{
		icon=JSON.parse(localStorage.getItem(device+'_set_icon'))
	}catch{}
	daikin=JSON.parse(localStorage.getItem('daikin'+device+'_value'))
	heatingset=localStorage.getItem('heating')
	temp=localStorage.getItem(device+'_temp')
	$mode=localStorage.getItem(device+'_set_mode')
	luchtdrogermode=localStorage.getItem('luchtdroger_mode')
	html='<div class="fix dimmer" ><h2>'+device+' = '+temp+'°C</h2><h2>Set = '+level+'°C</h2>'
	if($mode==1||$mode==2){
		html+='<div class="fix btn btna" style="top:105px;left:25px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'1\');initview();"><br>Manueel</div>'
		html+='<div class="fix btn" style="top:105px;left:380px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'0\');initview();"><br>Auto</div>'
	}else{
		html+='<div class="fix btn" style="top:105px;left:25px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'1\');initview();"><br>Manueel</div>'
		html+='<div class="fix btn btna" style="top:105px;left:380px;width:110px;height:80px;font-size:2em" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'0\');initview();"><br>Auto</div>'
	}
	html+='<div class="fix z" style="top:230px;left:0px;width:100%">'
	if(device=='badkamer'){
		modes=[0,1,2,3,'Auto']
		modes.forEach(function(mode){
			if(luchtdrogermode==mode)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'luchtdroger\',\''+mode+'\');floorplanheating();">'+mode+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'luchtdroger\',\''+mode+'\');floorplanheating();">'+mode+'</button>'
		})
		html+='<h4>Slow</h4>'
		temps=[19,20,20.5,21,21.5,22,22.5,23,23.5,24]
		temps.forEach(function(temp){
			if(level==temp&&$mode==1)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
		html+='<h4>Fast</h4>'
		temps=[19,20,20.5,21,21.5,22,22.5,23,23.5,24]
		temps.forEach(function(temp){
			if(level==temp&&$mode==2)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint2\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint2\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
	} else {
		if(heatingset>0){
			if(device=='living'&&heatingset==1) temps=[17,18,18.5,19,19.5,20,20.5,21,21.5,22]
			else if(device=='living') temps=[17,18,19,19.5,20,20.1,20.2,20.3,20.4,20.5,20.6,20.7,20.8,20.9,21,21.1,21.2,21.3,21.4,21.5,21.6,21.7,21.8,21.9,22]
			else temps=[4,12,12.5,13,13.5,14,14.5,15,15.5,16]
		}else{
			temps=[1,2,3,4,5,18,18.5,19,19.5,20,20.5,21,21.5,22,22.5,23,23.5,24,24.5,25,25.5,26,26.5,27,28,33]
		}
		temps.forEach(function(temp){
			if(level==temp)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
			else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'setpoint\',\''+temp+'\');floorplanheating();">'+temp+'</button>'
		})
	}
	html+='</div><div class="fix z" style="top:5px;left:5px;" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)

}
function dimmer(device,floorplan='floorplan'){
	try{$.clearInterval(myAjax)}catch{}
	$mode=localStorage.getItem(device+'mode')
	current=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:140px">'
	if(current==0)html+='<h2>'+device+' Off</h2>'
	else html+='<h2>'+device+' '+current+' %</h2>'
	html+='<div class="fix z" style="top:80px;left:115px;" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'0\');initview();"><img src="images/light_Off.png" class="i90"></div>'
	html+='<div class="fix z" style="top:80px;left:305px;" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'100\');initview();"><img src="images/light_On.png" class="i90"></div>'
	html+='</div><div>'
	levels=[1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,22,24,26,28,30,32,35,40,45,50,55,60,65,70,75,80,85,90,95,100]
	if(levels.includes(parseInt(current))){}else{if(current>0&&current<100)levels.push(current);}
	levels.sort((a, b) => a - b)
	levels.forEach(function(level){
		if(current==level)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\''+level+'\');initview();">'+level+'</button>'
		else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\''+level+'\');initview();">'+level+'</button>'
	})
	html+='</div><div class="fix z" style="top:5px;left:5px;" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)
}
function roller(device,floorplan='floorplanheating'){
	try{$.clearInterval(myAjax)}catch{}
	current=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:140px">'
	if(current==0){
		if(device=='luifel')html+='<h2>'+device+' Dicht</h2><div class="fix" style="top:90px;left:385px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
		else html+='<h2>'+device+' Open</h2><div class="fix" style="top:90px;left:305px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
	} else if(current==100){
		if(device=='luifel')html+='<h2>'+device+' Open</h2><div class="fix" style="top:90px;left:35px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
		else html+='<h2>'+device+' Dicht</h2><div class="fix" style="top:90px;left:115px;z-index:-100;background:#ffba00;width:90px;height:90px;border-radius:45px;"></div>'
	} else if(device!='Beneden'&&device!='Boven') html+='<h2>'+device+' '+current+' %</h2>'
	else html+='<h2>'+device+'</h2>'
	if(device=='luifel'){
		mode=localStorage.getItem(device+'mode')
		if(mode==1)html+='<button class="btn btna b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'1\');initview();">Manueel</button><button class="btn b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'0\');initview();">Auto</button>'
		else html+='<button class="btn b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'1\');initview();">Manueel</button><button class="btn btna b4" onclick="ajaxcontrol(\'luifel\',\'mode\',\'0\');initview();">Auto</button>'
	}
	if(device=='luifel') html+='<div class="fix z" style="top:90px;left:35px;"><img src="images/arrowgreendown.png" class="i90" onclick="ajaxcontrol(\''+device+'\',\'roller\',\'100\');initview();"></div>'
	else html+='<div class="fix z" style="top:90px;left:115px;"><img src="images/arrowgreendown.png" class="i90" onclick="ajaxcontrol(\''+device+'\',\'roller\',\'100\');initview();"></div>'
	if(device=='luifel') html+='<div class="fix z" style="top:90px;left:385px;"><img src="images/arrowgreenup.png" class="i90"  onclick="ajaxcontrol(\''+device+'\',\'roller\',\'0\');initview();"></div>'
	else html+='<div class="fix z" style="top:90px;left:305px;"><img src="images/arrowgreenup.png" class="i90"  onclick="ajaxcontrol(\''+device+'\',\'roller\',\'0\');initview();"></div>'
	html+='</div><div class="fix z" style="top:190px;left:0px;">'
	levels=[1,5,10,15,20,25,30,32,34,36,38,40,42,44,46,48,50,52,54,57,60,62,64,66,68,70,72,74,76,78,80,82,85,90,95]
	if(levels.includes(parseInt(current))){}else{if(current>0&&current<100)levels.push(current);}
	levels.sort((a, b) => a - b)
	levels.forEach(function(level){
		if(current==level)html+='<button class="dimlevel dimlevela" onclick="ajaxcontrol(\''+device+'\',\'roller\',\''+level+'\');initview();">'+level+'</button>'
		else html+='<button class="dimlevel" onclick="ajaxcontrol(\''+device+'\',\'roller\',\''+level+'\');initview();">'+level+'</button>'
	})
	html+='</div><div class="fix z" style="top:5px;left:5px;" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	$('#placeholder').html(html)
}
function Weg(){
	try{$.clearInterval(myAjax)}catch{}
	poort=localStorage.getItem('poort')
	achterdeur=localStorage.getItem('achterdeur')
	raamliving=localStorage.getItem('raamliving')
	raamkeuken=localStorage.getItem('raamkeuken')
	bose103=localStorage.getItem('bose103')
	bose104=localStorage.getItem('bose104')
	bose105=localStorage.getItem('bose105')
	bose106=localStorage.getItem('bose106')
	bose107=localStorage.getItem('bose107')
	$Weg=localStorage.getItem('Weg')
	html='<div class="dimmer" ><div style="min-height:140px">'
	html+='<div class="fix" style="top:5px;left:5px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	if(poort=='Open'||achterdeur=='Open'||raamliving=='Open'||raamhall=='Open')html+='<h1 style="font-size:4em">OPGELET!<br>'
	if(poort=='Open')html+='Poort OPEN<br>'
	if(achterdeur=='Open')html+='Achterdeur OPEN<br>'
	if(raamliving=='Open')html+='Raam Living OPEN<br>'
	if(raamhall=='Open')html+='Raam Hall OPEN<br>'
	if(raamkeuken=='Open')html+='Raam Keuken OPEN<br>'
	if(bose103=='On')html+='Bose kamer aan<br>'
	if(bose104=='On')html+='Bose garage aan<br>'
	if(bose105=='On')html+='Bose keuken aan<br>'
	if(bose106=='On')html+='Bose Buiten20 aan<br>'
	if(bose107=='On')html+='Bose Buiten10 aan<br>'
	if(poort=='Open'||achterdeur=='Open'||raamliving=='Open'||raamhall=='Open'){
		html+='</h1>'
	}
	if ($Weg==0) {
		html+='<button class="btn huge2" style="display:inline-block;background-image:url(images/Weg.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol(\'Weg\',\'Weg\',\'2\');initview();">Weg</button>'
		html+='<button class="btn huge2" style="display:inline-block;background-image:url(images/Slapen.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol(\'Weg\',\'Weg\',\'1\');initview();">Slapen</button>'
	} else if ($Weg>=1) {
		ajaxcontrol('Weg','Weg',0)
		window.location.reload(true)
	}
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function heating(){
	$heating=localStorage.getItem('heating')
	html='<div class="dimmer" ><div style="min-height:140px">'
	html+='<div class="fix" style="top:5px;left:5px;z-index:200000" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	if($heating==4) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'4\');sleep(500);initview();">Gas heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'4\');sleep(500);initview();">Gas heating</button>'
	if($heating==3) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');sleep(500);initview();">Gas-Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');sleep(500);initview();">Gas-Airco heating</button>'
	if($heating==2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/AircoGas.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');sleep(500);initview();">Airco-Gas heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/AircoGas.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');sleep(500);initview();">Airco-Gas heating</button>'
	if($heating==1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');sleep(500);initview();">Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');sleep(500);initview();">Airco heating</button>'
	if($heating==0) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');sleep(500);initview();">Neutral</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');sleep(500);initview();">Neutral</button>'
	if($heating==-1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');sleep(500);initview();">Passive cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');sleep(500);initview();">Passive cooling</button>'
	if($heating==-2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');sleep(500);initview();">Airco cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');sleep(500);initview();">Airco cooling</button>'
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function confirmSwitch(device){
	$value=localStorage.getItem(device)
	html='<div class="dimmer" ><div style="min-height:140px">'
	html+='<div class="fix" style="top:5px;left:5px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'
	html+='<br><h1>'+device+'='+$value+'</h1><br>'
	html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\');initview();">On</button>'
	html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\');initview();">Off</button>'
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function formatDate(nowDate) {
	date=new Date(nowDate*1000)
	var day=date.getDate()
	var month=date.getMonth()+1
	return (day+'/'+month);
}
function sleep(millis) {
	var date=new Date()
	var curDate=null
	do {curDate=new Date()}
	while(curDate-date < millis)
}