var isSubmitting=!1;euroelec=.2698,eurogas=.092,eurowater=4.8166;const ucfirst=e=>e[0].toUpperCase()+e.slice(1);
let ajaxTimer = null,ajaxToken = 0,avgTimeOffset=0,zonavg=null,lastAvgValue=null,d=null,view='floorplan';
function formatDate(t){return date=new Date(1e3*t),date.getDate()+"/"+(date.getMonth()+1)}
function handleResponse(response){
	newTime=response['t']
	if ('CivTwilightStart' in response) {
		$("#zonop").html(response['CivTwilightStart'])
		$("#sunop").html(response['Sunrise'])
		$("#sunonder").html(response['Sunset'])
		$("#zononder").html(response['CivTwilightEnd'])
		$("#playlist").html(response['playlist'])
		zonavg=response['zonavg']
		let avgTimeOffset = 0
		let lastAvgValue = null
	}
	if (view=='floorplan') {
		zon=+response['z']||0
		net=+response['n']||0
		avg=+response['a']||0
		bat=+response['b']||0
		charge=+response['c']||0
		total=net+zon-bat
		$("#netvalue").html(net)
		if(net>0) $("#net").css('color',berekenKleurRood(net,5000))
		else $("#net").css('color',berekenKleurGroen(-net,5000))
		drawCircle('netcircle',net,2500,90,'purple')
		
		$("#batvalue").html(bat+'<br><span class="units">'+charge+'%</span>')
		if(bat>0) $("#bat").css('color',berekenKleurRood(bat,2000))
		else $("#bat").css('color',berekenKleurGroen(-bat,1000))
		drawCircle('batcircle',bat,800,90,'purple')

		$("#avgvalue").html(avg);
		$("#avgvalue").css('color', berekenKleurRood(avg, 5000));
		if (lastAvgValue !== null && lastAvgValue > 0 && avg < lastAvgValue) avgTimeOffset = updateSecondsInQuarter(response['t']);
		lastAvgValue = avg;
		let rawSeconds = updateSecondsInQuarter(response['t']);
		let correctedSeconds = (rawSeconds - avgTimeOffset + 900) % 900;
		
		drawCircle('avgtimecircle', correctedSeconds, 900, 82, 'gray');
		drawCircle('avgcircle', avg, 2500, 90, 'purple');

		$("#totalvalue").html(total)
		$("#totalvalue").css('color',berekenKleurRood(net,5000))
		drawCircle('totalcircle',total,2500+zon,90,'purple')

		$("#zonvalue").html(zon)
		$("#zonvalue").css('color',berekenKleurGroen(zon,zonavg*2))
		drawCircle('zoncircle',-zon,zonavg,90,'green')

		if ('elec' in response) {
			euro=response['elec']*euroelec
			html=euro.toFixed(2).toString().replace(/[.]/, ",")
			val=response['elec']*1
			val=val.toFixed(2).toString().replace(/[.]/, ",")
			$("#elecvalue").html(html+'<br><span class="units">'+val+'</span>')
			if(net>0)$("#elecvalue").css('color',berekenKleurRood(response['elec'],response['elecavg']*2))
			else $("#elecvalue").css('color',berekenKleurGroen(-response['elec'],response['elecavg']*2))
			drawCircle('eleccircle',response['elec'],response['elecavg'],90,'purple')
			$("#alwayson").html(response['alwayson']+"W")
		}
		if ('zon' in response) {
			euro=response['zon']*(euroelec+0.45)
			html=euro.toFixed(2).toString().replace(/[.]/, ",")
			val=response['zon']*1
			val=val.toFixed(2).toString().replace(/[.]/, ",")
			$("#zonvvalue").html(html+'<br><span class="units">'+val+'</span>')
			$("#zonvvalue").css('color',berekenKleurGroen(-val,response['zonavg']/10))
			drawCircle('zonvcircle',response['zon'],response['zonavg'],90,'green')
		}
		if ('gas' in response) {
			item=response['gas']*1000
			euro=item/1000*11.5*eurogas
			html=euro.toFixed(2).toString().replace(/[.]/, ",")
			val=response['gas']*1
			val=val.toFixed(2).toString().replace(/[.]/, ",")
			$("#gasvalue").html(html+'<br><span class="units">'+val+'</span>')
			$("#gasvalue").css('color',berekenKleurRood(item,response['gasavg']*2000))
			drawCircle('gascircle',item,response['gasavg']*1000,90,'red')
		}
		if ('thermo_hist' in response) {
			for (const device in response['thermo_hist']) {
				const hist = response['thermo_hist'][device];
				sessionStorage.setItem(device + '_min', hist.min);
				sessionStorage.setItem(device + '_avg', hist.avg);
				sessionStorage.setItem(device + '_max', hist.max);
			}
		}
	}
	$.each(response, function(device, v, i){
		if(device=="verlof"){
			sessionStorage.setItem("verlof", v['s'])
			if(v['s']==0)html='Normaal'
			else if(v['s']==1)html='Geen school'
			else if(v['s']==2)html='Verlof'
			$("#verlof").html(html)
		}else if(device=="weg"){
			sessionStorage.setItem("weg", v['s'])
			try{
				html='<div class="abs z" onclick="weg();">'
				if(v['s']==0)html+='<img src="/images/Thuis.png" id="weg" onclick="weg();">'
				else if(v['s']==1)html+='<img src="/images/Slapen.png" id="weg" onclick="weg();">'
				else if(v['s']==2)html+='<img src="/images/weg.png" id="weg" onclick="weg();">'
				else if(v['s']==3)html+='<img src="/images/Vacation.png" id="weg" onclick="weg();">'
				html+='</div>'
				$("#weg").html(html)
			}catch{}
			if(v['s']==0){
				try{
					$("#zliving").removeClass("secured")
					$("#zlivingb").removeClass("secured")
					$("#zkeuken").removeClass("secured")
					$("#zinkom").removeClass("secured")
				}catch{}
				try{
					$("#zgarage").removeClass("secured")
					$("#zhalla").removeClass("secured")
					$("#zhallb").removeClass("secured")
				}catch{}
			}else if(v['s']==1){
				try{
					$("#zliving").addClass("secured")
					$("#zlivingb").addClass("secured")
					$("#zkeuken").addClass("secured")
					$("#zinkom").addClass("secured")
				}catch{}
				try{
					$("#zgarage").addClass("secured")
					$("#zhalla").removeClass("secured")
					$("#zhallb").removeClass("secured")
				}catch{}
			}else if(v['s']>=2){
				try{
					$("#zliving").addClass("secured")
					$("#zlivingb").addClass("secured")
					$("#zkeuken").addClass("secured")
					$("#zinkom").addClass("secured")
				}catch{}
				try{
					$("#zgarage").addClass("secured")
					$("#zhalla").addClass("secured")
					$("#zhallb").addClass("secured")
				}catch{}
			}
		}else if(device=="alexslaapt"){
			if(v['s']==1) $("#zalex").addClass("securedalex")
			else $("#zalex").removeClass("securedalex")
			if(v['t']>(newTime-82800)){
				date=new Date(v['t']*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
			}else document.getElementById("t"+device).innerHTML=""
		}else if(device=="dag"){
			let s = v['s']
			if (s < -10 || s > 10) s = Math.round(s)
			$("#dag").html(s)
		}else if(device=="minmaxtemp"){
			mintemp=(Math.round(v['s'] * 100) / 100).toFixed(1);
			maxtemp=(Math.round(v['m'] * 100) / 100).toFixed(1);
			if (mintemp>=10) mincolor=berekenKleurRood(mintemp-10, 35)
			else if (mintemp<=5) mincolor=berekenKleurBlauw(5-mintemp, 25)
			else mincolor='#CCC'
			if (maxtemp>=10) maxcolor=berekenKleurRood(maxtemp-10, 35)
			else if (maxtemp<=5) maxcolor=berekenKleurBlauw(5-maxtemp, 25)
			else maxcolor='#CCC'
			if(mintemp<=0) {
				$("#mintemp").html("<div class='mintemp z2'>"+mintemp.toString().replace(/[.]/, ",")+" &#8451;</div>")
				$("#mintemp").css("color", mincolor)
				$("#maxtemp").html("<div class='maxtemp z1'>"+maxtemp.toString().replace(/[.]/, ",")+" &#8451;</div>")
				$("#maxtemp").css("color", maxcolor)
			} else {
				$("#mintemp").html("<div class='mintemp z1'>"+mintemp.toString().replace(/[.]/, ",")+" &#8451;</div>")
				$("#mintemp").css("color", mincolor)
				$("#maxtemp").html("<div class='maxtemp z2'>"+maxtemp.toString().replace(/[.]/, ",")+" &#8451;</div>")
				$("#maxtemp").css("color", maxcolor)
			}
		}else if(device=="wind"){
			elem=document.getElementById("wind")
			elem.innerHTML=v['s'].toString().replace(/[.]/, ",")+"km/u"
			if(v['s']>40)elem.style.color="#F66"
			else if(v['s']>30)elem.style.color="#F77"
			else if(v['s']>25)elem.style.color="#F88"
			else if(v['s']>20)elem.style.color="#F99"
			else if(v['s']>16)elem.style.color="#FAA"
			else if(v['s']>12)elem.style.color="#FBB"
			else if(v['s']>8)elem.style.color="#FCC"
			else elem.style.color=null
		}else if(device=="icon"){
			$('#icon').attr("src", "/images/"+v['s']+".png")
		}else if(device=="uv"){
			if(v['s']==0)html=''
			else if(v['s']<2)html='<font color="#99EE00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['s']<4)html='<font color="#99CC00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['s']<6)html='<font color="#FFCC00">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['s']<8)html='<font color="#FF6600">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
			else html='<font color="#FF2200">UV: '+v['s'].toString().replace(/[.]/, ",")+'</font>'
			if(v['m']==0)html+=''
			else if(v['m']<2)html+='<br><font color="#99EE00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['m']<4)html+='<br><font color="#99CC00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['m']<6)html+='<br><font color="#FFCC00">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
			else if(v['m']<8)html+='<br><font color="#FF6600">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
			else html+='<br><font color="#FF2200">max: '+v['m'].toString().replace(/[.]/, ",")+'</font>'
			$("#uv").html(html)
		}else if(device=="heating"){
			try{
			   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
				if(v['s']==0)html+=''
				else if(v['s']==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
				else if(v['s']==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
				else if(v['s']==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
				else if(v['s']==2)html+='<img src="/images/AircoGas.png" class="i40" alt="AircoGas">'
				else if(v['s']==3)html+='<img src="/images/GasAirco.png" class="i40" alt="GasAirco">'
				else if(v['s']==4)html+='<img src="/images/Gas.png" class="i40" alt="Gas">'
				document.getElementById("heating").innerHTML=html
			}catch{}
			sessionStorage.setItem(device, v['s'])
			sessionStorage.setItem('tijd_'+device, v['t'])
			try{
				html='<td>'
				if(v['s']==0)html+='<img src="images/close.png" height="40" width="40px" onclick="heating();"></td><td align="left" height="40" width="40px" style="line-height:18px" onclick="heating()">Neutral</td>'
				else if(v['s']==-2)html+='<img src="images/Cooling.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>cooling</td>'
				else if(v['s']==-1)html+='<img src="images/Cooling_grey.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Passive<br>cooling</td>'
				else if(v['s']==1)html+='<img src="images/Cooling_red.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Airco<br>heating</td>'
				else if(v['s']==2)html+='<img src="images/GasAirco.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas-Airco<br>heating</td>'
				else if(v['s']==3)html+='<img src="images/Gas.png" onclick="heating();"></td><td align="left" height="60" width="80px" style="line-height:18px" onclick="heating()">Gas heating</td>'
				document.getElementById("trheating").innerHTML=html
			}catch{}
//		}else if(device=="daikin_kwh"){
//			elem=document.getElementById("daikin_kwh")
//			if(v['s']>0){
//				html=Math.round(v['s'])+" W"
//				elem.innerHTML=html
//			}
//			$color=~~(256-(v['s']/10))
//			$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
//			$color="#FF"+$color+"00"
//			if(v['s']>0)elem.style.color=$color
//			else elem.style.color=null
		}else if(device=="sirene"){
			if(v['s']!="Off")html='<img src="images/alarm_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'sirene\',\'sw\',\'Off\')"><br>'+device
			else html=""
			document.getElementById("sirene").innerHTML=html
//		}else if(v['dt']=="smoke detector"){
//			if(v['s']!="Off")html='<img src="images/smoke_On.png" width="500px" height="auto" alt="Sirene" onclick="ajaxcontrol(\'resetsecurity\',\'resetsecurity\',\'Off\')"><br>'+device
//			else html=""
//			document.getElementById("sirene").innerHTML=html
		}else if(device=="brander"){
			sessionStorage.setItem(device, v['s'])
			sessionStorage.setItem('tijd_'+device, v['t'])
			try{
				if(v['s']=="Off")html='<img src="images/fire_Off.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'On\')">'
				else html='<img src="images/fire_On.png" onclick="ajaxcontrol(\'brander\',\'sw\',\'Off\')">'
				document.getElementById("brander").innerHTML=html
			}catch{}
			heatingmode=sessionStorage.getItem('heating')
			try{
			   html='<img src="/images/arrowdown.png" class="i60" alt="Open">'
				if(heatingmode==0)html+=''
				else if(heatingmode==-2)html+='<img src="/images/Cooling.png" class="i40" alt="Cooling">'
				else if(heatingmode==-1)html+='<img src="/images/Cooling_grey.png" class="i40" alt="Cooling">'
				else if(heatingmode==1)html+='<img src="/images/Cooling_red.png" class="i40" alt="Elec">'
				else if(heatingmode==4){
					if(v['s']=='On')html+='<img src="/images/fire_On.png" class="i40" id="branderfloorplan" alt="Gas">'
					else html+='<img src="/images/fire_Off.png" class="i40" alt="Gas">'
				}
				document.getElementById("heating").innerHTML=html
			}catch{}
	//		try{
				//BRANDERFLOORPLAN
				if(heatingmode>=1){
					if(v['s']=="Off") $('#branderfloorplan').attr("src", "/images/fire_Off.png")
					else $('#branderfloorplan').attr("src", "/images/fire_On.png")
				} else if(heatingmode>0){
					if(v['s']=="Off")$('#branderfloorplan').attr("src", "/images/gaselec_Off.png")
					else $('#branderfloorplan').attr("src", "/images/gaselec_On.png")
				} else $('#branderfloorplan').attr("src", "")
	//		}catch{}
		}else if(device=="luifel"){
			sessionStorage.setItem(device, v['s'])
			sessionStorage.setItem('tijd_'+device, v['t'])
			sessionStorage.setItem(device+'mode', v['m'])
			if(v['s']==0)html='<img src="/images/arrowgreenup.png" class="i60">'
			else if(v['s']==100)html='<img src="/images/arrowgreendown.png" class="i60">'
			else html='<img src="/images/arrowdown.png" class="i60"><div class="fix center dimmerlevel" style="position:absolute;top:10px;left:-2px;width:70px;letter-spacing:4;"><font size="5" color="#CCC">'+v['s']+'</font> </div>'
			if(v['m']==1)html+='<div class="fix" style="top:2px;left:2px;z-index:-100;background:#fff7d8;width:56px;height:56px;border-radius:45px;"></div>'
			html+='<br>luifel<br><span id="tluifel"></span>'
			document.getElementById(device).innerHTML=html
//		}else if(device=="raamhall"){
//			sessionStorage.setItem(device, v['s'])
//			sessionStorage.setItem("tijd_"+device, v['t'])
//			element=document.getElementById(device)
//			if(v['s']=="Open") element.classList.add("red")
//			else element.classList.remove("red")
//			if(v['t']>(newTime-82800)){
//				date=new Date(v['t']*1000)
//				hours=date.getHours()
//				minutes="0"+date.getMinutes()
//				document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
//			}else document.getElementById("t"+device).innerHTML=""
		}else if(device=="buien"){
			if(typeof v['s'] !== undefined){
				elem=document.getElementById('buien')
				elem.innerHTML="Buien: "+v['s']
				if(v['s']>70)elem.style.color="#39F"
				else if(v['s']>60)elem.style.color="#69F"
				else if(v['s']>50)elem.style.color="#79F"
				else if(v['s']>40)elem.style.color="#89F"
				else if(v['s']>30)elem.style.color="#99F"
				else if(v['s']>20)elem.style.color="#AAF"
				else if(v['s']>10)elem.style.color="#BBD"
				else if(v['s']>0)elem.style.color="#CCF"
				else elem.style.color=null
			}else{
				elem=document.getElementById('buien')
				elem.innerHTML="Buien: 0"
				elem.style.color="#888"
			}
		} else if (["sw","hsw"].includes(v?.dt)) {
			sessionStorage.setItem(device, v['s']);
			let html = '';
			const isOn = (v['s'] == "On");
			const iconName = v['icon'] || 'l';
			const specialDevices = ["water", "regenpomp", "steenterras", "tuintafel", 
									"terras", "tuin", "auto", "media", "nas", "zetel", "grohered", "kookplaat",
									"boseliving", "bosekeuken",
									"ipaddock","mac"];
			const confirmDevices = ["ipaddcok","mac", "daikin", "grohered", "kookplaat", "media", "boseliving", "bosekeuken"];
			const directControlDevices = ["regenpomp", "nas"];
			if (device == "daikin") {
				if (!isOn) {
					const kwhElem = document.getElementById("daikin_kwh");
					if (kwhElem) kwhElem.innerHTML = "";
				}
				elem=document.getElementById("daikin_kwh")
				if(v['p']>0){
					html=Math.round(v['p'])+" W"
					elem.innerHTML=html
				}
				$color=~~(256-(v['p']/10))
				$color=('00' + $color.toString(16).toUpperCase()).slice(-2)
				$color="#FF"+$color+"00"
				if(v['p']>0)elem.style.color=$color
				else elem.style.color=null
				sessionStorage.setItem('daikinmode', (v['m'] == 1) ? 'auto' : 'man');
			}
			if (device == "water") {
				sessionStorage.setItem('watermode', v['m']);
			}
			let onclickHandler = '';
			if (confirmDevices.includes(device)) {
				onclickHandler = `confirmSwitch('${device}')`;
			} else if (directControlDevices.includes(device)) {
				const newState = isOn ? 'Off' : 'On';
				onclickHandler = `ajaxcontrol('${device}','sw','${newState}');floorplan();`;
			} else {
				const newState = isOn ? 'Off' : 'On';
				onclickHandler = `ajaxcontrol('${device}','sw','${newState}')`;
			}
			if (isOn) {
				if (iconName == 'l') {
					html = '<img src="/images/l_On.png" id="' + device + '" class="img100" />';
					html += '<div class="dimmercircle" onclick="' + onclickHandler + '">';
					html += '<svg viewBox="0 0 36 36">';
					html += '<path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />';
					html += '<path class="circle" stroke-dasharray="100, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />';
					html += '</svg>';
					html += '</div>';
				} else {
					html = '<img src="/images/' + iconName + '_On.png" id="' + device + '" onclick="' + onclickHandler + '" />';
				}
			} else {
				html = '<img src="/images/' + iconName + '_Off.png" id="' + device + '" onclick="' + onclickHandler + '" />';
			}
			if (specialDevices.includes(device)) {
				html += '<br>' + device;
				if (["water", "regenpomp", "auto", "media", "nas"].includes(device)) {
					if (v['t'] > (newTime - 82800)) {
						const date = new Date(v['t'] * 1000);
						const hours = date.getHours();
						const minutes = ("0" + date.getMinutes()).substr(-2);
						html += '<br>' + hours + ':' + minutes;
					} else {
						html += '<br>' + formatDate(v['t']);
					}
				}
			}
			$('#' + device).html(html);
		} else if (["bose"].includes(v?.dt)) {
			if(device=="bose101"||device=="bose106"){
				if(v['m']=="Offline")html=''
				else{
					if(v['s']=="On")html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_On.png\" id=\""+device+"\" alt=\"bose\"></a>"
					else html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST30_Off.png\" id=\""+device+"\" alt=\"bose\"></a>"
				}
			}else{
				if(v['m']=="Offline")html=''
				else{
					if(v['s']=="On")html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_On.png\" id=\""+device+"\" alt=\"bose\"></a>"
					else html="<a href='javascript:navigator_Go(\"floorplan.bose.php?ip="+device+"\");'><img src=\"images/ST10_Off.png\" id=\""+device+"\" alt=\"bose\"></a>"
				}
			}
			$('#'+device).html(html)
			sessionStorage.setItem(device, v['s'])
		} else if (["d","hd"].includes(v?.dt)) {
			sessionStorage.setItem(device, v['s']);
			let html = '';
			const level = parseInt(v['s']) || 0;
			if (level == 0 || v['s'] == "Off") {
				html = '<img src="/images/l_Off.png" class="img100">';
			} else {
				html = '<img src="/images/l_On.png" class="img100">';
				html += '<div class="dimmercircle">';
				html += '<svg viewBox="0 0 36 36">';
				html += '<path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />';
				html += '<path class="circle" stroke-dasharray="' + level + ', 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />';
				html += '</svg>';
				html += '<div class="dimmer-percentage">' + level + '%</div>';
				html += '</div>';
			}
			if (device == "terras") {
				html += 'terras';
			}
			$('#' + device).html(html);
		} else if (["r"].includes(v?.dt)) {
			sessionStorage.setItem(device, v['s']);
			sessionStorage.setItem(device + 'mode', v['m']);
			const opts = v['icon'].split(",");
			const status = 100 - v['s'];
			const elem = document.getElementById(device);
			if (elem) {
				let perc = (status < 100) ? (status / 100) * 0.7 : 1;
				let rollerTop = parseInt(opts[0]);
				let indicatorSize = 0;
				if (status == 0) {
					indicatorSize = 0;
					//elem.classList.remove("yellow");
				} else if (status > 0) {
					indicatorSize = (parseFloat(opts[2]) * perc) + 8;
					if (indicatorSize > parseFloat(opts[2])) {
						indicatorSize = parseFloat(opts[2]);
					}
					rollerTop = parseInt(opts[0]) + parseInt(opts[2]) - indicatorSize;
					elem.classList.add("yellow");
				} else {
					indicatorSize = parseFloat(opts[2]);
				}
				if (opts[3] == "P") {
					elem.style.top = rollerTop + 'px';
					elem.style.left = opts[1] + 'px';
					elem.style.width = '8px';
					elem.style.height = indicatorSize + 'px';
				} else if (opts[3] == "L") {
					elem.style.top = opts[0] + 'px';
					elem.style.left = opts[1] + 'px';
					elem.style.width = indicatorSize + 'px';
					elem.style.height = '9px';
				}
				let html = '';
				if (v['s'] == 100) {
					html = '<img src="/images/arrowgreendown.png" class="i48">';
				} else if (v['s'] == 0) {
					html = '<img src="/images/arrowgreenup.png" class="i48">';
				} else {
					html = '<img src="/images/circlegrey.png" class="i48">';
					html += '<div class="fix center dimmerlevel" style="position:absolute;top:19px;left:1px;width:46px;letter-spacing:6px;">';
					html += '<font size="5" color="#CCC">' + v['s'] + '</font>';
					html += '</div>';
				}
				html += '</div>';
				if (v['t'] > (newTime - 82800)) {
					const date = new Date(v['t'] * 1000);
					const hours = date.getHours();
					const minutes = ("0" + date.getMinutes()).substr(-2);
					html += '<br><div id="t' + device + '">' + hours + ':' + minutes + '</div>';
				} else {
					html += '<br><div id="t' + device + '">' + formatDate(v['t']) + '</div>';
				}
				$('#R' + device).html(html);
			}
			if (view=='floorplanheating') {
				const timestampElem = document.getElementById("t" + device);
				if (timestampElem) {
					if (v['t'] > (newTime - 82800)) {
						const date = new Date(v['t'] * 1000);
						const hours = date.getHours();
						const minutes = ("0" + date.getMinutes()).substr(-2);
						timestampElem.innerHTML = hours + ':' + minutes;
					} else {
						timestampElem.innerHTML = formatDate(v['t']);
					}
				}
			}
		} else if (["pir"].includes(v?.dt)) {
			sessionStorage.setItem(device, v['s'])
			sessionStorage.setItem("tijd_"+device, v['t'])
			device=device.toString().replace("pir", "")
			element=document.getElementById("z"+device)
			if(device=="hall"){
				if(v['s']=="On"){
					document.getElementById("z"+device+"a").classList.add("motion")
					document.getElementById("z"+device+"b").classList.add("motion")
				}else{
					document.getElementById("z"+device+"a").classList.remove("motion")
					document.getElementById("z"+device+"b").classList.remove("motion")
				}
			}else if(device=="living"){
				if(v['s']=="On"){
					document.getElementById("z"+device).classList.add("motion")
					document.getElementById("z"+device+"b").classList.add("motion")
				}else{
					document.getElementById("z"+device).classList.remove("motion")
					document.getElementById("z"+device+"b").classList.remove("motion")
				}
			}else{
				if(v['s']=="On") element.classList.add("motion")
				else element.classList.remove("motion")
			}
			if(v['t']>(newTime-82800)){
				date=new Date(v['t']*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				document.getElementById("tpir"+device).innerHTML=hours+':'+minutes.substr(-2)
			}else document.getElementById("tpir"+device).innerHTML=""
		} else if (["c"].includes(v?.dt)&&device!='raamhall') {
			try{
				sessionStorage.setItem(device, v['s'])
				sessionStorage.setItem("tijd_"+device, v['t'])
					element=document.getElementById(device)
				if(v['s']=="Open") element.classList.add("red")
				else element.classList.remove("red")
				if(v['t']>(newTime-82800)){
					date=new Date(v['t']*1000)
					hours=date.getHours()
					minutes="0"+date.getMinutes()
					document.getElementById("t"+device).innerHTML=hours+':'+minutes.substr(-2)
				}else document.getElementById("t"+device).innerHTML=formatDate(v['t'])
			}catch{}
		} else if (["t"].includes(v?.dt)) { // Thermometer
			sessionStorage.setItem(device, v['s']);
			renderThermometer(device, v);
		} else if (["th"].includes(v?.dt)) { //Thermostaat
			heatingset=sessionStorage.getItem('heating')
//			sessionStorage.setItem(device+'_mode', v['m'])
//			sessionStorage.setItem(device+'_icon', v['icon'])
//			sessionStorage.setItem(device, v['s'])
//			sessionStorage.setItem("tijd_"+device, v['t'])
			temp=sessionStorage.getItem(device.toString().replace("_set", "_temp"))
			dif=temp-v['s']
			if(dif>0.3)circle="hot"
			else if(dif<-0.3)circle="cold"
			else circle="grey"
			if(v['s']>=20)center="red"
			else if(v['s']>19)center="orange"
			else if(v['s']>14)center="grey"
			else center="blue"

			elem=document.getElementById(device)
			html='<img src="/images/thermo'+circle+center+'.png" class="i48" alt="">'
			html+='<div class="abs center" style="top:35px;left:11px;width:26px;">'
			if(v['m']==1){
				html+='<font size="2" color="#222">'+v['s'].toString().replace(/[.]/, ",")+'</font></div>'
				html+='<div class="abs" style="top:2px;left:2px;z-index:-100;background:#b08000;width:44px;height:44px;border-radius:45px;"></div>'
			}else html+='<font size="2" color="#CCC">'+v['s'].toString().replace(/[.]/, ",")+'</font></div>'
			if(v['t']>(newTime-82800)){
				date=new Date(v['t']*1000)
				hours=date.getHours()
				minutes="0"+date.getMinutes()
				html+='<br><div id="t'+device+'">'+hours+':'+minutes.substr(-2)+'</div>'
			}else html+='<br><div id="t'+device+'">'+formatDate(v['t'])+'</div>';
			if(heatingset==-2||heatingset>0){
				if(device=='alex_set'||device=='living_set'||device=='kamer_set'){
					try{
						obj=v['icon']
						html+='<br>'
						if(obj.power==0)html+='Off<br>'
						else html+=obj.set
					}catch{}
				}
			}
			document.getElementById(device).innerHTML=html
		}
	})
	date=new Date(newTime*1000)
	hours=date.getHours()
	minutes="0"+date.getMinutes()
	seconds="0"+date.getSeconds()
	$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
	if(view=='floorplanheating') {
		var items = ['living_set', 'badkamer_set', 'kamer_set', 'alex_set', 'brander', 'luifel'];
		items.forEach(id => {
			try {
				const tijd = parseInt(sessionStorage.getItem("tijd_" + id));
				const elem = document.getElementById("t" + id);
				const delta = newTime - tijd;
				if (delta < 86400) {
					const d = new Date(tijd * 1000);
					const hh = d.getHours();
					const mm = ("0" + d.getMinutes()).slice(-2);
					const txt = `${hh}:${mm}`;
					if (elem.innerHTML !== txt) elem.innerHTML = txt;
				} else {
					const txt = formatDate(tijd);
					if (elem.innerHTML !== txt) elem.innerHTML = txt;
				}
				let kleur;
				if (delta < 60) {
					const ratio = delta / 60;
					const g = Math.round(136 + (170 - 136) * ratio);  // 136 → 170
					kleur = `rgb(255, ${g}, 0)`; // #FF8800 → #FFAA00
				}
				else if (delta < 300) {
					const ratio = (delta - 60) / (300 - 60);
					const g = Math.round(170 + (255 - 170) * ratio);
					kleur = `rgb(255, ${g}, 0)`; // #FFAA00 → #FFFF00
				}
				else if (delta < 7200) {
					const ratio = (delta - 300) / (7200 - 300);
					const b = Math.round(0 + 204 * ratio);
					const g = Math.round(255 - 51 * ratio); // 255 → 204
					kleur = `rgb(255, ${g}, ${b})`;
				}
				else if (delta < 82800) {
					const ratio = (delta - 7200) / (82800 - 7200);
					const val = Math.round(204 - (204 - 119) * Math.min(ratio, 1)); // 204 → 119
					kleur = `rgb(${val}, ${val}, ${val})`;
				}
				else {
					kleur = "#777";
				}
		
				if (elem.style.color !== kleur) elem.style.color = kleur;
			}catch{}
		});
	}
	var items = ['deurgarage','deurinkom','achterdeur','deurvoordeur','deurbadkamer','deurkamer','deurwaskamer','deuralex','deurwc','raamliving','raamkeuken','raamkamer','raamwaskamer','raamalex']
	items.forEach(id => {
		try {
			const tijd = parseInt(sessionStorage.getItem("tijd_" + id));
			const status = sessionStorage.getItem(id);
			const elem = document.getElementById("t" + id);
			const delta = newTime - tijd;
			if (status === "Closed") {
				let kleur;
				if (delta < 600) {
					const ratio = delta / 600;
					const green = Math.round(255 * ratio);
					kleur = `rgb(255, ${green}, 0)`;
				}
				else if (delta < 1800) {
					const ratio = (delta - 900) / (1800 - 600);
					const blue = Math.round(255 * ratio);
					kleur = `rgb(255, 255, ${blue})`;
				}
				else if (delta < 82800) {
					const ratio = (delta - 1800) / (82800 - 1800);
					const val = Math.round(255 - (255 - 119) * Math.min(ratio, 1));
					kleur = `rgb(${val}, ${val}, ${val})`;
				}
				else {
					const datum = formatDate(tijd);
					if (elem.innerHTML !== datum) elem.innerHTML = datum;
					kleur = "#666";
				}
	
				if (elem.style.color !== kleur) elem.style.color = kleur;
	
			} else {
				if (delta < 82800) {
					if (elem.style.color) elem.style.color = null;
				} else {
					const datum = formatDate(tijd);
					if (elem.innerHTML !== datum) elem.innerHTML = datum;
				}
				if (elem.style.color !== "#FFF") elem.style.color = "#FFF";
			}
		} catch {}
	});

	var items = ['pirliving', 'pirinkom', 'pirhall', 'pirkeuken', 'pirgarage'];
	
	items.forEach(id => {
		try {
			const tijd = parseInt(sessionStorage.getItem("tijd_" + id));
			const status = sessionStorage.getItem(id);
			const elem = document.getElementById("t" + id);
			const delta = newTime - tijd;
			if (id=='alexslaapt') {
				console.log(id + '=' + status + ' delta = ' + delta);
			} else if (status === "Off" ||status == 0) {
				if (delta < 86400) {
					let kleur;
					if (delta < 600) {
						const ratio = delta / 600;
						const green = Math.round(255 * ratio);
						kleur = `rgb(255, ${green}, 0)`; // Rood naar Geel
					}
					else if (delta < 1800) {
						const ratio = (delta - 600) / (1800 - 600);
						const blue = Math.round(255 * ratio);
						kleur = `rgb(255, 255, ${blue})`; // Geel naar Wit
					}
					else {
						const ratio = Math.min((delta - 1800) / (82800 - 1800), 1);
						const val = Math.round(255 - (255 - 119) * ratio); // 255 → 119
						kleur = `rgb(${val}, ${val}, ${val})`;
					}
					if (elem.style.color !== kleur) elem.style.color = kleur;
				} else {
					const datum = formatDate(tijd);
					if (elem.innerHTML !== datum) elem.innerHTML = datum;
					if (elem.style.color !== "#666") elem.style.color = "#666";
				}
			} else {
				if (delta < 86400) {
					if (elem.style.color !== "#FFF") elem.style.color = "#FFF";
				} else {
					const datum = formatDate(tijd);
					if (elem.innerHTML !== datum) elem.innerHTML = datum;
					if (elem.style.color !== "#FFF") elem.style.color = "#FFF";
				}
			}
		} catch (e) {}
	})
}

function ajaxbose($ip){
	if(isSubmitting) {
		return
	}
	isSubmitting=true
	$.ajax({
		url: '/ajax.php?bose='+$ip,
		dataType : 'json',
		async: false,
		defer: true,
		success: function(data){
			date=new Date(data["time"]*1000)
			hours=date.getHours()
			minutes="0"+date.getMinutes()
			seconds="0"+date.getSeconds()
			$("#time").html(hours+':'+minutes.substr(-2)+':'+seconds.substr(-2))
			html=""
			if(data["source"]!="STANDBY"){
				let volume=parseInt(data["volume"], 10)
				levels=[-10, -7, -4, -2, -1, 0, 1, 2, 4, 7, 10]
				html="<br>"
				levels.forEach(function(level){
					let newlevel=parseInt(volume+level)
					if(newlevel>=0&&newlevel<=80){
						if(level!=0)html+='<button class="btn volume hover" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
						else html+='<button class="btn volume btna" id="vol'+level+'" onclick="ajaxcontrolbose('+$ip+',\'volume\',\''+newlevel+'\')">'+newlevel+'</button>'
					}
				})
				if($("#volume").html()!=html)$("#volume").html(html)
				if(data["source"]=="SPOTIFY"){
					if($("#artist").html()!=data["artist"])$("#artist").html(data["artist"])
					if($("#track").html()!=data["track"])$("#track").html(data["track"])
				}else if(data["source"]=="BLUETOOTH"){
					if($("#artist").html()!="Bluetooth")$("#artist").html("Bluetooth")
					if($("#track").html()!=data["track"])$("#track").html(data["track"])
				}else if(data["source"]=="TUNEIN"){
					if($("#artist").html()!=data["artist"])$("#artist").html(data["artist"])
					if($("#track").html()!=data["track"])$("#track").html(data["track"])
					try{
						$("#source").html(data["source"])
					}catch{}
				}else{
					try{
						$("#artist").html(data["source"])
					}catch{}
				}
				img='None'
				try{
					img=data["art"].toString().replace("http://", "https://")
				}catch{}
				if(data["source"]=="BLUETOOTH") html='<img src="/images/bluetooth.png" height="160px" width="auto" alt="bluetooth">'
				else if(img=='None')html=''
				else if(img.startsWith('http')) html='<img src="'+img+'" class="spotify" alt="Art">'
				else html=''
				try{
					elem=document.getElementById("art")
					if(elem.innerHTML!=html)elem.innerHTML=html
				}catch{}
				if(data["source"]=="SPOTIFY"){
					html='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'prev\')">Prev</button>'
					html+='<button class="btn b2" onclick="ajaxcontrolbose('+$ip+',\'skip\',\'next\')">Next</button>'
				} else html=''
				try{
					if(data["playlist"]=='EDM - Part 1') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">EDM - 1</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'1\')">EDM - 1</button>'
					if(data["playlist"]=='EDM - Part 2') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">EDM - 2</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'2\')">EDM - 2</button>'
					if(data["playlist"]=='EDM - Part 3') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">EDM - 3</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'3\')">EDM - 3</button>'
					if(data["playlist"]=='Mix - Part 1') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">MIX - 1</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'4\')">MIX - 1</button>'
					if(data["playlist"]=='Mix - Part 2') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">MIX - 2</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'5\')">MIX - 2</button>'
					if(data["playlist"]=='Mix - Part 3') html+='<button class="btn btna b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">MIX - 3</button>'
					else html+='<button class="btn b3" onclick="ajaxcontrolbose('+$ip+',\'preset\',\'6\')">MIX - 3</button>'
				}catch{}
				html+='<br><br><button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'Off\');ajaxbose('+$ip+');myAjaxmedia=setInterval( function() { ajaxbose('+$ip+'); }, 500 );">Power Off</button><br><br>'
			}else{
				$("#artist").html("")
				$("#track").html("")
				$("#art").html("")
				$("#volume").html("")
				$("#bass").html("")
				html='<button class="btn b1" onclick="ajaxcontrolbose('+$ip+',\'power\',\'On\')">Power On</button>'
			}
			$("#playlist").html(data['playlisttoday'])
			if($("#power").html()!=html) $("#power").html(html)
			isSubmitting=false
		},
		error: function( data ) {
			isSubmitting=false
		},timeout: 2000
	})
}

function floorplan(){
    view='floorplan'
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    ajaxall()
	html='<div class="abs leftbuttons" id="heating" onclick="floorplanheating();"></div>'
	html+='<div class="fix floorplan2icon" onclick="floorplanothers();"><img src="/images/plus.png" class="i60" alt="plus"></div>'
	html+='<div class="abs weg" id="weg"></div>'
	html+='<div class="abs z2" id="sirene"></div>'

	items=['rbureel','rkeukenl','rkeukenr','rliving','rkamerl','rkamerr','rwaskamer','ralex']
	items.forEach(function(item){html+='<div class="abs yellow" id="'+item+'"></div>';})

	items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','zliving','zlivingb','zkeuken','zinkom','zgarage','zhalla','zhallb','zalex','alwayson','daikin_kwh']
	items.forEach(function(item){html+='<div class="abs z0" id="'+item+'"></div>';})

	items=['dysonlader']
	items.forEach(function(item){html+='<div class="abs z1" id="'+item+'"></div>';})

	items=['living','badkamer','kamer','waskamer','alex','buiten']
	items.forEach(function(item){html+='<div class="abs" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})

	items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc','talexslaapt']
	items.forEach(function(item){html+='<div class="abs stamp" id="'+item+'"></div>';})

	items=['bose101','bose102','bose103','bose104','bose105','bose106','bose107']
	items.forEach(function(item){html+='<div class="abs" id="'+item+'"></div>';})

	items=['alex','eettafel','bureellinks','bureelrechts','kamer','lichtbadkamer','terras','zithoek','inkom','hall','wasbak','snijplank']
	items.forEach(function(item){html+='<div class="abs z" onclick="dimmer(\''+item+'\');" id="'+item+'"></div>';})

	items=['lampkast','tuin','tuintafel','kristal','voordeur','wc','garage','garageled','zolderg','steenterras','poortrf','daikin','badkamervuur1','badkamervuur2']
	items.forEach(function(item){html+='<div class="abs z1 i48" id="'+item+'"></div>';})

	html+='<div class="abs verbruik">'
	html+='<a href="https://verbruik.egregius.be/kwartierpiek.php"><div id="avg" onclick="location.href=\'https://verbruik.egregius.be/kwartierpiek.php\';" style="z-index:1000;"><span id="avgtitle">15\'</span><span id="avgvalue"></span><canvas id="avgtimecircle" width="120" height="120"></canvas><canvas id="avgcircle" width="120" height="120"></canvas></div></a>'
	html+='<div id="net"  onclick="window.open(\'https://hwenergy.app/dashboard?dashboard=6310D647-E7B5-4280-8D07-F829707D2D12\')"><span id="nettitle">Net</span><span id="netvalue"></span><canvas id="netcircle" width="120" height="120"></canvas></div>'
	html+='<div id="total" onclick="location.href=\'https://verbruik.egregius.be/dag.php?Guy=on&reset\';"><span id="totaltitle">Verbruik</span><span id="totalvalue"></span><canvas id="totalcircle" width="120" height="120"></canvas></div>'
	html+='<div id="elec" onclick="location.href=\'https://verbruik.egregius.be/dag.php?Guy=on&reset#elec\';"><span id="electitle">Elec</span><span id="elecvalue"></span><canvas id="eleccircle" width="120" height="120"></canvas></div>'
	html+='<div id="gas" onclick="location.href=\'https://verbruik.egregius.be/dag.php?Guy=on&reset#gas\';"><span id="gastitle">Gas</span><span id="gasvalue"></span><canvas id="gascircle" width="120" height="120"></canvas></div>'
	html+='<div id="bat"  onclick="window.open(\'https://hwenergy.app/dashboard?dashboard=6310D647-E7B5-4280-8D07-F829707D2D12\')"><span id="battitle">Bat</span><span id="batvalue"></span><canvas id="batcircle" width="120" height="120"></canvas></div>'
	html+='</div>'
	html+='<div class="abs zonurl" onclick="location.href=\'https://zon.egregius.be\';">'
	html+='<div id="zon"><span id="zontitle">Zon</span><span id="zonvalue"></span><canvas id="zoncircle" width="120" height="120"></canvas></div>'
	html+='<div id="zonv"><span id="zonvtitle">Zon</span><span id="zonvvalue"></span><canvas id="zonvcircle" width="120" height="120"></canvas></div>'
	html+='</div>'
	html+='<div id="playlist" class="abs"></div>'
	$('#placeholder').html(html)
	sidebar()
}
function floorplanothers(){
    view='floorplanothers'
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
	ajaxall();
	html='<div class="abs floorplan2icon" onclick="floorplan();"><img src="/images/close.png" class="i60" alt="plus"></div>'
	html+='<div class="fix z2" id="sirene"></div>'
	items=['grohered','kookplaat','nas','media','zetel','boseliving','bosekeuken']
	items.forEach(function(item){html+='<div class="abs z1 i48" id="'+item+'"></div>';})
	items=['bureel','keukenl','keukenr','living']
	items.forEach(function(item){html+='<div class="abs yellow" id="r'+item+'"></div>';})
	items=['zliving','zlivingb','zkeuken','zinkom']
	items.forEach(function(item){html+='<div class="abs z0" id="'+item+'"></div>';})
	items=['raamliving','raamkeuken','deurvoordeur','deurinkom','deurgarage','deurwc']
	items.forEach(function(item){html+='<div class="abs" id="'+item+'"></div>';})
	items=['buiten']
	items.forEach(function(item){html+='<div class="abs" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
	items=['auto','regenpomp','mac','ipaddock']
	items.forEach(function(item){html+='<div class="abs z1 i48" style="width:70px;" id="'+item+'"></div>';})
//	items=['tpirliving','tpirkeuken','tpirinkom','traamliving','traamkeuken','tdeurvoordeur','tdeurinkom','tdeurgarage','tdeurwc','talexslaapt']
//	items.forEach(function(item){html+='<div class="fix stamp" id="'+item+'"></div>';})

	html+='<div class="fix z1 center" style="top:880px;left:320px;"><a href=\'javascript:navigator_Go("log.php");\'><img src="/images/log.png" width="40px" height="40px"/><br>Log</a></div>'
	html+='<div class="fix z1 center" style="top:880px;left:400px;"><a href=\'javascript:navigator_Go("floorplan.cache.php?nicestatus");\'><img src="/images/log.png" width="40px" height="40px"/><br>Cache</a></div>'
	html+='<div class="fix z1 center" style="top:310px;left:100px;width:215px;">'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'googlemaps\');floorplan();" class="btn b1">Google myMaps</button><br><br>'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'garmingpx\');floorplan();" class="btn b1">Garmin GPX</button><br><br>'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'garminbadges\');floorplan();" class="btn b1">Garmin Badges</button><br><br>'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'weegschaal\');floorplan();" class="btn b1">Weegschaal</button><br><br>'
	html+='</div>'
	html+='<div class="fix z1 center" style="top:310px;left:330px;width:150px;">'
	html+='<button onclick="ajaxcontrol(\'MQTT\', \'MQTT\', \'MQTT\');floorplan();" class="btn b1">MQTT&CRON</button><br><br>'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'splitwise\');floorplan();" class="btn b1">Splitwise</button><br><br>'
	html+='<button onclick="ajaxcontrol(\'runsync\', \'runsync\', \'keyplan\');floorplan();" class="btn b1">Keyplan</button><br><br>'
	html+='<button class="btn b1" id="verlof" onclick="verlof();"></div>'
	html+='</div>'
	if (sessionStorage.getItem('weg')==2) html+='<div class="fix z1 center" style="top:590px;left:110px;"><a href=\'javascript:ajaxcontrol("weg","weg","3");floorplan();\'><img src="images/Vacation.png" width="40px" height="40px"/><br>Vacation</a></div>'
	html+='<div class="fix blackmedia">'
	html+='<div class="fix" style="top:750px;left:90px;width:400px;font-size:0.8em;">'
	water=sessionStorage.getItem('water')
	if (water!='Unavailable') {
		items=['water']
		items.forEach(function(item){html+='<div class="fix z1 i48" style="width:70px;" id="'+item+'"></div>';})
		$mode=sessionStorage.getItem('watermode')
		if ($mode==300) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3 btna" id="water300">Water 5 min</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 300);" class="btn b3" id="water300">Water 5 min</button>'
		if ($mode==360) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 360);" class="btn b3 btna" id="water360">Water 6 min</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 360);" class="btn b3" id="water360">Water 6 min</button>'
		if ($mode==420) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 420);" class="btn b3 btna" id="water420">Water 7 min</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 420);" class="btn b3" id="water420">Water 7 min</button>'
		if ($mode==480) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 480);" class="btn b3 btna" id="water480">Water 8 min</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 480);" class="btn b3" id="water480">Water 8 min</button>'
		if ($mode==1800) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3 btna" id="water1800">Water 30 min</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 1800);" class="btn b3" id="water1800">Water 30 min</button>'
		if ($mode==7200) html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3 btna" id="water7200">Water 2 uur</button>'
		else html+='<button onclick="ajaxcontrol(\'water\', \'water\', 7200);" class="btn b3" id="water7200">Water 2 uur</button>'
	}
	html+='</div></div>'
	html+='<div class="fix" id="mediasidebar"><br><br><br><br>'
	html+='<a href=\'javascript:navigator_Go("https://films.egregius.be/films.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Films</a><br><br><br>'
	html+='<a href=\'javascript:navigator_Go("https://films.egregius.be/series.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Series</a><br><br><br>'
	html+='<a href=\'javascript:navigator_Go("kodicontrol.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Kodi<br>Control</a><br><br><br>'
	html+='<a href=\'javascript:navigator_Go("kodi.php");\'><img src="/images/kodi.png" class="i48" alt=""><br>Kodi</a><br><br><br>'
	html+='<div class="fix z1 splitbill"><a href=\'javascript:navigator_Go("https://finance.egregius.be/splitbill/index.php");\'><img src="/images/euro.png" width="48px" height="48px" alt="Euro"></a></div>'
	$('#placeholder').html(html)
	sidebar()
}
function floorplanheating(){
    view='floorplanheating'
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
	ajaxall();
	heatingset=sessionStorage.getItem('heating')
	daikinmode=sessionStorage.getItem('daikinmode')
	html='<div class="abs floorplan2icon" onclick="floorplan();"><img src="/images/close.png" class="i60" alt="plus"></div>'
	html+='<div class="abs leftbuttons" id="heating" onclick="floorplanheating();"></div>'
	html+='<div class="fix z2" id="sirene"></div>'
	html+='<div class="abs z1" style="top:343px;left:415px;"><a href=\'javascript:navigator_Go("floorplan.doorsensors.php");\'><img src="/images/close.png" width="72px" height="72px" alt="Close"></a></div>'
	items=['grohered','kookplaat','daikin','badkamervuur1','badkamervuur2','wasdroger']
	items.forEach(function(item){html+='<div class="abs z1 i48" id="'+item+'"></div>';})
	items=['rbureel','rkeukenl','rkeukenr','rliving','rkamerl','rkamerr','rwaskamer','ralex']
	items.forEach(function(item){html+='<div class="abs yellow" id="'+item+'"></div>';})
	items=['raamalex','raamwaskamer','raamliving','raamkeuken','raamkamer','raamhall','achterdeur','deurvoordeur','deurbadkamer','deurinkom','deurgarage','deurwc','deurkamer','deurwaskamer','deuralex','zliving','zlivingb','zkeuken','zinkom','zgarage','zhalla','zhallb','alwayson','daikin_kwh']
	items.forEach(function(item){html+='<div class="abs z0" id="'+item+'"></div>';})
	items=['living','badkamer','kamer','waskamer','alex','zolder','buiten']
	items.forEach(function(item){html+='<div class="abs" onclick="location.href=\'temp.php?'+item+'=On\';" id="'+item+'_temp"></div>';})
	items=['rliving','rbureel','rkeukenl','rkamerl','rkamerr','rwaskamer','ralex'];
	items.forEach(function(item){html+='<div class="abs z" onclick="roller(\''+item+'\');" id="R'+item+'"></div>';})
	items=['tpirliving','tpirkeuken','tpirgarage','tpirinkom','tpirhall','traamliving','traamkeuken','traamkamer','traamwaskamer','traamalex','tdeurvoordeur','tdeurbadkamer','tdeurinkom','tdeurgarage','tachterdeur','tdeurkamer','tdeurwaskamer','tdeuralex','tdeurwc']
	items.forEach(function(item){html+='<div class="abs stamp" id="'+item+'"></div>';})
	if(heatingset>1) items=['living','badkamer','kamer','alex']
	else if(heatingset==1&&daikinmode=='auto')items=['living','badkamer','kamer','alex']
	else if(heatingset==1&&daikinmode=='man')items=['badkamer']
	else if(heatingset==0)items=['badkamer','living','kamer','alex']
	else if(heatingset==-1)items=['badkamer','living','kamer','alex']
	else if(heatingset==-2&&daikinmode=='auto')items=['living','kamer','alex']
	items.forEach(function(item){html+='<div class="abs z2 '+item+'_set" onclick="setpoint(\''+item+'\');" id="'+item+'_set"></div>';})
	html+='<div class="abs z" onclick="roller(\'luifel\');" id="luifel"></div>'
	html+='<div class="abs z" id="bovenbeneden"><button class="btn btnh" onclick="ajaxcontrol(\'tv\',\'roller\',\'tv\');initview();">TV</button> &nbsp; <button class="btn btnf" onclick="roller(\'Beneden\');">Beneden</button> &nbsp; <button class="btn btnf" onclick="roller(\'Boven\');">Boven</button></div>'
	html+='<div class="abs divsetpoints z"><table class="tablesetpoints">'
	html+='<tr><td id="brander"></td><td align="left" height="60" width="80px" style="line-height:18px">Brander<br><span id="tbrander"></span></td></tr>'
	html+='<tr id="trheating"></tr>'
	html+='</table></div>'
	html+='<div class="abs z1 HUM"><a href=\'javascript:navigator_Go("/hum.php");\'>HUM</a></div>'
	$('#placeholder').html(html)
	sidebar()
}
function sidebar(){
	html='<div class="abs center zon">'
	html+='<img src="images/sunrise.png" alt="sunrise"><div id="dag"></div><br><small>&#x21e7;</small><span id="zonop"></span><br><small>&#x21e7;</small><span id="sunop"></span><br><small>&#x21e9;</small><span id="sunonder"></span><br><small>&#x21e9;</small><span id="zononder"></span><br><div id="uv"></div>'
	html+='<a href=\'javascript:navigator_Go("https://www.buienradar.be/weer/Beitem/BE/2802384");\'><span id="buien"></span></a><br>'
	html+='<span id="wind"></span><br>'
	html+='<a href=\'javascript:navigator_Go("https://www.buienradar.be/weer/beitem/be/2802384/14daagse");\'><img src="" id="icon"></a>'
	html+='<span id="maxtemp"></span>'
	html+='<span id="mintemp"></span><br>'
	html+='</div>'
	document.getElementById('placeholder').insertAdjacentHTML('beforeend', html)
}
function setpoint(device){
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
    
    
    
    level = sessionStorage.getItem(device+'_set');
    heatingset = sessionStorage.getItem('heating');
    temp = sessionStorage.getItem(device+'_temp');
    $mode = sessionStorage.getItem(device+'_set_mode');
    const tmin = parseFloat(sessionStorage.getItem(device+'_temp_min')) || parseFloat(temp) - 5;
    const tavg = parseFloat(sessionStorage.getItem(device+'_temp_avg')) || parseFloat(temp);
    const tmax = parseFloat(sessionStorage.getItem(device+'_temp_max')) || parseFloat(temp) + 5;
    const currentTxtColor = getTemperatureColorTxt(parseFloat(temp), tmin, tavg, tmax);
    const targetTxtColor = getTemperatureColorTxt(parseFloat(level), tmin, tavg, tmax);
    
    let html = '<div class="dimmer"><div class="dimmer-container">';
    html += '<div class="dimmer-header">';
    html += '<h2 class="dimmer-title">'+ucfirst(device)+'</h2>';
    html += '</div>';
    html += '<div class="temp-display">';
    html += '<div class="temp-box current">';
    html += '<div class="temp-label">Temperatuur</div>';
    html += '<div class="temp-value" style="color:'+currentTxtColor+';">'+temp+'°C</div>';
    html += '</div>';
    html += '<div class="temp-box target">';
    html += '<div class="temp-label">Setpoint</div>';
    html += '<div class="temp-value" id="targetTemp" style="color:'+targetTxtColor+';">'+level+'°C</div>';

    html += '</div>';
    html += '</div>';
    
    // Mode toggle
    html += '<div class="mode-toggle">';
    html += '<button class="mode-btn '+($mode==1?'active':'')+'" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'1\');initview();">Manueel</button>';
    html += '<button class="mode-btn '+($mode==0||!$mode?'active':'')+'" onclick="ajaxcontrol(\''+device+'_set\',\'storemode\',\'0\');initview();">Auto</button>';
    html += '</div>';
    
    // Temperature levels
    let temps = [];
    if(device=='badkamer'){
        temps=[11,12,13,14,15,16,16.2,16.4,16.6,16.8,17,17.2,17.4,17.6,17.8,18,18.2,18.4,18.6,18.8,19,19.2,19.4,19.6,19.8,20,20.2,20.4,20.6,20.8,21,21.2,21.4,21.6,21.8];
    }else{
        if(heatingset>0){
            if(device=='living') temps=[10,13,14,15,16,17,17.2,17.4,17.6,17.8,18,18.2,18.4,18.6,18.8,19,19.2,19.4,19.6,19.8,20,20.2,20.4,20.6,20.8,21,21.2,21.4,21.6,21.8,22,22.2,22.4,22.6,22.8];
            else temps=[4,10,11,12,12.5,13,13.2,13.4,13.6,13.8,14,14.2,14.4,14.6,14.8,15,15.2,15.4,15.6,15.8,16,16.2,16.4,16.6,16.8,17,17.2,17.4,17.6,17.8,18,18.2,18.4,18.6,18.8];
        }else if(heatingset==-2){
            temps=[1,2,3,4,5,15,16,17,18,18.5,19,19.5,20,20.5,21,21.5,22,22.5,23,23.5,24,24.5,25,25.5,33,'D'];
        }else{
            temps=['D'];
        }
    }
    
    const cols = 5;
    const total = temps.length;
    const rows = Math.ceil(total / cols);
    let tempsSorted = temps.slice().sort((a,b)=>{
        if(a==='D') return 1;
        if(b==='D') return -1;
        return a-b;
    });
    
    let grid = [];
    for(let r=0;r<rows;r++){
        grid[r] = [];
    }
    for(let i=0;i<tempsSorted.length;i++){
        let row = rows - 1 - Math.floor(i/cols);
        let col = i % cols;
        grid[row][col] = tempsSorted[i];
    }
    
    let orderedTemps = [];
    for(let r=0;r<rows;r++){
        for(let c=0;c<cols;c++){
            if(grid[r][c] !== undefined) orderedTemps.push(grid[r][c]);
        }
    }
    
    html += '<div class="quick-levels">';
    orderedTemps.forEach(function(t){
        let btnClass = 'level-btn';
        let levelNum = parseFloat(level);
        let tempNum = (t === 'D') ? t : parseFloat(t);
        
        if(level == t || (t === 'D' && level === 'D')){
            btnClass += ' active';
        } else if(t !== 'D' && level !== 'D' && levelNum > tempNum){
            btnClass += ' below';
        }
        
        let displayTemp = (t === 'D') ? 'D' : t;
        html += '<button class="'+btnClass+'" data-temp="'+t+'" onclick="setThermostatTemp(\''+device+'\',\''+t+'\')">'+displayTemp+'</button>';
    });
    html += '</div>';
    html += '<button class="close-btn" onclick="floorplanheating();">✕</button>';
    html += '</div></div>';
    
    $('#placeholder').html(html);
}

window.dimmerLocked = window.dimmerLocked || {};


function dimmer(device, floorplan='floorplan'){
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    if(window.dimmerLocked[device]) {
        return;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
    
    
    
    $mode=sessionStorage.getItem(device+'mode')
    current=sessionStorage.getItem(device)
    
    let html = '<div class="dimmer"><div class="dimmer-container">';
    html += '<div class="dimmer-header">';
    html += '<h2 class="dimmer-title">'+ucfirst(device)+'</h2>';
    
    if(current==0) {
        html += '<p class="dimmer-value off" id="dimmerValue">Uit</p>';
    } else {
        html += '<p class="dimmer-value" id="dimmerValue">'+current+'%</p>';
    }
    html += '</div>';
    html += '<div class="slider-container">';
    html += '<div class="slider-track" id="sliderTrack">';
    const sliderPos = dimmerToSlider(parseInt(current));
    html += '<div class="slider-fill" id="sliderFill" style="width:'+sliderPos+'%"></div>';
    html += '<div class="slider-thumb" id="sliderThumb" style="left:'+sliderPos+'%"></div>';
    html += '</div></div>';
    let levels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,24,26,28,30,32,34,36,38,40,45,50,55,60,65,70,75,80,85,90];
    let currentInt = parseInt(current);
    
    if (!levels.includes(currentInt) && currentInt > 0 && currentInt < 100) {
        let closestIndex = 0;
        let closestDiff = Math.abs(levels[0] - currentInt);
        for (let i = 1; i < levels.length; i++) {
            let diff = Math.abs(levels[i] - currentInt);
            if (diff < closestDiff) {
                closestDiff = diff;
                closestIndex = i;
            }
        }
        levels[closestIndex] = currentInt;
    }
    levels.sort((a, b) => a - b);
    
    const cols = 5;
	const rows = 8;
	let grid = [];
	for (let r = 0; r < rows; r++) {
		grid[r] = [];
	}
	
	// Vul grid van rechts naar links
	for (let i = 0; i < levels.length; i++) {
		let row = rows - 1 - Math.floor(i / cols);      // rijen blijven hetzelfde
		let col = cols - 1 - (i % cols);                // kolommen omkeren
		grid[row][col] = levels[i];
	}
	
	let orderedLevels = [];
	for (let r = 0; r < rows; r++) {
		for (let c = 0; c < cols; c++) {
			if(grid[r][c] !== undefined) {
				orderedLevels.push(grid[r][c]);
			}
		}
	}
    
    html += '<div class="quick-levels">';
    orderedLevels.forEach(function(level){
        let btnClass = 'level-btn';
        if(currentInt == level) btnClass += ' active';
        else if(currentInt > level) btnClass += ' below';
        html += '<button class="'+btnClass+'" data-level="'+level+'" onclick="setDimmerLevel(\''+device+'\','+level+')">'+level+'</button>';
    });
    html += '</div>';
    html += '<div class="control-buttons">';
    html += '<button class="ctrl-btn off" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'0\');initview();">';
    html += '<span class="ctrl-btn-icon">⏻</span><span>Uit</span></button>';
    html += '<button class="ctrl-btn on" onclick="ajaxcontrol(\''+device+'\',\'dimmer\',\'100\');initview();">';
    html += '<span class="ctrl-btn-icon">💡</span><span>100%</span></button>';
    html += '</div>';
    html += '<button class="close-btn" onclick="'+floorplan+'();">✕</button>';
    html += '</div></div>';
    $('#placeholder').html(html);
    setTimeout(function() {
        initDimmerSlider(device);
    }, 10);
}


function roller(device, floorplan='floorplanheating'){
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
    
    
    current=sessionStorage.getItem(device)
    let currentInt = parseInt(current);
    let html = '<div class="dimmer"><div class="dimmer-container">';
    html += '<div class="dimmer-header">';
    html += '<h2 class="dimmer-title">'+ucfirst(device)+'</h2>';
    let status = '';
    if(currentInt == 0) {
        status = device == 'luifel' ? 'Dicht' : 'Open';
    } else if(currentInt == 100) {
        status = device == 'luifel' ? 'Open' : 'Dicht';
    } else if(device != 'Beneden' && device != 'Boven') {
        status = currentInt + '%';
    }
    
    if(status) {
        html += '<p class="dimmer-value" id="rollerValue">'+status+'</p>';
    } else {
        html += '<p class="dimmer-value" id="rollerValue">--</p>';
    }
    html += '</div>';
    if(device == 'luifel') {
        let mode = sessionStorage.getItem(device+'mode');
        html += '<div class="mode-toggle">';
        html += '<button class="mode-btn '+(mode==1?'active':'')+'" onclick="ajaxcontrol(\'luifel\',\'mode\',\'1\');initview();">Manueel</button>';
        html += '<button class="mode-btn '+(mode==0||!mode?'active':'')+'" onclick="ajaxcontrol(\'luifel\',\'mode\',\'0\');initview();">Auto</button>';
        html += '</div>';
    }
    let levels = [5,10,15,20,25,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,85,90,95];
    if (!levels.includes(currentInt) && currentInt > 0 && currentInt < 100) {
        let closestIndex = 0;
        let closestDiff = Math.abs(levels[0] - currentInt);
        for (let i = 1; i < levels.length; i++) {
            let diff = Math.abs(levels[i] - currentInt);
            if (diff < closestDiff) {
                closestDiff = diff;
                closestIndex = i;
            }
        }
        levels[closestIndex] = currentInt;
    }
    levels.sort((a, b) => b - a);
    const cols = 5;
    const total = levels.length;
    const rows = Math.ceil(total / cols);
    let grid = [];
    for(let r=0; r<rows; r++){
        grid[r] = [];
    }
    for(let i=0; i<levels.length; i++){
        let row = rows - 1 - Math.floor(i / cols);
        let col = i % cols;
        grid[row][col] = levels[i];
    }
    let orderedLevels = [];
    for(let r=0;r<rows;r++){
        for(let c=0;c<cols;c++){
            if(grid[r][c] !== undefined) orderedLevels.push(grid[r][c]);
        }
    }
    
    html += '<div class="quick-levels">';
    orderedLevels.forEach(function(level){
        let btnClass = 'level-btn';
        if(currentInt == level) btnClass += ' active';
        else if(currentInt < level) btnClass += ' below';
        html += '<button class="'+btnClass+'" data-level="'+level+'" onclick="setRollerLevel(\''+device+'\','+level+')">'+level+'</button>';
    });
    html += '</div>';
    // Direction buttons
    html += '<div class="roller-direction-buttons">';
    
    if(device == 'luifel') {
        html += '<button class="direction-btn down '+(currentInt==100?'active':'')+'" onclick="setRollerLevel(\''+device+'\',100)">';
        html += '<span class="direction-btn-icon">▼</span><span>Uitrollen</span></button>';
        html += '<button class="direction-btn up '+(currentInt==0?'active':'')+'" onclick="setRollerLevel(\''+device+'\',0)">';
        html += '<span class="direction-btn-icon">▲</span><span>Oprollen</span></button>';
    } else {
        html += '<button class="direction-btn down '+(currentInt==100?'active':'')+'" onclick="setRollerLevel(\''+device+'\',100)">';
        html += '<span class="direction-btn-icon">▼</span><span>Omlaag</span></button>';
        html += '<button class="direction-btn up '+(currentInt==0?'active':'')+'" onclick="setRollerLevel(\''+device+'\',0)">';
        html += '<span class="direction-btn-icon">▲</span><span>Omhoog</span></button>';
    }
    html += '</div>';
    
    // Close button
    html += '<button class="close-btn" onclick="'+floorplan+'();">✕</button>';
    html += '</div></div>';
    
    $('#placeholder').html(html);
    
    // Attach slider events
    setTimeout(function() {
        initRollerSlider(device);
    }, 10);
}
function verlof(){
	if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
	html='<div class="dimmer" ><div style="min-height:220px">'
	html+='<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplanothers();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div>'
	html+='<div id="message" class="dimmer">'

	if (d.verlof.s==2)html+='<button class="btn btna huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'2\');initview();">Verlof</button>'
	else html+='<button class="btn huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'2\');initview();">Verlof</button>'

	if (d.verlof.s==1)html+='<button class="btn btna huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'1\');initview();">Geen school</button>'
	else html+='<button class="btn huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'1\');initview();">Geen school</button>'

	if (d.verlof.s==0)html+='<button class="btn btna huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'0\');initview();">Normaal</button>'
	else html+='<button class="btn huge3" style="display:inline-block;" onclick="ajaxcontrol(\'verlof\',\'verlof\',\'0\');initview();">Normaal</button>'

	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function weg(){
    if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
    
    let html = ''
    html += '<div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div><div id="message" class="dimmer">'
    const warnings = []
    if(d.achterdeur.s === 'Open') warnings.push('Achterdeur OPEN')
    if(d.raamliving.s === 'Open') warnings.push('Raam Living OPEN')
    if(d.raamhall.s === 'Open') warnings.push('Raam Hall OPEN')
    if(d.raamkeuken.s === 'Open') warnings.push('Raam Keuken OPEN')
    if(d.bose103.s === 'On') warnings.push('Bose kamer aan')
    if(d.bose104.s === 'On') warnings.push('Bose garage aan')
    if(d.bose105.s === 'On') warnings.push('Bose keuken aan')
    if(d.bose106.s === 'On') warnings.push('Bose Buiten20 aan')
    if(d.bose107.s === 'On') warnings.push('Bose Buiten10 aan')
    if(warnings.length > 0){
        html += '<h1 style="font-size:4em">OPGELET!<br>'
        html += warnings.join('<br>')
        html += '</h1>'
    }
	let buttonHeight = Math.max(44 - warnings.length * 10, 12) + 'vh'
    if(d.weg.s == 0){
        html += `<button class="btn huge2" style="height:${buttonHeight};display:inline-block;background-image:url(images/weg.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol('weg','weg','2');initview();">Weg</button>`
        html += `<button class="btn huge2" style="height:${buttonHeight};display:inline-block;background-image:url(images/Slapen.png);background-repeat:no-repeat;background-position:center left 58px;background-size:25%;" onclick="ajaxcontrol('weg','weg','1');initview();">Slapen</button>`
    } else if(d.weg.s >= 1){
        ajaxcontrol('weg','weg',0)
        window.location.reload(true)
    }
    html += '</div></div>'
    $('#placeholder').html(html);
}

function heating(){
	if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
	html='<div class="dimmer" ><div style="min-height:220px"><div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplanheating();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div><div id="message" class="dimmer">'
	if(d.heating.s==3) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');initview();">Gas heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Gas.png);background-repeat:no-repeat;background-position:center left 80px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'3\');initview();">Gas heating</button>'
	if(d.heating.s==2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');initview();">Gas-Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/GasAirco.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'2\');initview();">Gas-Airco heating</button>'
	if(d.heating.s==1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');initview();">Airco heating</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_red.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'1\');initview();">Airco heating</button>'
	if(d.heating.s==0) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');initview();">Neutral</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/close.png);background-repeat:no-repeat;background-position:center left 35px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'0\');initview();">Neutral</button>'
	if(d.heating.s==-1) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');initview();">Passive cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling_grey.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-1\');initview();">Passive cooling</button>'
	if(d.heating.s==-2) html+='<button class="btn btna huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');initview();">Airco cooling</button>'
	else html+='<button class="btn huge7" style="display:inline-block;background-image:url(images/Cooling.png);background-repeat:no-repeat;background-position:center left 50px;" onclick="ajaxcontrol(\'heating\',\'heating\',\'-2\');initview();">Airco cooling</button>'
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
function confirmSwitch(device){
	if (ajaxTimer) {
        clearTimeout(ajaxTimer);
        ajaxTimer = null;
    }
    let d = sessionStorage.getItem(view);
	if (d) {
		d = JSON.parse(d);
	}
    html='<div class="dimmer" ><div style="min-height:220px"><div class="fix" style="bottom:12px;left:12px;z-index:200000" onclick="floorplan();"><img src="/images/close.png" width="72px" height="72px" alt="Close"></div><div id="message" class="dimmer"><br><h1>'+device+'</h1><br>'
	if (d[device].s=='On') {
		html+='<button class="btn btna huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\');initview();">On</button>'
		html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\');initview();">Off</button>'
	} else {
		html+='<button class="btn huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'On\');initview();">On</button>'
		html+='<button class="btn btna huge3" onclick="ajaxcontrol(\''+device+'\',\'sw\',\'Off\');initview();">Off</button>'
	}
	html+='</div>'
	html+='</div>'
	$('#placeholder').html(html)
}
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        if (ajaxTimer) {
            clearTimeout(ajaxTimer);
            ajaxTimer = null;
        }
    } else {
        ajax();
    }
});
!function(t,e){"use strict";const r={rAF:"undefined"!=typeof requestAnimationFrame,AbortController:"undefined"!=typeof AbortController,passiveEvent:(()=>{let e=!1;try{const r=Object.defineProperty({},"passive",{get(){e=!0}});t.addEventListener("testPassive",null,r),t.removeEventListener("testPassive",null,r)}catch(t){}return e})()},n=new Map;function o(t){if(!t)return null;if("string"!=typeof t)return t;if(n.has(t))return n.get(t);const r=e.getElementById(t);return n.set(t,r),r}const s=[];let i=!1;function c(t){"function"==typeof t&&(s.push(t),i||(i=!0,r.rAF?requestAnimationFrame(a):setTimeout(a,16)))}function a(){try{for(let t=0;t<s.length;t++)try{s[t]()}catch(t){console.error("DOM write error",t)}}finally{s.length=0,i=!1}}function l(t,e){const r="string"==typeof t?o(t):t;r&&r.innerHTML!==e&&c((()=>{r.innerHTML=e}))}function u(t,e){const r="string"==typeof t?o(t):t;r&&r.textContent!==e&&c((()=>{r.textContent=e}))}function f(t,e,r){const n="string"==typeof t?o(t):t;n&&(n.getAttribute&&n.getAttribute(e)===r||c((()=>{n.setAttribute&&n.setAttribute(e,r)})))}t._FP_safe=Object.assign(t._FP_safe||{},{$id:o,safeSetHtml:l,safeSetText:u,safeSetAttr:f,queueDomWrite:c});try{const t=EventTarget.prototype.addEventListener;EventTarget.prototype.addEventListener=function(e,n,o){const s=["touchstart","touchmove","wheel","mousewheel","scroll"];let i=o;try{null==o&&(i=!(!r.passiveEvent||-1===s.indexOf(e))&&{passive:!0})}catch(t){i=o}return t.call(this,e,n,i)}}catch(t){console.error("Fout bij EventTarget.prototype.addEventListener ",t)}!function(){const r=t.setInterval,n=t.clearInterval;t.setInterval=function(t,n,...o){if("function"!=typeof t)return r(t,n,...o);return r((function(){try{if(e.hidden)return;t.apply(this,arguments)}catch(t){console.error("Interval callback error",t)}}),n,...o)},t.clearInterval=function(t){return n(t)}}(),t.jQuery&&t.jQuery.fn&&function(t){try{const e=t.fn;function r(e,r){return function(n){return 0===arguments.length||"function"==typeof n?e.apply(this,arguments):(this.each(((o,s)=>{c((()=>{try{e.call(t(s),n)}catch(t){console.error("jQuery."+r+" write error",t)}}))})),this)}}if(e.html&&(e.html=r(e.html,"html")),e.text&&(e.text=r(e.text,"text")),e.attr){const n=e.attr;e.attr=function(e,r){return 0===arguments.length||1===arguments.length&&"string"==typeof e?n.apply(this,arguments):"object"==typeof e?(this.each(((r,o)=>{c((()=>{try{n.call(t(o),e)}catch(t){console.error("jQuery.attr write error",t)}}))})),this):"function"==typeof r?n.apply(this,arguments):(this.each(((o,s)=>{c((()=>{try{n.call(t(s),e,r)}catch(t){console.error("jQuery.attr write error",t)}}))})),this)}}["append","prepend","after","before","replaceWith","remove"].forEach((r=>{if(!e[r])return;const n=e[r];e[r]=function(){if(0===arguments.length)return n.apply(this,arguments);for(let t=0;t<arguments.length;t++)if("function"==typeof arguments[t])return n.apply(this,arguments);return this.each(((e,o)=>{const s=arguments;c((()=>{try{n.apply(t(o),s)}catch(t){console.error("jQuery."+r+" error",t)}}))})),this}}))}catch(o){console.error("jQuery wrapper error",o)}}(t.jQuery),t.jQuery&&!t.jQuery.json&&function(t){try{const e=new Map;t.json=function(n,o){(o=o||{}).timeout;const s=n+"::"+(o.tag||"default");if(r.AbortController){const t=e.get(s);if(t)try{t.abort()}catch(t){}const r=new AbortController;e.set(s,r);const o={signal:r.signal,credentials:"same-origin",cache:"no-store"};return fetch(n,o).then((t=>{if(!t.ok)throw new Error("HTTP "+t.status);return t.json()})).finally((()=>{e.delete(s)}))}return t.getJSON?t.getJSON(n):fetch(n,{credentials:"same-origin",cache:"no-store"}).then((t=>{if(!t.ok)throw new Error("HTTP "+t.status);return t.json()}))}}catch(t){console.error("$.json wrapper failed",t)}}(t.jQuery),t._FP_Control=Object.assign(t._FP_Control||{},{queueDomWrite:c,safeSetHtml:l,safeSetText:u,safeSetAttr:f,enableDebug:()=>{t._FP_DEBUG=!0},disableDebug:()=>{t._FP_DEBUG=!1}}),t.addEventListener("pagehide",(()=>{try{a()}catch(t){console.error("_flushDomQueue failed",t)}}))}(window,document);
const circleStates = {};
function navigator_Go(n){window.location.assign(n)}
function ajax() {
    const start = performance.now();
    const run = ++ajaxToken;
    let url;
    if (view === 'floorplan') url = 'd.php';
    else if (view === 'floorplanothers') url = 'd.php?o';
    else if (view === 'floorplanheating') url = 'd.php?h';
    $.json(url).then(function (e) {
        if (run !== ajaxToken) return;
        let d = sessionStorage.getItem(view);
        if (d) {
            d = JSON.parse(d);
            Object.assign(d, e);
            sessionStorage.setItem(view, JSON.stringify(d));
        } else {
            sessionStorage.setItem(view, JSON.stringify(e));
        }
        handleResponse(e);
        const rtt = performance.now() - start;
        if(rtt<=50) delay = 500 - rtt
        else delay = 1e3 - rtt
        ajaxTimer = setTimeout(ajax, delay);
    }).catch(function () {
        ajaxTimer = setTimeout(ajax, 1e3);
    });
}

function ajaxall(){
	const e=sessionStorage.getItem(view);
	if(!e)return fetchAll();
	try{d=JSON.parse(e)}catch(e){return sessionStorage.removeItem(view),fetchAll()}
	Promise.resolve().then((()=>{if("loading"===document.readyState)document.addEventListener("DOMContentLoaded",(()=>handleResponse(d)),{once:!0});else try{handleResponse(d)}catch(e){sessionStorage.removeItem(view),fetchAll()}}))
	ajaxTimer = setTimeout(ajax, 500);
}
function fetchAll(){
	if(view=='floorplan')url="da.php?all"
	else if(view=='floorplanothers')url="da.php?o&all"
	else if(view=='floorplanheating')url="da.php?h&all"
	$.json(url).then((function(e){sessionStorage.setItem(view,JSON.stringify(e)),handleResponse(e)}))
	ajaxTimer = setTimeout(ajax, 500);
}
function ajaxcontrol(a,o,n){$.get("/ajax.php?device="+a+"&command="+o+"&action="+n);}
function ajaxcontrolbose(a,o,n){$.get("/ajax.php?boseip="+a+"&command="+o+"&action="+n)}

function floorplanbose(){ajaxbose($ip)(),myAjaxmedia=$.setInterval((function(){ajaxbose($ip)}),1e3)}
function pad(e,n){return len=n-(""+e).length,(len>0?new Array(++len).join("0"):"")+e}
function toggle_visibility(n){e=document.getElementById(n),"inherit"==e.style.display?e.style.display="none":e.style.display="inherit"}
function fix(){var e=this,n=e.parentNode,i=e.nextSibling;n.removeChild(e),setTimeout((function(){n.insertBefore(e,i)}),0)}
function human_kb(e){
    var n = -1;
    do {
        e /= 1024;
        n++;
    } while(e > 1024);
    var val = n === 0 ? Math.round(e) : Math.max(e, 0.1).toFixed(1);
    return val + [" kb"," Mb"," Gb"," Tb"," Pb"," Eb"," Zb"," Yb"][n];
}
function initview(){"floorplan"==view?window.floorplan():"floorplanheating"==view?window.floorplanheating():"floorplanothers"==view?window.floorplanothers():"floorplandaikin"==view?window.floorplandaikin():window.floorplan()}
function sliderToDimmer(r){return r<=50?r/50*25:25+(r-50)/50*75}
function dimmerToSlider(r){return r<=25?r/25*50:50+(r-25)/75*50}
function setThermostatTemp(t,o){ajaxcontrol(t,"setpoint",o),floorplanheating()}
function setRollerLevel(e,l){ajaxcontrol(e,"roller",l),initview()}
function setDimmerLevel(e,i){ajaxcontrol(e,"dimmer",i),initview()}
function initDimmerSlider(e){const t=document.getElementById("sliderTrack"),n=document.getElementById("sliderThumb"),o=document.getElementById("sliderFill"),s=document.getElementById("dimmerValue");if(!t)return;let i=!1,d=parseInt(sessionStorage.getItem(e))||0,c=null;function r(e){const t=Math.round(e);return s&&(0===t?(s.textContent="Uit",s.classList.add("off")):(s.textContent=t+"%",s.classList.remove("off"))),document.querySelectorAll(".level-btn").forEach((e=>{const n=parseInt(e.dataset.level);e.classList.remove("active","below"),n===t?e.classList.add("active"):n<t&&e.classList.add("below")})),d=t,t}function l(t){window.dimmerLocked[e]=!0,ajaxcontrol(e,"dimmer",t),sessionStorage.setItem(e,t)}function a(e){e.cancelable&&e.preventDefault();const s=t.getBoundingClientRect(),d=(e.clientX||(e.touches&&e.touches[0]?e.touches[0].clientX:null))-s.left;if(null===d)return;const a=Math.max(0,Math.min(100,d/s.width*100)),u=(m=a)<=50?m/50*25:25+(m-50)/50*75;var m;const v=r(Math.round(u));return o.style.width=a+"%",n.style.left=a+"%",i&&(c&&clearTimeout(c),c=setTimeout((()=>l(v)),250)),v}function u(t){i=!0,window.dimmerLocked[e]=!0,n.style.cursor="grabbing"}function m(){i&&(i=!1,n.style.cursor="grab",c&&clearTimeout(c),l(d),setTimeout((()=>{window.dimmerLocked[e]=!1}),1e3))}n.addEventListener("mousedown",u),document.addEventListener("mousemove",(e=>{i&&a(e)})),document.addEventListener("mouseup",m),n.addEventListener("touchstart",(e=>{e.preventDefault(),u()}),{passive:!1}),document.addEventListener("touchmove",(e=>{i&&(e.preventDefault(),a(e))}),{passive:!1}),document.addEventListener("touchend",(e=>{i&&(e.preventDefault(),m())}),{passive:!1}),document.addEventListener("touchcancel",(e=>{i&&(e.preventDefault(),m())}),{passive:!1}),t.addEventListener("click",(function(e){if(!i){l(a(e))}}))}
function initRollerSlider(e){const t=document.getElementById("sliderTrack"),n=document.getElementById("sliderThumb"),o=document.getElementById("sliderFill"),i=document.getElementById("rollerValue");if(!t)return;let l=!1;function c(l){const c=t.getBoundingClientRect(),d=(l.clientX||l.touches[0].clientX)-c.left;!function(t){const l=Math.round(t);if(o.style.width=l+"%",n.style.left=l+"%",i){let t="";t=0==l?"luifel"==e?"Dicht":"Open":100==l?"luifel"==e?"Open":"Dicht":l+"%",i.textContent=t}document.querySelectorAll(".level-btn").forEach((e=>{const t=parseInt(e.dataset.level);e.classList.remove("active","below"),t===l?e.classList.add("active"):t>l&&e.classList.add("below")})),document.querySelectorAll(".direction-btn").forEach((e=>{e.classList.remove("active")})),0==l?document.querySelector(".direction-btn.up")?.classList.add("active"):100==l&&document.querySelector(".direction-btn.down")?.classList.add("active")}(Math.max(0,Math.min(100,d/c.width*100)))}function d(){if(l){l=!1;const t=Math.round(parseFloat(o.style.width));ajaxcontrol(e,"roller",t),initview()}}n.addEventListener("mousedown",(()=>l=!0)),n.addEventListener("touchstart",(()=>l=!0)),document.addEventListener("mousemove",(e=>{l&&c(e)})),document.addEventListener("touchmove",(e=>{l&&c(e)})),document.addEventListener("mouseup",d),document.addEventListener("touchend",d),t.addEventListener("click",(function(t){c(t);const n=Math.round(parseFloat(o.style.width));ajaxcontrol(e,"roller",n),initview()}))}
function berekenKleurRood(t,r){let a,n,o;const d=.25*r,e=.5*r,u=.75*r;return(t=Math.max(0,Math.min(r,t)))<d?(a=204,n=204+t/d*51,o=204):t<e?(a=255,n=255-(t-d)/(e-d)*50,o=0):t<u?(a=255,n=165-(t-e)/(u-e)*15,o=0):(a=255,n=69-(t-u)/(r-u)*69,o=0),`#${Math.round(a).toString(16).padStart(2,"0")}${Math.round(n).toString(16).padStart(2,"0")}${Math.round(o).toString(16).padStart(2,"0")}`}
function berekenKleurGroen(t,r){let n,a,o;const e=.25*r,d=.5*r,u=.75*r;return(t=Math.max(0,Math.min(r,t)))<e?(n=204,a=204+t/e*51,o=204):t<d?(n=255,a=255-(t-e)/(d-e)*50,o=0):t<u?(n=165-(t-d)/(u-d)*15,a=255,o=0):(n=69-(t-u)/(r-u)*69,a=255,o=0),`#${Math.round(n).toString(16).padStart(2,"0")}${Math.round(a).toString(16).padStart(2,"0")}${Math.round(o).toString(16).padStart(2,"0")}`}
function berekenKleurBlauw(t,a){let r,n,o;const u=.25*a,d=.5*a,e=.75*a;return(t=Math.max(0,Math.min(a,t)))<u?(r=204,n=204,o=204+t/u*51):t<d?(r=0,n=0,o=255-(t-u)/(d-u)*50):t<e?(r=165-(t-d)/(e-d)*15,n=165-(t-d)/(e-d)*15,o=255):(r=69-(t-e)/(a-e)*69,n=0,o=255),`#${Math.round(r).toString(16).padStart(2,"0")}${Math.round(n).toString(16).padStart(2,"0")}${Math.round(o).toString(16).padStart(2,"0")}`}
function drawCircle(e,t,c,r,a){const l=document.getElementById(e),n=l.getContext("2d"),i=l.width/2,u=l.height/2,d=r/2;circleStates[e]||(circleStates[e]={currentValue:t,targetValue:t});const g=circleStates[e];g.currentValue=t,g.targetValue=t,drawCircleFrame(n,i,u,d,t,c,a,e)}
function drawCircleFrame(e,t,r,l,f,a,s,o){const k=Math.abs(f)/a;let y;y=k>2?k-2:k>1?k-1:k;const S=2*Math.PI,c=y*S;e.clearRect(0,0,e.canvas.width,e.canvas.height),e.beginPath(),e.arc(t,r,l,-Math.PI/2,-Math.PI/2+S),e.lineWidth=10,k>2?f>=0?"purple"==s?e.strokeStyle="#b54dff":"green"==s?e.strokeStyle="#66ff66":"red"==s?e.strokeStyle="#ffb833":"blue"==s&&(e.strokeStyle="#3333ff"):"purple"==s?e.strokeStyle="#0f3d0f":"green"==s?e.strokeStyle="#66ff66":"red"==s?e.strokeStyle="#ffb833":"blue"==s&&(e.strokeStyle="#000080"):k>1?f>=0?"purple"==s?e.strokeStyle="#b54dff":"green"==s?e.strokeStyle="#33cc33":"red"==s?e.strokeStyle="#ffb833":"blue"==s&&(e.strokeStyle="#3333ff"):"purple"==s?e.strokeStyle="#0f3d0f":"green"==s?e.strokeStyle="#33cc33":"red"==s?e.strokeStyle="#ffb833":"blue"==s&&(e.strokeStyle="#000080"):f>=0?"purple"==s?e.strokeStyle="#3b0066":"green"==s?e.strokeStyle="#0f3d0f":"red"==s?e.strokeStyle="#805300":"blue"==s?e.strokeStyle="#000080":"gray"==s&&(e.strokeStyle="#000000"):"purple"==s||"green"==s?e.strokeStyle="#0f3d0f":"red"==s?e.strokeStyle="#805300":"blue"==s&&(e.strokeStyle="#000080"),e.stroke(),e.beginPath(),k>2?f>=0?("green"==s?e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0):e.arc(t,r,l,-Math.PI/2,-Math.PI/2+c),"purple"==s?e.strokeStyle="#ff0000":"green"==s?e.strokeStyle="#f0ff05":("red"==s||"blue"==s)&&(e.strokeStyle="#ff0000")):(e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0),"purple"==s?e.strokeStyle="#33cc33":"green"==s?e.strokeStyle="#e6ff00":"red"==s?e.strokeStyle="#ff1a1a":"blue"==s&&(e.strokeStyle="#ff0000")):k>1?f>=0?("green"==s?e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0):e.arc(t,r,l,-Math.PI/2,-Math.PI/2+c),"purple"==s?e.strokeStyle="#ff0000":"green"==s?e.strokeStyle="#66ff66":("red"==s||"blue"==s)&&(e.strokeStyle="#ff0000")):(e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0),"purple"==s?e.strokeStyle="#33cc33":"green"==s?e.strokeStyle="#e6ff00":"red"==s?e.strokeStyle="#ff1a1a":"blue"==s&&(e.strokeStyle="#ff0000")):f>=0?("green"==s?e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0):e.arc(t,r,l,-Math.PI/2,-Math.PI/2+c),"purple"==s?e.strokeStyle="#b54dff":"green"==s?e.strokeStyle="#33cc33":"red"==s?e.strokeStyle="#ffb833":"blue"==s?e.strokeStyle="#3333ff":"gray"==s&&(e.strokeStyle="#aaaaaa")):(e.arc(t,r,l,-Math.PI/2,-Math.PI/2-c,!0),"purple"==s||"green"==s?e.strokeStyle="#33cc33":"red"==s?e.strokeStyle="#ffb833":"blue"==s&&(e.strokeStyle="#3333ff")),e.lineWidth=10,e.stroke()}
function updateSecondsInQuarter(e){let t=new Date(1e3*e);return Math.floor(t.getTime()/1e3)%900}
function renderThermometer(t,e){const{dt:s,s:n,icon:o,m:i}=e,a=parseFloat(n),r="buiten_temp"!==t?parseFloat(o):0,p=["zolder_temp","waskamer_temp"].includes(t),l=i||0;sessionStorage.setItem(t,n);const d=parseFloat(sessionStorage.getItem(`${t}_min`))||a-5,x=parseFloat(sessionStorage.getItem(`${t}_avg`))||a,m=parseFloat(sessionStorage.getItem(`${t}_max`))||a+5,g=m-d;let c=(a-d)/g*68+20;c=Math.max(20,Math.min(85,c));const h=91-c,b=getTemperatureColor(a,d,x,m),u=document.getElementById(t);if(!u)return;u.classList.contains("thermometer-initialized")||u.classList.add("thermometer-initialized");let f=`<div class="fix tmpbg thermometer-mercury"  style="top:${h}px; left:8px; width:26px; height:${c}px; background:${b}; border-radius:6px; position:absolute;box-shadow: inset 0 -2px 8px rgba(255,255,255,0.3), 0 2px 8px rgba(0,0,0,0.2);transition: height 0.8s ease-out, top 0.8s ease-out, background 0.5s ease;"></div><div class="average-line"  style="position:absolute; top:${91-(20+(x-d)/g*68)}px; left:8px; width:26px; height:3px; background:#0D0;box-shadow: 0 0 4px #0D0; border-radius:2px;transition: top 0.8s ease-out;"></div><img src="/images/temp.png" height="100px" width="42px" alt="${t}"  style="position:absolute; top:0; left:0; filter: drop-shadow(1px 1px 2px rgba(0,0,0,0.3));"><div class="fix center temp-display"  style="top:73px; left:5px; width:32px; text-align:center; font-weight:bold; color:#FFF; position:absolute;text-shadow: 1px 1px 3px rgba(0,0,0,0.8), 0 0 8px rgba(0,0,0,0.5);font-size:13px; line-height:1.2;" id="temp${t}">${a.toFixed(1).replace(".",",")}${p?"":`<br>${l}%`}</div>`;const $=getTrendArrow(r);u.style.opacity="0.7",u.innerHTML=f,$&&u.insertAdjacentHTML("beforeend",$),setTimeout((()=>{u.style.opacity="1"}),50)}
function getTemperatureColor(r,n,e,t){if(r<n)return"linear-gradient(180deg, #5588ff 0%, #2255ff 100%)";if(r<e){const t=(r-n)/(e-n);return`linear-gradient(180deg,rgb(${34+Math.round(221*t)}, ${85+Math.round(130*t)}, ${255-Math.round(255*t)}) 0%,rgb(${20+Math.round(220*t)}, ${70+Math.round(130*t)}, ${255-Math.round(255*t)}) 100%)`}if(Math.abs(r-e)<=1)return"linear-gradient(180deg, #FFD700 0%, #FFC000 100%)";if(r<=t){const n=(r-e)/(t-e);return`linear-gradient(180deg,rgb(255, ${Math.round(192-192*n)}, 0) 0%, rgb(255, ${Math.round(170-170*n)}, 0) 100%)`}return"linear-gradient(180deg, #FF3300 0%, #CC0000 100%)"}
function getTemperatureColorTxt(r,t,n,u){if(r<t)return"#3377ff";if(r<n){const u=(r-t)/(n-t);return`rgb(${34+Math.round(221*u)}, ${85+Math.round(130*u)}, ${255-Math.round(255*u)})`}if(Math.abs(r-n)<=1)return"#FFD700";if(r<=u){const t=(r-n)/(u-n);return`rgb(${255}, ${Math.round(192-192*t)}, ${0})`}return"#FF3300"}
function getTrendArrow(t){const n=Math.min(Math.abs(t),1),r=Math.round(14+42*n);return t>.05?`<div class="abs trend-arrow" style="top:10px; left:13px;"><img src="/images/trendup.png" height="${r}px" width="15px" style="filter: drop-shadow(0 0 3px rgba(255,100,0,0.8));"></div>`:t<-.05?`<div class="abs trend-arrow" style="top:10px; left:13px;"><img src="/images/trenddown.png" height="${r}px" width="15px" style="filter: drop-shadow(0 0 3px rgba(100,150,255,0.8));"></div>`:""}
